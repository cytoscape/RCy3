print ("Automatic execution of RCytoscape unit tests disabled because they take too long for the build machine.")
#require("RCy3") || stop("unable to load RCytoscape package")
#RCy3:::.test()
