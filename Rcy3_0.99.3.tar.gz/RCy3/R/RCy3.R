# move these to the DESCRIPTION file
library(httr)
library(graph)
library(methods)
library(RJSONIO)
library(RCurl)
# ------------------------------------------------------------------------------
printf = function (...) print (noquote (sprintf (...)))
# ------------------------------------------------------------------------------
setClass("CytoscapeConnectionClass", 
	representation = representation (uri="character"), 
	prototype = prototype (uri="http://localhost:1234/v1")
)

# ------------------------------------------------------------------------------
setClass("CytoscapeWindowClass", 
	representation = representation(
		title="character", 
		window.id='character', 
		graph="graphBase", 
		collectTimings="logical",
		suid.name.dict="list",
    edge.suid.name.dict="list",
    view.id='numeric'), 
	contains = 'CytoscapeConnectionClass', 
	prototype = prototype(title="R graph", 
		graph=new("graphNEL", edgemode='directed'), 
		uri="http://localhost:1234/v1", 
		collectTimings=FALSE, 
		suid.name.dict=list(),
    edge.suid.name.dict=list())
)

# ------------------------------------------------------------------------------
setGeneric ('ping', 
   signature='obj', function(obj) standardGeneric('ping'))
setGeneric ('pluginVersion', 
   signature='obj', function(obj) standardGeneric('pluginVersion'))
setGeneric ('getServerStatus', 
   signature='obj', function(obj, api.version) standardGeneric('getServerStatus'))
setGeneric ('msg', 
  signature='obj', function(obj, string) standardGeneric('msg'))
setGeneric ('clearMsg', 
  signature='obj', function(obj) standardGeneric('clearMsg'))
setGeneric ('createWindow', 
  signature='obj', function(obj) standardGeneric('createWindow'))
setGeneric ('createWindowFromSelection', 
  signature='obj', function(obj, new.windowTitle, return.graph) standardGeneric ('createWindowFromSelection'))
setGeneric ('getWindowCount', 
  signature='obj', function(obj) standardGeneric ('getWindowCount'))
setGeneric ('getWindowList',
  signature='obj', function(obj) standardGeneric ('getWindowList'))
setGeneric ('deleteWindow', 
  signature='obj', function(obj, window.title=NA) standardGeneric ('deleteWindow'))
setGeneric ('deleteAllWindows', 
  signature='obj', function(obj) standardGeneric ('deleteAllWindows'))
setGeneric ('getArrowShapes', 
  signature='obj', function(obj) standardGeneric ('getArrowShapes'))
setGeneric ('getLayoutNames', 
  signature='obj', function(obj) standardGeneric ('getLayoutNames'))
setGeneric ('getLayoutNameMapping',	
  signature='obj', function(obj) standardGeneric ('getLayoutNameMapping'))
setGeneric ('getLayoutPropertyNames',	
  signature='obj', function(obj, layout.name) standardGeneric ('getLayoutPropertyNames'))
setGeneric ('getLayoutPropertyType',	
  signature='obj', function(obj, layout.name, property.name) standardGeneric ('getLayoutPropertyType'))
setGeneric ('getLayoutPropertyValue', 
  signature='obj', function(obj, layout.name, property.name) standardGeneric ('getLayoutPropertyValue'))
setGeneric ('setLayoutProperties', 
  signature='obj', function(obj, layout.name, properties.list) standardGeneric ('setLayoutProperties'))
setGeneric ('getLineStyles', 
  signature='obj', function(obj) standardGeneric ('getLineStyles'))
setGeneric ('getNodeShapes', 
  signature='obj', function(obj) standardGeneric ('getNodeShapes'))
setGeneric ('getDirectlyModifiableVisualProperties', 
  signature='obj', function(obj) standardGeneric ('getDirectlyModifiableVisualProperties'))
setGeneric ('getAttributeClassNames',	
  signature='obj', function(obj) standardGeneric ('getAttributeClassNames'))
setGeneric ('setGraph', 
  signature='obj', function(obj, graph) standardGeneric ('setGraph'))
setGeneric ('getGraph', 
  signature='obj', function(obj) standardGeneric ('getGraph'))
setGeneric ('sendNodes', 
  signature='obj', function(obj) standardGeneric ('sendNodes'))
setGeneric ('sendEdges', 
  signature='obj', function(obj) standardGeneric ('sendEdges'))

setGeneric ('addCyNode', 
  signature='obj', function(obj, nodeName) standardGeneric ('addCyNode'))
setGeneric ('addCyEdge', 
  signature='obj', function(obj, sourceNode, targetNode, edgeType, directed) standardGeneric ('addCyEdge'))
setGeneric ('addGraphToGraph', 
  signature='obj', function(obj, other.graph) standardGeneric ('addGraphToGraph'))

setGeneric ('setNodeAttributes', 
  signature='obj', function(obj, attribute.name) standardGeneric ('setNodeAttributes'))
setGeneric ('setNodeAttributesDirect', 
  signature='obj', function(obj, attribute.name, attribute.type, node.names, values) standardGeneric ('setNodeAttributesDirect'))

setGeneric ('setEdgeAttributes', 
  signature='obj', function(obj, attribute.name) standardGeneric ('setEdgeAttributes'))
setGeneric ('setEdgeAttributesDirect', 
  signature='obj', function(obj, attribute.name, attribute.type, edge.names, values) standardGeneric ('setEdgeAttributesDirect'))

setGeneric ('displayGraph', 
  signature='obj', function(obj) standardGeneric ('displayGraph'))
setGeneric ('predictTimeToDisplayGraph', 
  signature='obj', function(obj) standardGeneric ('predictTimeToDisplayGraph'))
setGeneric ('layoutNetwork', 
  signature='obj', function(obj, layout.name='grid') standardGeneric ('layoutNetwork'))
setGeneric ('saveLayout', 
  signature='obj', function(obj, filename, timestamp.in.filename=FALSE) standardGeneric ('saveLayout'))
setGeneric ('restoreLayout', 
  signature='obj', function(obj, filename) standardGeneric ('restoreLayout'))
setGeneric ('setNodePosition', 
  signature='obj', function (obj, node.names, x.coords, y.coords) standardGeneric ('setNodePosition'))
setGeneric ('getNodePosition', 
  signature='obj', function (obj, node.names) standardGeneric ('getNodePosition'))
setGeneric ('getNodeSize', 
  signature='obj', function (obj, node.names) standardGeneric ('getNodeSize'))
setGeneric ('redraw', 
  signature='obj', function (obj) standardGeneric ('redraw'))
setGeneric ('hidePanel', 
  signature='obj', function (obj, panelName) standardGeneric ('hidePanel'))
setGeneric ('hideAllPanels', 
  signature='obj', function (obj) standardGeneric ('hideAllPanels'))
setGeneric ('dockPanel', 
  signature='obj', function (obj, panelName) standardGeneric ('dockPanel'))
setGeneric ('floatPanel', 
  signature='obj', function (obj, panelName) standardGeneric ('floatPanel'))

setGeneric ('setTooltipInitialDelay', 
  signature='obj', function (obj, msecs) standardGeneric ('setTooltipInitialDelay'))
setGeneric ('setTooltipDismissDelay',	
  signature='obj', function (obj, msecs) standardGeneric ('setTooltipDismissDelay'))

setGeneric ('raiseWindow',					
  signature='obj', function (obj, window.title=NA) standardGeneric ('raiseWindow'))
setGeneric ('setWindowSize', 
  signature='obj', function (obj, width, height) standardGeneric ('setWindowSize'))
setGeneric ('showGraphicsDetails', 
  signature='obj', function (obj, new.value) standardGeneric ('showGraphicsDetails'))
setGeneric ('fitContent', 
  signature='obj', function (obj) standardGeneric ('fitContent'))
setGeneric ('fitSelectedContent', 
  signature='obj', function (obj) standardGeneric ('fitSelectedContent'))
setGeneric ('getCenter', 
  signature='obj', function (obj) standardGeneric ('getCenter'))
setGeneric ('setCenter', 
  signature='obj', function (obj, x, y) standardGeneric ('setCenter'))
setGeneric ('getZoom', 
  signature='obj', function (obj) standardGeneric ('getZoom'))
setGeneric ('setZoom', 
  signature='obj', function (obj, new.level) standardGeneric ('setZoom'))
setGeneric ('getViewCoordinates', 
  signature='obj', function (obj) standardGeneric ('getViewCoordinates'))

setGeneric ('getDefaultBackgroundColor', 
   signature='obj', function (obj, vizmap.style.name='default') standardGeneric ('getDefaultBackgroundColor'))
setGeneric ('setDefaultBackgroundColor', 
   signature='obj', function (obj, new.color, vizmap.style.name='default') standardGeneric ('setDefaultBackgroundColor'))

setGeneric ('getDefaultNodeSelectionColor',  
   signature='obj', function (obj, vizmap.style.name='default') standardGeneric ('getDefaultNodeSelectionColor'))
setGeneric ('setDefaultNodeSelectionColor',  
   signature='obj', function (obj, new.color, vizmap.style.name='default') standardGeneric ('setDefaultNodeSelectionColor'))

setGeneric ('getDefaultNodeReverseSelectionColor', 
   signature='obj', function (obj, vizmap.style.name='default') standardGeneric ('getDefaultNodeReverseSelectionColor'))
setGeneric ('setDefaultNodeReverseSelectionColor',  
   signature='obj', function (obj, new.color, vizmap.style.name='default') standardGeneric ('setDefaultNodeReverseSelectionColor'))

setGeneric ('getDefaultEdgeSelectionColor',  
   signature='obj', function (obj, vizmap.style.name='default') standardGeneric ('getDefaultEdgeSelectionColor'))
setGeneric ('setDefaultEdgeSelectionColor', 
   signature='obj', function (obj, new.color,  vizmap.style.name='default') standardGeneric ('setDefaultEdgeSelectionColor'))

setGeneric ('getDefaultEdgeReverseSelectionColor', 
   signature='obj', function (obj, vizmap.style.name='default') standardGeneric ('getDefaultEdgeReverseSelectionColor'))
setGeneric ('setDefaultEdgeReverseSelectionColor', 
   signature='obj', function (obj, new.color, vizmap.style.name='default') standardGeneric ('setDefaultEdgeReverseSelectionColor'))

setGeneric ('saveImage', 
   signature='obj', function (obj, file.name, image.type, scale=1.0) standardGeneric ('saveImage'))
setGeneric ('saveNetwork', 
   signature='obj', function (obj, file.name, format='gml') standardGeneric ('saveNetwork'))

setGeneric ('setDefaultNodeShape',        signature='obj', function (obj, new.shape, vizmap.style.name='default') standardGeneric ('setDefaultNodeShape'))
setGeneric ('setDefaultNodeSize',         signature='obj', function (obj, new.size, vizmap.style.name='default') standardGeneric ('setDefaultNodeSize'))
setGeneric ('setDefaultNodeColor',        signature='obj', function (obj, new.color, vizmap.style.name='default') standardGeneric ('setDefaultNodeColor'))
setGeneric ('setDefaultNodeBorderColor',  signature='obj', function (obj, new.color, vizmap.style.name='default') standardGeneric ('setDefaultNodeBorderColor'))
setGeneric ('setDefaultNodeBorderWidth',  signature='obj', function (obj, new.width, vizmap.style.name='default') standardGeneric ('setDefaultNodeBorderWidth'))
setGeneric ('setDefaultNodeFontSize',     signature='obj', function (obj, new.size, vizmap.style.name='default') standardGeneric ('setDefaultNodeFontSize'))
setGeneric ('setDefaultNodeLabelColor',   signature='obj', function (obj, new.color, vizmap.style.name='default') standardGeneric ('setDefaultNodeLabelColor'))

setGeneric ('setDefaultEdgeLineWidth',    signature='obj', function (obj, new.width, vizmap.style.name='default') standardGeneric ('setDefaultEdgeLineWidth'))
setGeneric ('setDefaultEdgeColor',        signature='obj', function (obj, new.color, vizmap.style.name='default') standardGeneric ('setDefaultEdgeColor'))
setGeneric ('setDefaultEdgeFontSize',     signature='obj', function (obj, new.size, vizmap.style.name='default') standardGeneric ('setDefaultEdgeFontSize'))

setGeneric ('setNodeTooltipRule',       signature='obj', function (obj, node.attribute.name) standardGeneric ('setNodeTooltipRule'))
setGeneric ('setEdgeTooltipRule',       signature='obj', function (obj, edge.attribute.name) standardGeneric ('setEdgeTooltipRule'))
setGeneric ('setNodeLabelRule',         signature='obj', function (obj, node.attribute.name) standardGeneric ('setNodeLabelRule'))
setGeneric ('setEdgeLabelRule',         signature='obj', function (obj, edge.attribute.name) standardGeneric ('setEdgeLabelRule'))

setGeneric ('setNodeColorRule',         signature='obj', 
    function (obj, node.attribute.name, control.points, colors, mode, default.color='#FFFFFF') standardGeneric ('setNodeColorRule'))

setGeneric ('setNodeBorderColorRule',   signature='obj', 
    function (obj, node.attribute.name, control.points, colors, mode, default.color='#000000') standardGeneric ('setNodeBorderColorRule'))

setGeneric ('setNodeBorderWidthRule',   signature='obj', 
    function (obj, node.attribute.name, attribute.values, line.widths, default.width=1) standardGeneric ('setNodeBorderWidthRule'))

setGeneric ('setNodeShapeRule',         signature='obj', 
    function (obj, node.attribute.name, attribute.values, node.shapes, default.shape='ellipse') standardGeneric ('setNodeShapeRule'))
setGeneric ('setNodeSizeRule',          signature='obj', 
    function (obj, node.attribute.name, control.points, node.sizes, mode, default.size=40) standardGeneric ('setNodeSizeRule'))

setGeneric ('setNodeOpacityRule',          signature='obj', 
    function (obj, node.attribute.name, control.points, opacities, mode, aspect='all') standardGeneric ('setNodeOpacityRule'))


setGeneric ('setNodeSizeDirect',          signature='obj', function (obj, node.names, new.sizes) standardGeneric ('setNodeSizeDirect'))
setGeneric ('setNodeLabelDirect',         signature='obj', function (obj, node.names, new.labels) standardGeneric ('setNodeLabelDirect'))
setGeneric ('setNodeFontSizeDirect',      signature='obj', function (obj, node.names, new.sizes) standardGeneric ('setNodeFontSizeDirect'))
setGeneric ('setNodeLabelColorDirect',    signature='obj', function (obj, node.names, new.colors) standardGeneric ('setNodeLabelColorDirect'))
setGeneric ('setNodeWidthDirect',         signature='obj', function (obj, node.names, new.widths) standardGeneric ('setNodeWidthDirect'))
setGeneric ('setNodeHeightDirect',        signature='obj', function (obj, node.names, new.heights) standardGeneric ('setNodeHeightDirect'))
setGeneric ('setNodeShapeDirect',         signature='obj', function (obj, node.names, new.shapes) standardGeneric ('setNodeShapeDirect'))
setGeneric ('setNodeImageDirect',         signature='obj', function (obj, node.names, image.urls) standardGeneric ('setNodeImageDirect'))
setGeneric ('setNodeColorDirect',         signature='obj', function (obj, node.names, new.color) standardGeneric ('setNodeColorDirect'))
setGeneric ('setNodeBorderWidthDirect',   signature='obj', function (obj, node.names, new.sizes) standardGeneric ('setNodeBorderWidthDirect'))
setGeneric ('setNodeBorderColorDirect',   signature='obj', function (obj, node.names, new.color) standardGeneric ('setNodeBorderColorDirect'))

setGeneric ('setNodeOpacityDirect',       signature='obj', function (obj, node.names, new.values) standardGeneric ('setNodeOpacityDirect'))
setGeneric ('setNodeFillOpacityDirect',   signature='obj', function (obj, node.names, new.values) standardGeneric ('setNodeFillOpacityDirect'))
setGeneric ('setNodeLabelOpacityDirect',  signature='obj', function (obj, node.names, new.values) standardGeneric ('setNodeLabelOpacityDirect'))
setGeneric ('setNodeBorderOpacityDirect', signature='obj', function (obj, node.names, new.values) standardGeneric ('setNodeBorderOpacityDirect'))
setGeneric ('setEdgeOpacityDirect',         signature='obj', function (obj, edge.names, new.values) standardGeneric ('setEdgeOpacityDirect'))

#setGeneric ('setNodeOpacitiesDirect',       signature='obj', function (obj, node.names, new.values) standardGeneric ('setNodeOpacitiesDirect'))
#setGeneric ('setNodeFillOpacitiesDirect',   signature='obj', function (obj, node.names, new.values) standardGeneric ('setNodeFillOpacitiesDirect'))
#setGeneric ('setNodeLabelOpacitiesDirect',  signature='obj', function (obj, node.names, new.values) standardGeneric ('setNodeLabelOpacitiesDirect'))
#setGeneric ('setNodeBorderOpacitiesDirect', signature='obj', function (obj, node.names, new.values) standardGeneric ('setNodeBorderOpacitiesDirect'))
#setGeneric ('setEdgeOpacitiesDirect',       signature='obj', function (obj, edge.names, new.values) standardGeneric ('setEdgeOpacitiesDirect'))

setGeneric ('setEdgeColorDirect', signature='obj', function (obj, edge.names, new.value) standardGeneric ('setEdgeColorDirect'))
setGeneric ('setEdgeLabelDirect', signature='obj', function (obj, edge.names, new.value) standardGeneric ('setEdgeLabelDirect'))
setGeneric ('setEdgeFontFaceDirect', signature='obj', function (obj, edge.names, new.value) standardGeneric ('setEdgeFontFaceDirect'))
setGeneric ('setEdgeFontSizeDirect', signature='obj', function (obj, edge.names, new.value) standardGeneric ('setEdgeFontSizeDirect'))
setGeneric ('setEdgeLabelColorDirect', signature='obj', function (obj, edge.names, new.value) standardGeneric ('setEdgeLabelColorDirect'))
setGeneric ('setEdgeTooltipDirect', signature='obj', function (obj, edge.names, new.values) standardGeneric ('setEdgeTooltipDirect'))
setGeneric ('setEdgeLineWidthDirect', signature='obj', function (obj, edge.names, new.value) standardGeneric ('setEdgeLineWidthDirect'))
setGeneric ('setEdgeLineStyleDirect', signature='obj', function (obj, edge.names, new.values) standardGeneric ('setEdgeLineStyleDirect'))
setGeneric ('setEdgeSourceArrowShapeDirect', signature='obj', function (obj, edge.names, new.values) standardGeneric ('setEdgeSourceArrowShapeDirect'))
setGeneric ('setEdgeTargetArrowShapeDirect', signature='obj', function (obj, edge.names, new.values) standardGeneric ('setEdgeTargetArrowShapeDirect'))
setGeneric ('setEdgeSourceArrowColorDirect', signature='obj', function (obj, edge.names, new.colors) standardGeneric ('setEdgeSourceArrowColorDirect'))
setGeneric ('setEdgeTargetArrowColorDirect', signature='obj', function (obj, edge.names, new.colors) standardGeneric ('setEdgeTargetArrowColorDirect'))
setGeneric ('setEdgeLabelOpacityDirect', signature='obj', function (obj, edge.names, new.value) standardGeneric ('setEdgeLabelOpacityDirect'))
#setGeneric ('setEdgeLabelPositionDirect', signature='obj', function (obj, edge.names, new.value) standardGeneric ('setEdgeLabelPositionDirect'))
setGeneric ('setEdgeLabelWidthDirect', signature='obj', function (obj, edge.names, new.value) standardGeneric ('setEdgeLabelWidthDirect'))


setGeneric ('setEdgeLineStyleRule',     signature='obj', 
    function (obj, edge.attribute.name, attribute.values, line.styles, default.style='SOLID') standardGeneric ('setEdgeLineStyleRule'))

setGeneric ('setEdgeLineWidthRule', signature='obj', 
    function (obj, edge.attribute.name, attribute.values, line.widths, default.width='1') standardGeneric ('setEdgeLineWidthRule'))

setGeneric ('setEdgeTargetArrowRule',   signature='obj', 
    function (obj, edge.attribute.name, attribute.values, arrows, default='Arrow') standardGeneric ('setEdgeTargetArrowRule'))
setGeneric ('setEdgeSourceArrowRule',   signature='obj', 
    function (obj, edge.attribute.name, attribute.values, arrows, default='Arrow') standardGeneric ('setEdgeSourceArrowRule'))

setGeneric ('setEdgeTargetArrowColorRule',   signature='obj', 
    function (obj, edge.attribute.name, attribute.values, colors, default.color='#000000') standardGeneric ('setEdgeTargetArrowColorRule'))
setGeneric ('setEdgeSourceArrowColorRule',   signature='obj', 
    function (obj, edge.attribute.name, attribute.values, colors, default.color='#000000') standardGeneric ('setEdgeSourceArrowColorRule'))

setGeneric ('setEdgeColorRule',         signature='obj',
    function (obj, edge.attribute.name, control.points, colors, mode, default.color='#FFFFFF') standardGeneric ('setEdgeColorRule'))

setGeneric ('setEdgeOpacityRule',          signature='obj', 
    function (obj, edge.attribute.name, control.points, opacities, mode) standardGeneric ('setEdgeOpacityRule'))


setGeneric ('getNodeCount',             signature='obj', function (obj) standardGeneric ('getNodeCount'))
setGeneric ('getEdgeCount',             signature='obj', function (obj) standardGeneric ('getEdgeCount'))
setGeneric ('getNodeAttribute',         signature='obj', function (obj, node.name, attribute.name) standardGeneric ('getNodeAttribute'))
setGeneric ('getNodeAttributeType',     signature='obj', function (obj, attribute.name) standardGeneric ('getNodeAttributeType'))
setGeneric ('getAllNodeAttributes',     signature='obj', function (obj, onlySelectedNodes=FALSE) standardGeneric ('getAllNodeAttributes'))
setGeneric ('getEdgeAttribute',         signature='obj', function (obj, edge.name, attribute.name) standardGeneric ('getEdgeAttribute'))
setGeneric ('getEdgeAttributeType',     signature='obj', function (obj, attribute.name) standardGeneric ('getEdgeAttributeType'))
setGeneric ('getAllEdgeAttributes',     signature='obj', function (obj, onlySelectedEdges=FALSE) standardGeneric ('getAllEdgeAttributes'))
setGeneric ('getNodeAttributeNames',    signature='obj', function (obj) standardGeneric ('getNodeAttributeNames'))
setGeneric ('getEdgeAttributeNames',    signature='obj', function (obj) standardGeneric ('getEdgeAttributeNames'))
setGeneric ('deleteNodeAttribute',      signature='obj', function (obj, attribute.name) standardGeneric ('deleteNodeAttribute'))
setGeneric ('deleteEdgeAttribute',      signature='obj', function (obj, attribute.name) standardGeneric ('deleteEdgeAttribute'))
setGeneric ('getAllNodes',              signature='obj', function (obj) standardGeneric ('getAllNodes'))
setGeneric ('getAllEdges',              signature='obj', function (obj) standardGeneric ('getAllEdges'))
setGeneric ('selectNodes',              signature='obj', function (obj, node.names, preserve.current.selection=TRUE) standardGeneric ('selectNodes'))
setGeneric ('getSelectedNodes',         signature='obj', function (obj) standardGeneric ('getSelectedNodes'))
setGeneric ('clearSelection',           signature='obj', function (obj) standardGeneric ('clearSelection'))
setGeneric ('getSelectedNodeCount',     signature='obj', function (obj) standardGeneric ('getSelectedNodeCount'))
setGeneric ('hideNodes',                signature='obj', function (obj, node.names) standardGeneric ('hideNodes'))
# setGeneric ('unhideNodes',              signature='obj', function (obj, node.names) standardGeneric ('unhideNodes'))
setGeneric ('hideSelectedNodes',        signature='obj', function (obj) standardGeneric ('hideSelectedNodes'))
setGeneric ('invertNodeSelection',      signature='obj', function (obj) standardGeneric ('invertNodeSelection'))
setGeneric ('deleteSelectedNodes',      signature='obj', function (obj) standardGeneric ('deleteSelectedNodes'))

setGeneric ('selectEdges',              signature='obj', function (obj, edge.names, preserve.current.selection=TRUE) standardGeneric ('selectEdges'))
setGeneric ('invertEdgeSelection',      signature='obj', function (obj) standardGeneric ('invertEdgeSelection'))
setGeneric ('deleteSelectedEdges',      signature='obj', function (obj) standardGeneric ('deleteSelectedEdges'))

setGeneric ('getSelectedEdges',         signature='obj', function (obj) standardGeneric ('getSelectedEdges'))
setGeneric ('clearSelection',           signature='obj', function (obj) standardGeneric ('clearSelection'))
setGeneric ('getSelectedEdgeCount',     signature='obj', function (obj) standardGeneric ('getSelectedEdgeCount'))
setGeneric ('hideSelectedEdges',        signature='obj', function (obj) standardGeneric ('hideSelectedEdges'))

setGeneric ('unhideAll', 
   signature='obj', function (obj) standardGeneric ('unhideAll'))
setGeneric ('getFirstNeighbors', 
   signature='obj', function (obj, node.names) standardGeneric ('getFirstNeighbors'))
setGeneric ('RCy3.getFirstNeighbors', 
   signature='obj', function (obj, node.names) standardGeneric ('RCy3.getFirstNeighbors'))
setGeneric ('selectFirstNeighborsOfSelectedNodes',
   signature='obj', function (obj) standardGeneric ('selectFirstNeighborsOfSelectedNodes'))
setGeneric ('sfn', 
   signature='obj', function (obj) standardGeneric ('sfn'))

#-----------------------------------------------------------
# methods related to transmitting data from Cytoscape to R
#-----------------------------------------------------------
setGeneric ('getWindowID', 
  signature='obj', function (obj, window.title) standardGeneric ('getWindowID'))
setGeneric ('haveNodeAttribute', 
  signature='obj', function (obj, node.names, attribute.name) standardGeneric ('haveNodeAttribute'))
setGeneric ('haveEdgeAttribute', 
  signature='obj', function (obj, edge.names, attribute.name) standardGeneric ('haveEdgeAttribute'))
setGeneric ('copyNodeAttributesFromCyGraph', 
  signature='obj', function (obj, window.id, existing.graph) standardGeneric ('copyNodeAttributesFromCyGraph'))
setGeneric ('copyEdgeAttributesFromCyGraph', 
  signature='obj', function (obj, window.id, existing.graph) standardGeneric ('copyEdgeAttributesFromCyGraph'))
setGeneric ('getGraphFromCyWindow', 
  signature='obj', function (obj, window.title) standardGeneric ('getGraphFromCyWindow'))

#-----------------------------------------------------------
# methods related to visual styles
#-----------------------------------------------------------
setGeneric ('getVisualStyleNames', 
   signature='obj', function (obj) standardGeneric ('getVisualStyleNames'))
setGeneric ('copyVisualStyle', 
   signature='obj', function (obj, from.style, to.style) standardGeneric ('copyVisualStyle'))
setGeneric ('setVisualStyle', 
   signature='obj', function (obj, new.style.name) standardGeneric ('setVisualStyle'))
setGeneric ('lockNodeDimensions', 
   signature='obj', function (obj, new.state, visual.style.name='default') standardGeneric ('lockNodeDimensions'))

#-----------------------------------------------------------
# private methods, for internal use only
#-----------------------------------------------------------
setGeneric ('.addNodes', 
   signature='obj', function (obj, other.graph) standardGeneric ('.addNodes'))
setGeneric ('.addEdges', 
   signature='obj', function (obj, other.graph) standardGeneric ('.addEdges'))
setGeneric ('.getWindowNameFromSUID', 
   signature='obj', function (obj, win.suid) standardGeneric ('.getWindowNameFromSUID'))
setGeneric ('.getNetworkViews', 
   signature='obj', function (obj) standardGeneric ('.getNetworkViews'))
setGeneric ('.nodeNameToNodeSUID',
   signature='obj', function (obj, node.names) standardGeneric ('.nodeNameToNodeSUID'))
setGeneric ('.nodeSUIDToNodeName', 
   signature='obj', function (obj, node.suids) standardGeneric ('.nodeSUIDToNodeName'))
setGeneric ('.edgeNameToEdgeSUID',
   signature='obj', function (obj, edge.names) standardGeneric ('.edgeNameToEdgeSUID'))
setGeneric ('.edgeSUIDToEdgeName', 
   signature='obj', function (obj, edge.suids) standardGeneric ('.edgeSUIDToEdgeName'))

# ------------------------------------------------------------------------------
setValidity("CytoscapeWindowClass", 
   function(object) {
      if(length(object@title) != 1) 
         "'title' is not a single string" 
      else if(!nzchar(object@title)) 
         "'title' is an empty string" 
      validObject(object@graph)
})
## END setValidity

# ------------------------------------------------------------------------------
CytoscapeConnection = function(host='localhost', port=1234) {
    uri = sprintf('http://%s:%s', host, port)
    cc = new('CytoscapeConnectionClass', uri = uri)
    if(!url.exists(uri)) {
        write(sprintf("Connection failed. Please ensure that you have Cytoscape running and CyREST installed."), stderr())
        return()
    }
    return(cc)
}
## END CytoscapeConnection

# ------------------------------------------------------------------------------
# 'CytoscapeWindow' constructor, defined as simple function
CytoscapeWindow = 
    function(title, graph=new('graphNEL', edgemode='directed'), host='localhost', port=1234, 
             create.window=TRUE, overwriteWindow=FALSE, collectTimings=FALSE) 
{
        uri = sprintf('http://%s:%s', host, port)
        # new 'CytoscapeConnectionClass' object
        cy.conn = CytoscapeConnection(host, port)
        
        check.cytoscape.plugin.version(cy.conn)
        # if the user has specified, delete already existing window(s) with the same title
        if(overwriteWindow) {
            if(title %in% as.character(getWindowList(cy.conn))) {
                deleteWindow(cy.conn, title)
            }
        }
        
        if(!is.na(getWindowID(cy.conn, title))) {
            write(sprintf("A window named '%s' already exists in Cytoscape. Please, use a unique window name, or set 'overwriteWindow=TRUE'", title), stderr())
            write(sprintf("Please, use "), stderr())
            stop("")
            
            # write(sprintf('There is already a window in Cytoscape named "%s".', title), stderr())
            # write(sprintf('Please use a unique name, or set "overwriteWindow=TRUE".'), stderr())
            # stop("check")
        }
  
  if(is.classic.graph(graph)) 
    if(edgemode(graph) == 'undirected') {
      graph = remove.redundancies.in.undirected.graph(graph)
    }
  # are all node attributes properly initialized?
  node.attributes = noa.names(graph)
  if(length(node.attributes) > 0) {
    check.list = list()
    for(node.attribute in node.attributes) {
      check.list[[node.attribute]] = properlyInitializedNodeAttribute(graph, node.attribute)
    }
    uninitialized.attributes = which(check.list == FALSE)
    if(length(uninitialized.attributes) > 0) {
      write(sprintf("%d uninitialized node attribute/s", length(uninitialized.attributes)), stderr())
      return()
    }
  } # if node.attributes

  # are all edge attributes properly initialized?
  edge.attributes = eda.names(graph)
  if(length(edge.attributes) > 0) {
    check.list = list()
    for(edge.attribute in edge.attributes) {
      check.list[[edge.attribute]] = properlyInitializedEdgeAttribute(graph, edge.attribute)
    }
    uninitialized.attributes = which(check.list == FALSE)
    if(length(uninitialized.attributes) > 0) {
      write(sprintf("%d uninitialized edge attribute/s", length(uninitialized.attributes)), stderr())
      return()
    }
  } # if edge.attributes
  
  if(!'label' %in% noa.names(graph)) {
    write('nodes have no label attribute -- adding default labels', stderr())
    graph = initNodeAttribute(graph, 'label', 'char', 'noLabel')
    if(length(nodes(graph) > 0)) {
      nodeData(graph, nodes(graph), 'label') = nodes(graph) # nodes(graph) returns strings
    }
  }
  # create new 'CytoscapeWindow' object
  cw = new('CytoscapeWindowClass', title=title, graph=graph, uri=uri, 
           collectTimings=collectTimings, suid.name.dict=list(), edge.suid.name.dict=list())
  
  if(create.window) {
    cw@window.id = createWindow(cw)
  }
  cw@collectTimings = collectTimings
  
  return (cw)
} 
## END 'CytsoscapeWindow' constructor

# ------------------------------------------------------------------------------
existing.CytoscapeWindow = 
    function(title, host='localhost', port=1234, copy.graph.from.cytoscape.to.R=FALSE)
        {
        uri = sprintf('http://%s:%s', host, port)
        # create this (inexpensively) just to gain access to the window list
        cy.conn = CytoscapeConnection(host, port)
        check.cytoscape.plugin.version(cy.conn)
        
        existing.window.id = as.character(getWindowID(cy.conn, title))
        # inform the user if the desired window does not exist
        if(is.na(existing.window.id)) {
            write(sprintf("WARNING in RCy3::existing.CytoscapeWindow():\n\t there is no window in Cytoscape named '%s' >> please, choose from the following titles: ", title), stderr())
            write(as.character(getWindowList(cy.conn)), stderr())
            return(NA)
        }
        
        # get graph from Cytoscape
        cy.window = new('CytoscapeWindowClass', title=title, window.id=existing.window.id, uri=uri)
        
        if(copy.graph.from.cytoscape.to.R) {
            g.cy = getGraphFromCyWindow(cy.window, title)
            cy.window = setGraph(cy.window, g.cy)
        }
        
        return(cy.window)
} 
## END existing.CytsoscapeWindow

# ------------------------------------------------------------------------------
check.cytoscape.plugin.version = function(cyCon) 
{
  plugin.version.string = pluginVersion(cyCon)
  string.tmp1 = strsplit(plugin.version.string, ' ')[[1]][1]
  string.tmp2 = gsub('[a-z]', '', string.tmp1)
  string.tmp3 = gsub('[A-Z]', '', string.tmp2)
  plugin.version = as.numeric(string.tmp3)
  
  expected.version = 1
  
  if(plugin.version < expected.version) { 
    write(' ', stderr())
    write(sprintf('This version of the RCytoscape package requires CyREST plugin version %s or greater.', expected.version), 
          stderr ())
    write(sprintf('However, you are using version %s. You must upgrade.', plugin.version), stderr ())
    write('Please visit the plugins page at http://www.cytoscape.org.', stderr ())
    write(' ', stderr())
    stop('Wrong CyREST version.')
  }
} 
## END check.cytoscape.plugin.version

# ------------------------------------------------------------------------------
setMethod('ping', signature = 'CytoscapeConnectionClass', 
   function(obj) {
      resource.uri = paste(obj@uri, pluginVersion(obj), sep="/")
      request.res = GET(url=resource.uri)
      apiVersion = fromJSON(rawToChar(request.res$content))$apiVersion
      
      if(length(apiVersion) > 0) {
         return("It works!")
      } else {
         return("RCy3 Error: cyREST connection problem!")
      }
})
## END ping

# ------------------------------------------------------------------------------
setMethod('pluginVersion', 'CytoscapeConnectionClass', 
   function(obj) {
      request.res = GET(url=obj@uri)
      # get vector with available plugin versions
      available.api.versions = 
         fromJSON(rawToChar(request.res$content))$availableApiVersion
      
      api.version = character(0)
      
      # loop through the available plugin versions and pick the current one
      for(i in 1:length(available.api.versions)) {
         server.status = getServerStatus(obj, available.api.versions[i])
         
         if(server.status$status_code == 200) {
            api.version = fromJSON(rawToChar(server.status$content))$apiVersion
         }
      }
      # current api.version will be the highest/latest version
      return(api.version)
})
## END pluginVersion

# ------------------------------------------------------------------------------
setMethod('getServerStatus', 'CytoscapeConnectionClass',
   function(obj, api.version) {
      request.uri = paste(obj@uri, api.version, sep="/")
      request.res = GET(url=request.uri)
      return(request.res)
})
## END getServerStatus

# ------------------------------------------------------------------------------
setMethod('msg', 'CytoscapeConnectionClass', 
   function(obj, string) { 
      # invisible (xml.rpc (obj@uri, 'Cytoscape.setStatusBarMessage', string))
})
## END msg

# ------------------------------------------------------------------------------
setMethod('clearMsg', 'CytoscapeConnectionClass', 
   function(obj) {
      # invisible (xml.rpc (obj@uri, 'Cytoscape.clearStatusBarMessage'))
})
## END clearMsg

# ------------------------------------------------------------------------------
setMethod('createWindow', 'CytoscapeWindowClass', 
  function(obj) {
    obj@graph@graphData$name = obj@title
    graph.attributes = obj@graph@graphData
    graph.elements = list(nodes=list(), edges=list())
    
    cygraph = toJSON(list(data=graph.attributes, elements=graph.elements))
    resource.uri = paste(obj@uri, pluginVersion(obj), "networks", sep="/")
    request.res = POST(url=resource.uri, body=cygraph, encode="json")
    window.id = unname(fromJSON(rawToChar(request.res$content)))
    
    return(as.character(window.id))
})
## END createWindow

# ------------------------------------------------------------------------------
setMethod('createWindowFromSelection', 'CytoscapeWindowClass', function (obj, new.windowTitle, return.graph=FALSE) {
#    if (getSelectedNodeCount (obj) == 0) {
#      write (noquote ('RCytoscape::createWindowFromSelection error:  no nodes are selected'), stderr ())
#      return (NA)
#      }
#    if (new.windowTitle %in% as.character (getWindowList (obj))) {
#      msg = sprintf ('RCytoscape::createWindowFromSelection error:  window "%s" already exists', new.windowTitle)
#      write (noquote (msg), stderr ())
#      return (NA)
#      }
#      
#    window.id = xml.rpc (obj@uri, 'Cytoscape.createNetworkFromSelection', obj@window.id, new.windowTitle)
#    return (existing.CytoscapeWindow (new.windowTitle, copy.graph.from.cytoscape.to.R = return.graph))
}) # createWindowFromSelection

# ------------------------------------------------------------------------------
setMethod('getWindowCount', 'CytoscapeConnectionClass',
   function(obj) {
      resource.uri = paste(obj@uri, pluginVersion(obj), "networks/count", sep="/")
      request.res = GET(url=resource.uri)
      num.cytoscape.windows = unname(fromJSON(rawToChar(request.res$content)))
      return(as.integer(num.cytoscape.windows))
})
## END getWindowCount

# ------------------------------------------------------------------------------
setMethod('getWindowID', 'CytoscapeConnectionClass', 
   function(obj, window.title) {
      resource.uri = paste(obj@uri, pluginVersion(obj), "networks", sep="/")
      request.res = GET(url=resource.uri)
      # list of the existing Cytoscape networks SUIDs
      cy.window.SUIDs = fromJSON(rawToChar(request.res$content))
      
      for(win.SUID in cy.window.SUIDs) {
         win.name = .getWindowNameFromSUID(obj, win.SUID)
         if(win.name == window.title) {
            return(win.SUID)
         }
      }
      # [GIK - 26 Apr, 2015] below print has been commented since it is not appropriate for this function
      # write(sprintf("Cytoscape window named '%s' does not exist yet", window.title), stderr())
      return(NA)
})
## END getWindowID

# ------------------------------------------------------------------------------
setMethod('getWindowList', 'CytoscapeConnectionClass', 
   function(obj) {
      if(getWindowCount(obj) == 0) {
         return(c())
      }
      
      resource.uri = paste(obj@uri, pluginVersion(obj), "networks", sep="/")
      request.res = GET(url=resource.uri)
      # list of the existing Cytoscape networks SUIDs
      cy.window.SUIDs = fromJSON(rawToChar(request.res$content))
      # list of the existing Cytoscape networks names (empty)
      cy.window.names = c()
      
      for(win.SUID in cy.window.SUIDs) {
         win.name = .getWindowNameFromSUID(obj, win.SUID)
         cy.window.names = c(cy.window.names, win.name)
      }
      return(cy.window.names)
})
## END getWindowList

# ------------------------------------------------------------------------------
setMethod('deleteWindow', 'CytoscapeConnectionClass',
  function (obj, window.title=NA) {
    if(!is.na(window.title)) {
       print("check1")
       window.id = getWindowID(obj, window.title)
    } else if(class(obj) == 'CytoscapeWindowClass') {
       print("check2")
       window.id = as.character(obj@window.id)
    } else {
      write(sprintf('RCy::deleteWindow error. You must provide a valid 
                    CytoscapeWindow object, or a CytoscapeConnection object and 
                    a window title'), stderr())
      return()
    }
    
    resource.uri = paste(obj@uri, pluginVersion(obj), "networks", window.id, sep="/")
    request.res = DELETE(url=resource.uri)
    invisible(request.res)
})

# ------------------------------------------------------------------------------
# deletes all networks and associated windows in cytoscape
setMethod('deleteAllWindows', 'CytoscapeConnectionClass', 
   function(obj) {
      resource.uri = paste(obj@uri, pluginVersion(obj), "networks", sep="/")
      request.res = DELETE(url=resource.uri)
      invisible(request.res)
})
## END deleteAllWindows

# ------------------------------------------------------------------------------
setMethod('getNodeShapes', 'CytoscapeConnectionClass', 
   function(obj) {
      resource.uri = paste(obj@uri, pluginVersion(obj), "styles/visualproperties/NODE_SHAPE/values", sep="/")
      request.res = GET(url=resource.uri)
      request.res = fromJSON(rawToChar(request.res$content))
      return(request.res$values)
})
## END getNodeShapes

# ------------------------------------------------------------------------------
setMethod('getDirectlyModifiableVisualProperties', 'CytoscapeConnectionClass', 
   function(obj) {
      resource.uri = paste(obj@uri, pluginVersion(obj), "styles", as.character(vizmap.style.name), "defaults", sep="/")
      request.res = GET(url=resource.uri)
      visual.properties = unname(fromJSON(rawToChar(request.res$content))[[1]])
      visual.properties = sapply(visual.properties, '[[', 1)
      return(visual.properties)
})
## END getDirectlyModifiableVisualProperties

# ------------------------------------------------------------------------------
# returns the names of recognized and supported attribute class/type names
setMethod('getAttributeClassNames', 'CytoscapeConnectionClass', 
   function(obj) {
      return(c('floating|numeric|double', 'integer|int', 'string|char|character'))
})
## END getAttributeClassNames

# ------------------------------------------------------------------------------
setMethod('getLineStyles', 'CytoscapeConnectionClass', 
   function(obj) {
      resource.uri = paste(obj@uri, pluginVersion(obj), "styles/visualproperties/EDGE_LINE_TYPE/values", sep="/")
      request.res = GET(url=resource.uri)
      request.res = fromJSON(rawToChar(request.res$content))
      return(request.res$values)
})
## END getLineStyles

# ------------------------------------------------------------------------------
setMethod('getArrowShapes', 'CytoscapeConnectionClass', 
   function(obj) {
      resource.uri = paste(obj@uri, pluginVersion(obj), "styles/visualproperties/EDGE_TARGET_ARROW_SHAPE/values", sep="/")
      # Comment TanjaM: EDGE_SOURCE_ARROW_SHAPE rather than TARGET returns the same results as of April 2015
      request.res = GET(url=resource.uri)
      request.res = fromJSON(rawToChar(request.res$content))
      return(request.res$values)
})
## END getArrowShapes

# ------------------------------------------------------------------------------
setMethod('getLayoutNames', 'CytoscapeConnectionClass', 
  function(obj) {
    request.uri = paste(obj@uri, pluginVersion(obj), "apply/layouts", sep="/")
    request.res = GET(url=request.uri)
    available.layouts = unname(fromJSON(rawToChar(request.res$content)))
    
    return(available.layouts)
})
## END getLayoutNames

# ------------------------------------------------------------------------------
setMethod('getLayoutNameMapping', 'CytoscapeConnectionClass', 
   function(obj) {
      ### for implementation ... waiting for cyREST API upgrade
}) 
## END getLayoutNameMapping

# ------------------------------------------------------------------------------
setMethod('getLayoutPropertyNames', 'CytoscapeConnectionClass', 
   function(obj, layout.name) {
      ### for implementation ... waiting for cyREST API upgrade
}) 
## END getLayoutProperties

# ------------------------------------------------------------------------------
setMethod('getLayoutPropertyType', 'CytoscapeConnectionClass', 
   function(obj, layout.name, property.name) {
      ### for implementation ... waiting for cyREST API upgrade
}) 
## END getLayoutPropertyType

# ------------------------------------------------------------------------------
setMethod('getLayoutPropertyValue', 'CytoscapeConnectionClass', 
   function(obj, layout.name, property.name) {
      ### for implementation ... waiting for cyREST API upgrade
}) 
## END getLayoutPropertyValue

# ------------------------------------------------------------------------------
setMethod('setLayoutProperties', 'CytoscapeConnectionClass', 
   function(obj, layout.name, properties.list) {
      all.possible.props = getLayoutPropertyNames(obj, layout.name)
      ### for implementation ... waiting for getLayoutPropertyNames()
}) 
## END setLayoutProperties

# ------------------------------------------------------------------------------
setMethod('setGraph', 'CytoscapeWindowClass', 
    function(obj, graph) {
        if(edgemode(graph) == 'undirected') {
            graph = remove.redundancies.in.undirected.graph (graph)
        }
        obj@graph = graph
        return(obj)
})
## END setGraph

# ------------------------------------------------------------------------------
setMethod('getGraph', 'CytoscapeWindowClass', 
    function(obj) {
        return(obj@graph)
})
## END getGraph

# ------------------------------------------------------------------------------
# in Cytoscape, node attributes are administered on a global level.  In addition, and in contrast to R, not all nodes in a graph
# will have a specific attribute define on it.  (In R, every node has every attribute)
# this function returns a list of nodes for which the specified attribute has a value in the corresponding Cytoscape network
setMethod('haveNodeAttribute', 'CytoscapeConnectionClass', 
    function(obj, node.names, attribute.name) {
        
        net.SUID = as.character(obj@window.id)
        version = pluginVersion(obj)
        # check the attribute exists
        if(attribute.name %in% getNodeAttributeNames(obj)) {
            # get the node SUIDs
            node.SUIDs = .nodeNameToNodeSUID(obj, node.names)
            nodes.that.have.attribute = c()
            
            for(i in 1:length(node.SUIDs)) {
                resource.uri = paste(obj@uri, version, "networks", net.SUID, "tables/defaultnode/rows", as.character(node.SUIDs[i]), attribute.name, sep="/")
                request.res = GET(url=resource.uri)
                node.attribute.value = rawToChar(request.res$content)
                
                if(nchar(node.attribute.value) > 0) {
                    nodes.that.have.attribute = c(nodes.that.have.attribute, node.SUIDs[i])
                }
            }
            
            return(as.character(.nodeSUIDToNodeName(obj, nodes.that.have.attribute)))
        } else {
            write(sprintf("Error: '%s' is not an existing node attribute name", attribute.name), stderr())
        }
})
## END haveNodeAttribute

#------------------------------------------------------------------------------------------------------------------------
# in Cytoscape, attributes are administered on a global level.  In addition, and in contrast to R, not all nodes in a graph
# will have a specific attribute define on it.  (In R, every node has every attribute)
# this function returns a list of nodes for which the specified attribute has a value in the corresponding Cytoscape network
setMethod('haveEdgeAttribute', 'CytoscapeConnectionClass', 
    function(obj, edge.names, attribute.name) {
        net.SUID = as.character(obj@window.id)
        version = pluginVersion(obj)
        
        if(attribute.name %in% getEdgeAttributeNames(obj)) {
            edge.SUIDs = .edgeNameToEdgeSUID(obj, edge.names)
            edges.that.have.attribute = c()
            
            for(i in 1:length(edge.SUIDs)) {
                resource.uri = paste(obj@uri, version, "networks", net.SUID, "tables/defaultedge/rows", as.character(edge.SUIDs[i]), attribute.name, sep="/")
                request.res = GET(url=resource.uri)
                edge.attribute.value = rawToChar(request.res$content)
                
                if(nchar(edge.attribute.value) > 0) {
                    edges.that.have.attribute = c(edges.that.have.attribute, edge.SUIDs[i])
                }
            }
            
            return(as.character(.edgeSUIDToEdgeName(obj, edges.that.have.attribute)))
        } else {
            write(sprintf("Error: '%s' is no an existing edge attribute name", attribute.name), stderr())
        }
})
## END haveEdgeAttribute

# ------------------------------------------------------------------------------
setMethod('copyNodeAttributesFromCyGraph', 'CytoscapeConnectionClass', 
    function(obj, window.id, existing.graph) {
        net.SUID = as.character(obj@window.id)
        version = pluginVersion(obj)
        
        node.attribute.names = getNodeAttributeNames(obj)
        
        for(attribute.name in node.attribute.names) {
            known.node.names = sapply(obj@suid.name.dict, function(n) { n$name })
            # nodes that store values for this attribute (meaning the value is not empty)
            nodes.with.attribute = haveNodeAttribute(obj, known.node.names, attribute.name)
            if(length(nodes.with.attribute) > 0) {
                attribute.type = getNodeAttributeType(obj, attribute.name)
                
                write(sprintf("\t retrieving attribute '%s' values for %d nodes", attribute.name, length(nodes.with.attribute)), stderr())
                # write(sprintf("\t retrieving %s '%s' attribute for %d nodes", attribute.type, attribute.name, length(nodes.with.attribute)), stderr())
                if(attribute.type == 'Integer') {
                    attribute.type = 'integer'
                    default.value = as.integer(0)
                } else if(attribute.type == 'String') {
                    attribute.type = 'char'
                    default.value = as.character('unassigned')
                } else if(attribute.type == 'Double') {
                    attribute.type = 'numeric'
                    default.value = as.numeric(0.0)
                } else if(attribute.type == 'Boolean') {
                    attribute.value = 'boolean'
                    default.value = as.logical(FALSE)
                } else {
                    write(sprintf('RCy3::copyNodeAttributesFromCyGraph, no support yet for attributes of type %s', attribute.type), stderr())
                    next()
                }
                existing.graph = 
                    initNodeAttribute(existing.graph, attribute.name, attribute.type, default.value)
                
                attribute.values = c()
                
                for(i in 1:length(nodes.with.attribute)) {
                    attribute.values = c(attribute.values, getNodeAttribute(obj, nodes.with.attribute[i], attribute.name))
                }
                nodeData(existing.graph, nodes.with.attribute, attribute.name) = attribute.values
            } ## END if there are nodes that have values for the attribute
        } ## END for loop : looping through each node attribute
        return(existing.graph)
})
## END copyNodeAttributesFromCyGraph

# ------------------------------------------------------------------------------
setMethod('copyEdgeAttributesFromCyGraph', 'CytoscapeConnectionClass', 
    function(obj, window.id, existing.graph) {
        net.SUID = as.character(obj@window.id)
        version = pluginVersion(obj)
        
        edge.attribute.names = getEdgeAttributeNames(obj)
        
        cy2.edgenames = as.character(cy2.edge.names(existing.graph)) # < 2 seconds for > 9000 edges
        
        for(attribute.name in edge.attribute.names) {
            edges.with.attribute = haveEdgeAttribute(obj, cy2.edgenames, attribute.name)
            
            if(length(edges.with.attribute) > 0) {
                attribute.type = getEdgeAttributeType(obj, attribute.name) 
                
                write(sprintf("\t retrieving attribute '%s' values for %d edges", attribute.name, length(edges.with.attribute)), stderr())
                if(attribute.type == 'Integer') {
                    attribute.type = 'integer' 
                    default.value = 0
                } else if(attribute.type == 'String') {
                    attribute.type = 'char'
                    default.value = 'unassigned'
                } else if(attribute.type == 'Double') {
                    attribute.type = 'numeric' 
                    default.value = as.numeric(0.0)
                } else {
                    write(sprintf('RCy3::copyEdgeAttributesFromCyGraph, no support yet for attributes of type %s', attribute.type), stderr())
                    next()
                }
                existing.graph = 
                    initEdgeAttribute(existing.graph, attribute.name, attribute.type, default.value)
                eda.values = c()
                
                for(i in 1:length(edges.with.attribute)) {
                    eda.values = c(eda.values, getEdgeAttribute(obj, edges.with.attribute[i], attribute.name))
                }
                
                regex = ' *[\\(|\\)] *'
                edges.tokens = strsplit(edges.with.attribute, regex)
                source.nodes = unlist(lapply(edges.tokens, function(tokens) tokens[1]))
                target.nodes = unlist(lapply(edges.tokens, function(tokens) tokens[3]))
                edge.types = unlist(lapply(edges.tokens, function(tokens) tokens[2])) 
                
                edgeData(existing.graph, source.nodes, target.nodes, attribute.name) = eda.values
                
                # for(i in 1:length(edgeData(existing.graph, from=source.nodes, to=target.nodes, attr=attribute.name))) {
                #     attr(edgeData(existing.graph, from=source.nodes, to=target.nodes, attr=attribute.name)[[i]], 'class') = 
                #         getEdgeAttributeType(obj, attribute.name)
                # }
            } ## END if
        } ## END for
        
        return(existing.graph)
})
## END copyEdgeAttributesFromCyGraph


# ------------------------------------------------------------------------------
setMethod('getGraphFromCyWindow', 'CytoscapeConnectionClass', 
    function(obj, window.title) {
        # handles the case when 'obj' is 'CytoscapeConnectionClass', instead of 'CytoscapeWindowClass' 
        if(class(obj) == "CytoscapeConnectionClass") {
            loc.obj = 
                new('CytoscapeWindowClass', title=window.title, window.id = as.character(getWindowID(obj, window.title)), uri = obj@uri)
        } else {
            loc.obj = obj
        }
        # network id and cyREST plugin version
        net.SUID = as.character(loc.obj@window.id)
        version = pluginVersion(loc.obj)
        
        if(!is.na(net.SUID)) {
            # get the graph from Cytoscape
            resource.uri = paste(loc.obj@uri, version, "networks", net.SUID, sep="/")
            request.res = GET(url=resource.uri)
            request.res = fromJSON(rawToChar(request.res$content))
            
            g = new("graphNEL", edgemode='directed') # create graph object
            
            # GET GRAPH NODES
            g.nodes = request.res$elements$nodes
            # if there are no nodes in the graph received from Cytoscape, return an empty 'graphNEL' object
            if(length(g.nodes) == 0) {
                write(sprintf("NOTICE in RCy3::getGraphFromCyWindow():\n\t returning an empty 'graphNEL'"), stderr())
                return(g)
            }
            # else get the node names and add them to the R graph
            loc.obj@suid.name.dict = lapply(g.nodes, function(n) { 
                list(name=n$data$name, SUID=n$data$SUID) })
            g.node.names = sapply(loc.obj@suid.name.dict, function(n) { n$name })
            write(sprintf("\t received %d NODES from '%s'", length(g.nodes), window.title), stderr())
            g = graph::addNode(g.node.names, g)
            write(sprintf("\t - added %d nodes to the returned graph\n", length(g.node.names)), stderr())
            
            # GET NODE ATTRIBUTES (if any)
            g = copyNodeAttributesFromCyGraph(loc.obj, net.SUID, g)
            
            # Bioconductor's 'graph' edges require the 'edgeType' attribute, so its default value is assigned
            g = initEdgeAttribute (g, 'edgeType', 'char', 'assoc')
            
            # GET GRAPH EDGES
            g.edges = request.res$elements$edges
            
            if(length(g.edges) > 0) {
                regex = ' *[\\(|\\)] *'
                write(sprintf("\n\t received %d EDGES from '%s'", length(g.edges), window.title), stderr())
                
                loc.obj@edge.suid.name.dict = lapply(g.edges, function(e) { 
                    list(name=e$data$name, SUID=e$data$SUID) })
                g.edge.names = sapply(loc.obj@edge.suid.name.dict, function(e) { e$name })
                edges.tokens = strsplit(g.edge.names, regex)
                source.nodes = unlist(lapply(edges.tokens, function(tokens) tokens[1]))
                target.nodes = unlist(lapply(edges.tokens, function(tokens) tokens[3]))
                edge.types = unlist(lapply(edges.tokens, function(tokens) tokens[2]))
                write(sprintf('\t - adding %d edges to the returned graph\n', length(edges.tokens)), stderr())
                g = addEdge(source.nodes, target.nodes, g)
                
                edgeData(g, source.nodes, target.nodes, 'edgeType') = edge.types
                
                # GET EDGE ATTRIBUTES (if any)
                g = copyEdgeAttributesFromCyGraph(loc.obj, window.id, g)
            }
            
        } else {
            write(sprintf("ERROR in RCy3::getGraphFromCyWindow():\n\t there is no graph with name '%s' in Cytoscape", window.title), stderr())
            
            return(NA)
        }
        
        return(g)
})
## END getGraphFromCyWindow

# ------------------------------------------------------------------------------
setMethod('sendNodes', 'CytoscapeWindowClass', 
   function(obj) {
      loc.obj <- obj
      # returns the nodes currently stored in the graph object
      graph.network.nodes = nodes(loc.obj@graph)
      # returns the nodes currently displayed in Cytoscape
      current.cytoscape.nodes = sapply(loc.obj@suid.name.dict, function(n) n$name)
      
      node.suid.name.dict <- (0)
      
      diff.nodes = setdiff(graph.network.nodes, current.cytoscape.nodes)
      # if new nodes need to be added
      if(length(diff.nodes) > 0) {
         net.SUID = as.character(loc.obj@window.id)
         version = pluginVersion(loc.obj)
         
         resource.uri = paste(loc.obj@uri, version, "networks", net.SUID, "nodes", sep="/")
         diff.nodes.JSON = toJSON(diff.nodes)
         
         write(sprintf('sending %d node(s)', length(diff.nodes)), stderr())
         
         request.res = POST(url=resource.uri, body=diff.nodes.JSON, encode="json")
         new.node.SUIDs = unname(fromJSON(rawToChar(request.res$content)))
         
         for(i in 1:length(new.node.SUIDs)) {
            loc.obj@suid.name.dict[[length(loc.obj@suid.name.dict)+1]] = new.node.SUIDs[[i]]
         }
      } else {
         write(sprintf("NOTICE in RCy3::sendNodes():\n\t all %d nodes already exist in Cytoscape - nothing new to add >> function returns", length(graph.network.nodes)), stderr())
         return()
      }
      
      write('sendNodes() COMPLETED', stderr())
      # needed for 'pass-by-reference' R functionality 
      eval.parent(substitute(obj <- loc.obj))
})
## END sendNodes

# ------------------------------------------------------------------------------
setMethod('.addNodes', signature(obj='CytoscapeWindowClass'), 
    function(obj, other.graph) {
        loc.obj <- obj
        if(length(nodes(other.graph)) == 0) {
            write("NOTICE in RCy3::.addNodes():\n\t no nodes in other.graph >> function returns", stderr())
            return()
        }
        # new.nodes = setdiff(nodes(other.graph), getAllNodes(loc.obj))
        new.node.indices = which(!nodes(other.graph) %in% getAllNodes(loc.obj))
        
        new.nodes = nodes(other.graph)[new.node.indices]
        
        if(length(new.node.indices) > 0) {
            net.SUID = as.character(loc.obj@window.id)
            version = pluginVersion(loc.obj)
            
            resource.uri = paste(loc.obj@uri, version, "networks", net.SUID, "nodes", sep="/")
            new.nodes.JSON = toJSON(new.nodes)
            
            request.res = POST(url=resource.uri, body=new.nodes.JSON, encode="json")
            new.node.SUIDs = unname(fromJSON(rawToChar(request.res$content)))
            
            for(i in 1:length(new.node.SUIDs)) {
                loc.obj@suid.name.dict[[length(loc.obj@suid.name.dict)+1]] = new.node.SUIDs[[i]]
            }
        } else {
            write(sprintf("NOTICE in RCy3::.addNodes():\n\t all %d nodes already exist in Cytoscape - nothing new to add >> function returns", length(nodes(other.graph))), stderr())
            return()
        }
        # needed for 'pass-by-reference' R functionality
        eval.parent(substitute(obj <- loc.obj))
        
        return(new.node.indices)
})
## END .addNodes

# ------------------------------------------------------------------------------
setMethod('.addEdges', signature(obj='CytoscapeWindowClass'), 
    function(obj, other.graph) {
        loc.obj <- obj
        net.SUID = as.character(loc.obj@window.id)
        version = pluginVersion(loc.obj)
        
        if(length(edgeNames(other.graph)) == 0) {
            write("NOTICE in RCy3::.addEdges():\n\t no edges in graph >> function returns", stderr())
            return()
        }
        
        if(is.classic.graph(other.graph)) {
            tbl.edges = .classicGraphToNodePairTable(other.graph)
        } else if(is.multiGraph(other.graph)) {
            tbl.edges = .multiGraphToNodePairTable(other.graph)
        }
        # get the 'other.graph' edge names
        other.graph.edge.names = unname(cy2.edge.names(other.graph))
        
        cytoscape.existing.edge.names = 
            sapply(loc.obj@edge.suid.name.dict, function(e) {return(e$name)})
        new.edge.indices = which(!other.graph.edge.names %in% cytoscape.existing.edge.names)
        
        if(length(new.edge.indices) > 0) {
            # source nodes vector
            source.nodes = tbl.edges$source[new.edge.indices]
            # target nodes vector
            target.nodes = tbl.edges$target[new.edge.indices]
            # edge types vector
            edge.type = tbl.edges$edgeType[new.edge.indices]
            directed = rep(TRUE, length(source.nodes))
            
            # convert the [node.SUID, node.name] dict(list) to data frame object
            suid.name.dict.df = 
                data.frame(matrix(unlist(loc.obj@suid.name.dict), nrow=length(loc.obj@suid.name.dict), byrow=T), stringsAsFactors=FALSE)
            colnames(suid.name.dict.df) <- c("name", "SUID")
            
            # get the SUIDs of the source nodes for the new edges
            source.node.SUIDs = .nodeNameToNodeSUID(loc.obj, source.nodes)
            # get the SUIDs of the target nodes for the new edges
            target.node.SUIDs = .nodeNameToNodeSUID(loc.obj, target.nodes)
            
            # format the new edges data for sending to Cytoscape
            edge.tbl.records = 
                apply(cbind(source.node.SUIDs, target.node.SUIDs, directed, edge.type), MARGIN=1,
                      FUN=function(r) {list(source=unname(r[[1]]), target=unname(r[[2]]), directed=unname(r[[3]]), interaction=unname(r[[4]]))})
            edge.tbl.records.JSON = toJSON(edge.tbl.records)
            resource.uri = paste(loc.obj@uri, pluginVersion(loc.obj), "networks", net.SUID, "edges", sep="/")
            request.res = POST(url=resource.uri, body=edge.tbl.records.JSON, encode="json")
            
            # request.res.edge.SUIDs contains 
            # [edge.SUID, source.node.SUID, targetn.node.SUID] for each edge
            request.res.edge.data = fromJSON(rawToChar(request.res$content))
            
            new.edge.names = cy2.edge.names(other.graph)[new.edge.indices]
            # ctreates matrix of the format : 
            # note: column 1 contains edge.SUIDs, and columns 3 & 4 contain node.SUIDs
            #      [,1]   [,2]                     [,3]   [,4]
            # [1,] "412"  "A (phosphorylates) B"   "413"  "404"
            # [2,] "406"  "B (synthetic lethal C"  "407"  "408"
            # [3,] "407"  "C (undefined) A"        "408"  "406"
            edge.names.tbl.records = 
                apply(unname(cbind(unname(t(sapply(request.res.edge.data, unlist))), new.edge.names)), 
                      MARGIN=1, 
                      FUN=function(r) {list(SUID=as.numeric(unname(r[[1]])), value=unname(r[[4]]), 
                                            source.node=as.numeric(unname(r[[2]])), 
                                            target.node=as.numeric(unname(r[[3]])))})
            # CREATES DICT ENTRIES for the new edges in the following format :
            # [edge.SUID, edge.name, source.node.SUID, target.node.SUID]
            for(i in 1:length(edge.names.tbl.records)) {
                loc.obj@edge.suid.name.dict[[length(loc.obj@edge.suid.name.dict)+1]] = 
                    list(SUID=edge.names.tbl.records[[i]]$SUID, name=edge.names.tbl.records[[i]]$value, 
                         source.node=edge.names.tbl.records[[i]]$source.node, 
                         target.node=edge.names.tbl.records[[i]]$target.node)
            }
            
            # invisible(request.res)
        } else {
            write(sprintf("NOTICE in RCy3::.addEdges():\n\t all %d edges already exists in Cytoscape - nothing new to add >> function returns", length(other.graph.edge.names)), stderr())
            return()
        }
        
        eval.parent(substitute(obj <- loc.obj))
        
        return(new.edge.indices)
}) 
## END .addEdges

# ------------------------------------------------------------------------------
setMethod('.getWindowNameFromSUID', 'CytoscapeConnectionClass',
   function(obj, win.suid) {
      suid = as.character(win.suid)
      resource.uri = paste(obj@uri, pluginVersion(obj), "networks", suid, sep="/")
      request.res = GET(url=resource.uri)
      win.name = fromJSON(rawToChar(request.res$content))$data$name
      return(win.name)
})
## END .getWindowNameFromSUID

# ------------------------------------------------------------------------------
setMethod('.getNetworkViews', 'CytoscapeConnectionClass',
   function(obj) {
      net.SUID = as.character(obj@window.id)
      
      resource.uri = paste(obj@uri, pluginVersion(obj), "networks", net.SUID, "views", sep="/")
      request.res = GET(url=resource.uri)
      network.view.SUIDs = unname(fromJSON(rawToChar(request.res$content)))
      return(network.view.SUIDs)
})
## END .getNetworkViews

# ------------------------------------------------------------------------------
setMethod('.nodeNameToNodeSUID', 'CytoscapeConnectionClass',
   function(obj, node.names) {
      # initial source used 'which', but it did not return SUIDs in the input names order  
      # dict.indices = which(node.names %in% sapply(obj@suid.name.dict, function(n) { n$name}))
      # 'match' achieves this desired behavior
      dict.node.names = sapply(obj@suid.name.dict, function(n) { n$name})
      dict.indices = match(node.names, dict.node.names)
      
      node.SUIDs = sapply(obj@suid.name.dict[dict.indices], function(i) {i$SUID})
      return(node.SUIDs)
})
## END .nodeNamesToNodeSUID

# ------------------------------------------------------------------------------
setMethod('.nodeSUIDToNodeName', 'CytoscapeConnectionClass', 
   function(obj, node.suids) {
      dict.node.SUIDs = sapply(obj@suid.name.dict, function(s) { s$SUID})
      dict.indices = match(node.suids, dict.node.SUIDs)
      
      node.names = sapply(obj@suid.name.dict[dict.indices], function(n) {n$name})
      return(node.names)
})
## END .nodeSUIDToNodeName

# ------------------------------------------------------------------------------
setMethod('.edgeNameToEdgeSUID', 'CytoscapeConnectionClass',
   function(obj, edge.names) {
      dict.edge.names = sapply(obj@edge.suid.name.dict, function(e) {e$name})
      dict.indices = match(edge.names, dict.edge.names)
      
      edge.SUIDs = sapply(obj@edge.suid.name.dict[dict.indices], function(i){i$SUID})
      return(edge.SUIDs)
})
## END .edgeNamesToEdgeSUID

# ------------------------------------------------------------------------------
setMethod('.edgeSUIDToEdgeName', 'CytoscapeConnectionClass', 
   function(obj, edge.suids) {
      dict.edge.SUIDs = sapply(obj@edge.suid.name.dict, function(s) {s$SUID})
      dict.indices = match(edge.suids, dict.edge.SUIDs)
      
      edge.names = sapply(obj@edge.suid.name.dict[dict.indices], function(e) {e$name})
      return(edge.names)
})
## END .edgeSUIDToEdgeName

# ------------------------------------------------------------------------------
setMethod('addCyNode', 'CytoscapeWindowClass', 
   function(obj, nodeName) {
      loc.obj <- obj
      
      if(nodeName %in% getAllNodes(loc.obj)) {
         write(sprintf('RCy3::addCyNode, %s node already present in Cytoscape graph', nodeName), stderr())
         return()
      }
      # get the network suid
      net.SUID = as.character(loc.obj@window.id)
      
      resource.uri = paste(loc.obj@uri, pluginVersion(loc.obj), "networks", net.SUID, "nodes", sep="/")
      nodename.JSON = toJSON(c(nodeName))
      # add the node to the Cytoscape graph
      request.res = POST(url=resource.uri, body=nodename.JSON, encode="json")
      
      new.cynode.suid.name <- unname(fromJSON(rawToChar(request.res$content)))
      # add the new node to the cw@suid.name.dict
      loc.obj@suid.name.dict[[length(loc.obj@suid.name.dict)+1]] = 
         list(name=new.cynode.suid.name[[1]]$name, SUID=new.cynode.suid.name[[1]]$SUID)
      
      # TO DO in future RCy3 releases: add the node to the cw@graph object
      eval.parent(substitute(obj <- loc.obj))
})
## END addCyNode

# ------------------------------------------------------------------------------
setMethod('addCyEdge', 'CytoscapeWindowClass', 
    function (obj, sourceNode, targetNode, edgeType, directed) {
        loc.obj <- obj
        
        good.args = TRUE
        # confirm that the user has provided exactly one source and one target nodes
        if((length(sourceNode) > 1) || (length(targetNode) > 1)) {
            good.args = FALSE
            write(sprintf('RCy3::addEdge can have only one source and one target nodes'), stderr())
        }
        
        if(!sourceNode %in% getAllNodes(loc.obj)) {
            good.args = FALSE
            write(sprintf("Error: source node '%s' does not exist in the Cytoscape graph. Edge cannot be created.", sourceNode), stderr())
        }
        if(!targetNode %in% getAllNodes(loc.obj)) {
            good.args = FALSE
            write(sprintf("Error: target node '%s' does not exist in the Cytoscape graph. Edge cannot be created.", targetNode), stderr())
        }
        if(!good.args) {
            return()
        }
        # network ID and cyREST version
        net.SUID = as.character(loc.obj@window.id)
        version = pluginVersion(loc.obj)
        
        # get the edge name
        edge.name = paste(sourceNode, " (", edgeType, ") ", targetNode, sep="")
        
        # confirm the edge is not already existing
        if(!edge.name %in% sapply(loc.obj@edge.suid.name.dict, function(e) { e$name })) {
            # add the new edge to the network
            source.node.SUID = .nodeNameToNodeSUID(loc.obj, sourceNode)
            target.node.SUID = .nodeNameToNodeSUID(loc.obj, targetNode)
            resource.uri = paste(loc.obj@uri, version, "networks", net.SUID, "edges", sep="/")
            new.edge.record = 
                list(source=source.node.SUID, target=target.node.SUID, directed=directed, interaction=edgeType)
            new.edge.record.JSON = toJSON(list(new.edge.record))
            request.res = POST(url=resource.uri, body=new.edge.record.JSON, encode="json")
            
            edge.SUID = unname(fromJSON(rawToChar(request.res$content))[[1]][1])
            print(edge.SUID)
            
            # add edge to session dictionary
            loc.obj@edge.suid.name.dict[[length(loc.obj@edge.suid.name.dict)+1]] = 
                list(SUID=edge.SUID, name=edge.name, source.node=source.node.SUID, target.node=target.node.SUID)
            invisible(request.res)
        }
        # simulate 'pass-by-reference' in R
        eval.parent(substitute(obj <- loc.obj))
})
## END addCyEdge

# ------------------------------------------------------------------------------
# this method adds a new graph to an existing graph : 
# first the new nodes, then the edges, then the node attributes, and finally - the edge attributes
setMethod('addGraphToGraph', 'CytoscapeWindowClass', 
    function(obj, other.graph) {
        loc.obj <- obj
        # RCy3 keeps a dictionary of the network nodes 
        # the below vector stores the indices of the newly added nodes in this dictionary
        new.node.indices = .addNodes(loc.obj, other.graph)
        # RCy3 keeps a dictionary of the network edges
        # the below vector stores the indices of the newly added edges to this dictionary
        new.edge.indices = .addEdges(loc.obj, other.graph)
        
        node.attribute.names = noa.names(other.graph)
        
        for(attribute.name in node.attribute.names) {
            printf('sending noa %s', attribute.name)
            .sendNodeAttributesForGraph(loc.obj, other.graph, attr=attribute.name, new.node.indices)
        }
        
        edge.attribute.names = eda.names(other.graph)
        for(attribute.name in edge.attribute.names) {
            printf('sending eda %s', attribute.name)
            .sendEdgeAttributesForGraph(loc.obj, other.graph, attr=attribute.name, new.edge.indices)
        }
        
        # needed for 'pass-by-reference' R functionality
        eval.parent(substitute(obj <- loc.obj))
}) 
## END addGraphToGraph

# ------------------------------------------------------------------------------
# send graph edges to Cytoscape
setMethod('sendEdges', 'CytoscapeWindowClass', 
   function(obj) {
      loc.obj <- obj
      net.SUID = as.character(loc.obj@window.id)
      version = pluginVersion(loc.obj)
      # check that there are edges in the graph
      if(length(edgeNames(loc.obj@graph)) == 0) {
         write('NOTICE in RCy3::sendEdges():\n\t no edges in graph >> function returns', stderr())
         return()
      }
      
      write(sprintf('transforming (%d) graph edges to nodePairTable', length(edgeNames(loc.obj@graph))), stderr())
      if(loc.obj@collectTimings) {
         start.time = Sys.time()
      }
      
      if(is.classic.graph(loc.obj@graph)) {
         tbl.edges = .classicGraphToNodePairTable(loc.obj@graph)
      }
      else if(is.multiGraph(loc.obj@graph)) {
         tbl.edges = .multiGraphToNodePairTable(loc.obj@graph)
      }
      
      if (loc.obj@collectTimings){
         write (sprintf(' *** create node pair table: %f secs', difftime (Sys.time(), start.time, units='secs')), stderr ())
      }
      
      # get the list of edges to be send to Cytoscape
      in.graph.edge.names = unname(cy2.edge.names(loc.obj@graph))
      # get the list of currently existing esges (from dict)
      existing.edge.names = 
         sapply(loc.obj@edge.suid.name.dict, function(n) {return(n$name)})
      
      diff.edges = setdiff(in.graph.edge.names, existing.edge.names)
      # in new edges need to be send to the network
      if(length(diff.edges) > 0) {
         write (sprintf('sending %d edges', nrow(tbl.edges)), stderr())
         # source nodes vector
         source.nodes = tbl.edges$source
         # target nodes vector
         target.nodes = tbl.edges$target
         # edge types vector
         edge.type = tbl.edges$edgeType
         directed = rep(TRUE, length(source.nodes))
         
         # convert the [node.SUID, node.name] dict(list) to data frame object 
         suid.name.dict.df = 
            data.frame(matrix(unlist(loc.obj@suid.name.dict), nrow=length(loc.obj@suid.name.dict), byrow=T), stringsAsFactors=FALSE)
         colnames(suid.name.dict.df) <- c("name", "SUID")
         # get the SUIDs of the source nodes for the new edges
         source.node.SUIDs = .nodeNameToNodeSUID(loc.obj, source.nodes)
         # get the SUIDs of the target nodes for the new edges
         target.node.SUIDs = .nodeNameToNodeSUID(loc.obj, target.nodes)
         
         # format the new edges data for sending to Cytoscape
         edge.tbl.records = 
            apply(cbind(source.node.SUIDs, target.node.SUIDs, directed, edge.type), MARGIN=1,
                  FUN=function(r) {list(source=unname(r[[1]]), target=unname(r[[2]]), directed=unname(r[[3]]), interaction=unname(r[[4]]))})
         edge.tbl.records.JSON = toJSON(edge.tbl.records)
         resource.uri = paste(loc.obj@uri, pluginVersion(loc.obj), "networks", net.SUID, "edges", sep="/")
         request.res = POST(url=resource.uri, body=edge.tbl.records.JSON, encode="json")
         
         # request.res.edge.SUIDs contains 
         # [edge.SUID, source.node.SUID, targetn.node.SUID] for each edge
         request.res.edge.data = fromJSON(rawToChar(request.res$content))
         
         edge.names = cy2.edge.names(obj@graph)
         # ctreates matrix of the format : 
         # note: column 1 contains edge.SUIDs, and columns 3 & 4 contain node.SUIDs
         #      [,1]   [,2]                     [,3]   [,4]
         # [1,] "412"  "A (phosphorylates) B"   "413"  "404"
         # [2,] "406"  "B (synthetic lethal C"  "407"  "408"
         # [3,] "407"  "C (undefined) A"        "408"  "406"
         edge.names.tbl.records = 
            apply(unname(cbind(unname(t(sapply(request.res.edge.data, unlist))), edge.names)), 
                  MARGIN=1, 
                  FUN=function(r) {list(SUID=as.numeric(unname(r[[1]])), value=unname(r[[4]]), 
                                        source.node=as.numeric(unname(r[[2]])), 
                                        target.node=as.numeric(unname(r[[3]])))})
         # CREATES DICT ENTRIES for the new edges in the following format :
         # [edge.SUID, edge.name, source.node.SUID, target.node.SUID]
         for(i in 1:length(edge.names.tbl.records)) {
            loc.obj@edge.suid.name.dict[[length(loc.obj@edge.suid.name.dict)+1]] = 
               list(SUID=edge.names.tbl.records[[i]]$SUID, name=edge.names.tbl.records[[i]]$value, 
                    source.node=edge.names.tbl.records[[i]]$source.node, 
                    target.node=edge.names.tbl.records[[i]]$target.node)
         }
         invisible(request.res)
      } else {
          write(sprintf("NOTICE in RCy3::sendEdges():\n\t all %d edges already exist in Cytoscape - nothing new to add >> function returns", length(in.graph.edge.names)), stderr())
          return()
      }
      # simulate 'pass-by-reference' in R
      eval.parent(substitute(obj <- loc.obj))
})

# ------------------------------------------------------------------------------
setMethod('layoutNetwork', 'CytoscapeWindowClass', 
   function(obj, layout.name = 'grid') {
      if(!layout.name %in% getLayoutNames(obj)) {
         write(sprintf("layout.name '%s' is not recognized; call getLayoutNames(<CytoscapeWindow>) to see those which are supported", layout.name), stderr()) 
         return()
      }    
      net.SUID = as.character(obj@window.id)
      resource.uri = paste(obj@uri, pluginVersion(obj), "apply/layouts", layout.name, net.SUID, sep = "/")
      request.res = GET(url=resource.uri)
      invisible(request.res)
})
# END layoutNetwork()

# ------------------------------------------------------------------------------
setMethod('saveLayout', 'CytoscapeWindowClass', 
   function(obj, filename, timestamp.in.filename=FALSE) {
      custom.layout = getNodePosition(obj, getAllNodes(obj))
      if(timestamp.in.filename) {
         dateString = format(Sys.time(), "%a.%b.%d.%Y-%H.%M.%S")
         stem = strsplit(filename, '\\.RData')[[1]]
         filename = sprintf('%s.%s.RData', stem, dateString)
         write(sprintf('saving layout to %s\n', filename), stderr())
      }
      save(custom.layout, file=filename)
})
## END saveLayout

# ------------------------------------------------------------------------------
setMethod('restoreLayout', 'CytoscapeWindowClass', 
   function(obj, filename) {
      load(filename)
      node.names = names(custom.layout)
      node.names.filtered = intersect(node.names, getAllNodes(obj))
      x = as.integer(sapply(node.names.filtered, function(node.name) return(custom.layout[[node.name]]$x)))
      y = as.integer(sapply(node.names.filtered, function(node.name) return(custom.layout[[node.name]]$y)))
      setNodePosition(obj, node.names.filtered, x, y)
})
## END restoreLayout

# ------------------------------------------------------------------------------
setMethod('setNodePosition', 'CytoscapeWindowClass', 
   function(obj, node.names, x.coords, y.coords) {
      unknown.nodes = setdiff(node.names, getAllNodes(obj))
      recognized.nodes = intersect(node.names, getAllNodes(obj))
      
      if(length(unknown.nodes) > 0) {
         node.names = intersect(node.names, nodes(obj@graph))
         write(sprintf("Error! unknown nodes in RCy3::setNodePosition"), stderr())
         for(i in 1:length(unknown.nodes)){
            write(sprintf(" %s", unknown.nodes[i]), stderr())
         }
         return()
      }
      
      indices = match(recognized.nodes, node.names)
      node.names = recognized.nodes
      
      x.coords <- x.coords[indices]
      y.coords <- y.coords[indices]
      count = length(node.names)
      # stopifnot(length(x.coords) == count)
      # stopifnot(length(y.coords) == count)
      
      if(count == 0) {
         return()
      }
      
      # set node's x-position
      setNodePropertyDirect(obj, node.names, x.coords, "NODE_X_LOCATION")
      # set node's y-position
      setNodePropertyDirect(obj, node.names, y.coords, "NODE_Y_LOCATION")
})
## END setNodePosition

# ------------------------------------------------------------------------------
setMethod('getNodePosition', 'CytoscapeWindowClass', 
   function(obj, node.names) {
      net.SUID = as.character(obj@window.id)
      version = pluginVersion(obj)
      
      net.view.SUIDs = .getNetworkViews(obj)
      view.SUID = as.character(net.view.SUIDs[[1]])
      # if multiple views are returned, inform the user about it
      if(length(net.view.SUIDs) > 1) {
         write(sprintf("RCy3::getCenter() - %d views found... returning coordinates of the first one", length(net.view.SUIDs)), stderr())
      }
      
      coordinates.list = list()
      
      node.SUIDs = .nodeNameToNodeSUID(obj, node.names)
      i = 1
      # get the position of each node
      for(node.SUID in node.SUIDs) {
         # get the x-coordinate
         resource.uri = 
            paste(obj@uri, version, "networks", net.SUID, "views", view.SUID, "nodes", as.character(node.SUID), "NODE_X_LOCATION", sep="/")
         request.res = GET(url=resource.uri)
         node.x.position = fromJSON(rawToChar(request.res$content))[[2]]
         
         # get the y-coordinate
         resource.uri = 
            paste(obj@uri, version, "networks", net.SUID, "views", view.SUID, "nodes", as.character(node.SUID), "NODE_Y_LOCATION", sep="/")
         request.res = GET(url=resource.uri)
         node.y.position = fromJSON(rawToChar(request.res$content))[[2]]
         
         # add the x- and y-coordinates to the list
         node.name = node.names[i]
         coordinates.list[[node.name]] = list(x=node.x.position, y=node.y.position)
         i = i+1
      }
      
      return(coordinates.list)
})
## END getNodePosition

# ------------------------------------------------------------------------------
setMethod('getNodeSize', 'CytoscapeWindowClass', 
    function(obj, node.names) {
        # get network ID and version
        net.SUID = as.character(obj@window.id)
        version = pluginVersion(obj)
        
        net.views.SUIDs = .getNetworkViews(obj)
        view.SUID = as.character(net.views.SUIDs[[1]])
        
        node.widths <- c()
        node.heights <- c()
        
        for(i in seq(node.names)) {
            node.name <- node.names[i]
            
            node.SUID = as.character(.nodeNameToNodeSUID(obj, node.name))
            resource.uri = paste(obj@uri, version, "networks", net.SUID, "views", view.SUID, "nodes", node.SUID, sep="/")
            # request result
            request.res = GET(url=resource.uri)
            request.res = fromJSON(rawToChar(request.res$content))
            
            visual.properties = sapply(request.res, '[[', "visualProperty")
            visual.values = sapply(request.res, '[[', "value")
            
            node.widths = c(node.widths, as.integer(visual.values[which(visual.properties == "NODE_WIDTH")]))
            node.heights = c(node.heights, as.integer(visual.values[which(visual.properties =="NODE_HEIGHT")]))
        }
        
        return(list(width=node.widths, height=node.heights))
}) 
## END getNodeSize

# ------------------------------------------------------------------------------
properlyInitializedNodeAttribute = function (graph, attribute.name) {
    if(length(nodes(graph)) == 0) {
        return(TRUE)
    }
    
    caller.specified.attribute.class = attr(nodeDataDefaults(graph, attribute.name), 'class')
    
    if(is.null(caller.specified.attribute.class)) {
        msg1 = sprintf('Error!  Node attribute not initialized "%s"', attribute.name)
        msg2 = sprintf('        You should call:')
        msg3 = sprintf('        initNodeAttribute (graph, attribute.name, attribute.type, default.value)')
        msg4 = sprintf('        where attribute type is one of "char", "integer", "boolean", or "numeric".')
        msg5 = sprintf('        example:  g <- initNodeAttribute (g, "nodeType", "char", "molecule")')
        msg6 = sprintf('             or:  g <- initNodeAttribute (g, "pValue", "numeric", 1.0)')
        write(msg1, stderr())
        write(msg2, stderr())
        write(msg3, stderr())
        write(msg4, stderr())
        write(msg5, stderr())
        write(msg6, stderr())
        return(FALSE)
    }
    return(TRUE)
} 
## END properlyInitializedNodeAttribute

# ------------------------------------------------------------------------------
properlyInitializedEdgeAttribute = function (graph, attribute.name) {
    if(length(edgeNames(graph)) == 0) {
        return(TRUE)
    }
    
    caller.specified.attribute.class = attr(edgeDataDefaults(graph, attribute.name), 'class')
    
    if(is.null(caller.specified.attribute.class)) {
        msg1 = sprintf('Error!  "%s" edge attribute not initialized.', attribute.name)
        msg2 = sprintf('        You should call:')
        msg3 = sprintf('        initEdgeAttribute (graph, attribute.name, attribute.type, default.value)')
        msg4 = sprintf('        where attribute type is one of "char", "integer", "boolean", or "numeric".')
        msg5 = sprintf('        example:  g <- initEdgeAttribute (g, "edgeType", "char", "molecule")')
        msg6 = sprintf('             or:  g <- initEdgeAttribute (g, "pValue", "numeric", 1.0)')
        write(msg1, stderr())
        write(msg2, stderr())
        write(msg3, stderr())
        write(msg4, stderr())
        write(msg5, stderr())
        write(msg6, stderr())
        return(FALSE)
    }
    return(TRUE)
} 
## END properlyInitializedEdgeAttribute

# ------------------------------------------------------------------------------
setMethod('setNodeAttributes', 'CytoscapeWindowClass', 
    function(obj, attribute.name) {
        # it might be the case that 'obj@graph' contains nodes that do NOT exist in Cytoscape
        # the below line identifies the indices of those graph nodes, which DO exist in Cytoscape
        node.indices = which(nodes(obj@graph) %in% getAllNodes(cw))
        
        if(length(node.indices) > 0) {
            node.names = nodes(obj@graph)[node.indices]
            
            values = noa(obj@graph, attribute.name)[node.indices]
            
            caller.specified.attribute.class = 
                attr(nodeDataDefaults(obj@graph, attribute.name), 'class')
            invisible(setNodeAttributesDirect(obj, attribute.name, caller.specified.attribute.class, node.names, values))
        } else {
            write(sprintf("WARNING in RCy3::setNodeAttributes():\n\t before setting node attributes, please first send the graph nodes to Cytoscape >> function aborted"), stderr())
        }
})
## END setNodeAttributes

# ------------------------------------------------------------------------------
setMethod('setNodeAttributesDirect', 'CytoscapeWindowClass', 
    function(obj, attribute.name, attribute.type, node.names, values) {
        net.SUID = as.character(obj@window.id)
        version = pluginVersion(obj)
        
        caller.specified.attribute.class = tolower(attribute.type)
        # the switch-block ensures the attribute values have the correct data type
        switch(caller.specified.attribute.class,
            "floating"=,
            "numeric"=,
            "double"={
                caller.specified.attribute.class = 'Double'
                values = as.numeric(values)
            },
            "integer"=,
            "int"={
                caller.specified.attribute.class = "Integer"
                values = as.integer(values)
            },
            "boolean"={
                caller.specified.attribute.class = "Boolean"
                values = as.logical(values)
            },{
                caller.specified.attribute.class = "String"
                values = as.character(values)
            }
        )
        
        if(!attribute.name %in% getNodeAttributeNames(obj)) {
            # create new table column in Cytoscape 'Node Table' to store the attribute values
            tbl.col = list(name=attribute.name, type=caller.specified.attribute.class)
            tbl.col.JSON = toJSON(tbl.col)
            resource.uri = 
                paste(obj@uri, version, "networks", net.SUID, "tables/defaultnode/columns", sep="/")
            request.res = POST(url=resource.uri, body=tbl.col.JSON, encode="json")
        }
        
        if(length(node.names) > 0) {
            if(length(node.names) != length(values)) {
                write(sprintf("ERROR in RCy3::setNodeAttributesDirect():\n\t the number of values(%d) for attribute '%s' must equal the number of nodes(%d) >> function aborted", 
                              length(values), attribute.name, length(node.names)), stderr())
            } else {
                node.SUIDs = .nodeNameToNodeSUID(obj, node.names)
                node.name.suid.value.df = data.frame(node.names, node.SUIDs, values)
                
                # converts the above data frame data in the cyREST [SUID:value]-pairs format
                node.SUID.value.pairs = 
                    apply(node.name.suid.value.df[,c('node.SUIDs','values')], 1, function(x) {list(SUID=unname(x[1]), value=unname(x[2]))})
                node.SUID.value.pairs.JSON = toJSON(node.SUID.value.pairs)
                
                resource.uri = 
                    paste(obj@uri, version, "networks", net.SUID, "tables/defaultnode/columns", attribute.name, sep="/")
                request.res = PUT(url=resource.uri, body=node.SUID.value.pairs.JSON, encode="json")
                invisible(request.res)
            }
        }
})
## END setNodeAttributesDirect

# ------------------------------------------------------------------------------
setMethod ('setEdgeAttributes', 'CytoscapeWindowClass', 
    function(obj, attribute.name) {
        cyrest.edge.names = as.character(cy2.edge.names(obj@graph))
        # user might have entered the names of edges that do NOT exist
        # the below line will return the indicies of the nodes that DO exist
        edge.indices = which(cyrest.edge.names %in% getAllEdges(cw))
        
        if(length(edge.indices) > 0) {
            edge.names = cyrest.edge.names[edge.indices]
            edge.names.tilde = names(cy2.edge.names(obj@graph)[edge.indices])
            edge.names.with.bars = gsub('~', '|', edge.names.tilde)
            values = eda(obj@graph, attribute.name)[edge.names.with.bars]
            
            caller.specified.attribute.class = attr(edgeDataDefaults(obj@graph, attribute.name), 'class')
                
            invisible(setEdgeAttributesDirect(obj, attribute.name, caller.specified.attribute.class, edge.names, values))
        } else {
            write(sprintf("WARNING in RCy3::setEdgeAttributes():\n\t before setting edge attributes, please first send the graph edges to Cytoscape >> function aborted"), stderr())
        }
})
## END setEdgeAttributes

# ------------------------------------------------------------------------------
setMethod('setEdgeAttributesDirect', 'CytoscapeWindowClass', 
    function(obj, attribute.name, attribute.type, edge.names, values) {
        net.SUID = as.character(obj@window.id)
        version = pluginVersion(obj)
        
        if(length(edge.names) > 0) {
            if(length(edge.names) != length(values)) {
                write(sprintf("ERROR in RCy3::setEdgeAttributesDirect():\n\t the number of values(%d) for attribute '%s' must equal the number of edges(%d) >> function aborted", 
                              length(values), attribute.name, length(edge.names)), stderr())
            } else {
                caller.specified.attribute.class = tolower(attribute.type)
                # the switch-block ensures the attribute values have the correct data type
                switch(caller.specified.attribute.class,
                       "floating"=,
                       "numeric"=,
                       "double"={
                           caller.specified.attribute.class = 'Double'
                           values = as.numeric(values)
                       },
                       "integer"=,
                       "int"={
                           caller.specified.attribute.class = "Integer"
                           values = as.integer(values)
                       },
                       "boolean"={
                           caller.specified.attribute.class = "Boolean"
                           values = as.logical(values)
                       },{
                           caller.specified.attribute.class = "String"
                           values = as.character(values)
                       }
                )
                
                if(!attribute.name %in% getEdgeAttributeNames(obj)) {
                    tbl.col = list(name=attribute.name, type=caller.specified.attribute.class)
                    tbl.col.JSON = toJSON(tbl.col)
                    resource.uri = 
                        paste(obj@uri, version, "networks", net.SUID, "tables/defaultedge/columns", sep="/")
                    request.res = POST(url=resource.uri, body=tbl.col.JSON, encode="json")
                }
                
                edge.SUIDs = .edgeNameToEdgeSUID(obj, edge.names)
                edge.name.suid.value.df = data.frame(edge.names, edge.SUIDs, values)
                
                edge.SUID.value.pairs = 
                    apply(edge.name.suid.value.df[,c('edge.SUIDs','values')], 1, function(x) {list(SUID=unname(x[1]), value=unname(x[2]))})
                edge.SUID.value.pairs.JSON = toJSON(edge.SUID.value.pairs)
                resource.uri = 
                    paste(obj@uri, version, "networks", net.SUID, "tables/defaultedge/columns", attribute.name, sep="/")
                request.res = PUT(url=resource.uri, body=edge.SUID.value.pairs.JSON, encode="json")
                invisible(request.res)
            }
        }
})
## END setEdgeAttributesDirect

# ------------------------------------------------------------------------------
setMethod('displayGraph', 'CytoscapeWindowClass', 
    function(obj) {
        # needed to simulate 'pass-by-reference' behavior in R
        loc.obj <- obj
        
        if(length(nodes(loc.obj@graph)) == 0) {
            write('RCy3::displayGraph, cannot display empty(0 nodes) graph, returning...', stderr())
            return()
        }
        node.count = length(nodes(loc.obj@graph))
        edge.count = length(edgeNames(loc.obj@graph))
        node.attribute.count = length(noa.names(loc.obj@graph)) * node.count
        edge.attribute.count = length(eda.names(loc.obj@graph)) * edge.count
        
        estimated.time = predictTimeToDisplayGraph(loc.obj)
        # if (execution)time measurement option is turned on, save the current time
        if(loc.obj@collectTimings) {
            method.start.time = Sys.time()
            # start time (for sending nodes to Cytoscape) 
            stepwise.start.time = Sys.time()
        }
        write(sprintf('estimated displayGraph time: %8.1f seconds', estimated.time), stderr()) 
        
        write(sprintf('adding %d nodes...', length(nodes(loc.obj@graph))), stderr())
        sendNodes(loc.obj)
        if(loc.obj@collectTimings) {
            current.step.exec.time = difftime(Sys.time(), stepwise.start.time, units='secs')
            write(sprintf(' *** sendNodes: %f secs', current.step.exec.time, stderr()))
            # start time (for sending node attributes to Cytoscape)
            stepwise.start.time = Sys.time()
        }
        write(sprintf('adding %d edges...', length(edgeNames(loc.obj@graph))), stderr())
        
        sendEdges(loc.obj)
        if(loc.obj@collectTimings) {
            write(sprintf(' *** sendEdges: %f secs', difftime(Sys.time(), stepwise.start.time, units='secs')), stderr())
            stepwise.start.time = Sys.time()
        }
        
        write('adding node attributes...', stderr())
        sapply(noa.names(loc.obj@graph), function(name) {
            # prints the node attribute name; removed
            # print(name[1])
            write(sprintf("\t > %s", name[1]), stderr())
            setNodeAttributes(loc.obj, name)
            })
        if(loc.obj@collectTimings) {
            write(sprintf(' *** send node attributes: %f secs', difftime(Sys.time(), stepwise.start.time, units='secs')), stderr())
            stepwise.start.time = Sys.time()
        }
        write('adding edge attributes...', stderr())
        
        edgeAttributeNames = eda.names(loc.obj@graph)
        sapply(eda.names(loc.obj@graph), function(name) {
            # print the edge attribute name; removed
            # print(name)
            write(sprintf("\t > %s", name[1]), stderr())
            setEdgeAttributes(loc.obj, name)
            })
        if(loc.obj@collectTimings){
            write(sprintf(' *** send edge attributes: %f secs', difftime(Sys.time(), stepwise.start.time, units='secs')), stderr())
            stepwise.start.time = Sys.time()
            actual.time = difftime(Sys.time(), method.start.time, units='secs')
            write(sprintf(' *** leaving displayGraph, predicted duration %f secs,  actual %f secs', 
                          as.integer(round(estimated.time)), as.integer(round(actual.time))), stderr())
        }
        # pseudo R 'pass-by-reference': cw now contains the [node suid,node name] pairs
        eval.parent(substitute(obj <- loc.obj))
})
## END displayGraph

# ------------------------------------------------------------------------------
setMethod('predictTimeToDisplayGraph', 'CytoscapeWindowClass', 
   function(obj) {
      g = obj@graph
      node.count = length(nodes(g))
      edge.count = length(edgeNames(g))
      noa.count = length(noa.names(g)) * node.count
      eda.count = length(eda.names(g)) * edge.count
      prediction = (0.002 * node.count) + (0.010 * edge.count) + (0.001 * noa.count) + (0.001 * eda.count)
      return(prediction)
})
## END predictTimeToDisplayGraph

# ------------------------------------------------------------------------------
setMethod('redraw', 'CytoscapeWindowClass', 
   function(obj) {
      net.SUID = as.character(obj@window.id)
      
      resource.uri = paste(obj@uri, pluginVersion(obj), "apply/styles", "default", net.SUID, sep = "/")
      request.res = GET(url=resource.uri)
      invisible(request.res)
})
## END redraw

# ------------------------------------------------------------------------------
setMethod('setWindowSize', 'CytoscapeWindowClass', 
   function (obj, width, height) {
      ### for implementation...
})
## END setWindowSize

# ------------------------------------------------------------------------------
setMethod('setTooltipInitialDelay', 'CytoscapeConnectionClass', 
   function(obj, msecs) {
#     invisible (xml.rpc (obj@uri, 'Cytoscape.setToolTipInitialDelay', as.integer (msecs)))
})
## END setTooltipInitialDelay

#------------------------------------------------------------------------------------------------------------------------
setMethod ('setTooltipDismissDelay', 'CytoscapeConnectionClass',

   function (obj, msecs) {
#     invisible (xml.rpc (obj@uri, 'Cytoscape.setToolTipDismissDelay', as.integer (msecs)))
     })

# ------------------------------------------------------------------------------
setMethod('raiseWindow', 'CytoscapeConnectionClass', 
  function(obj, window.title = NA) {
    if(is.na(window.title)) {
      if(class(obj) == 'CytoscapeWindowClass') {
        window.id = obj@window.id
      } else {
        write(sprintf('error in RCy3::raiseWindow(), no window title provided'), stderr())
        return()
      }
    } # no window title
    # if window title was provided
    if(!is.na(window.title)) {
      window.id = getWindowID(obj, window.title)
      
      if(is.na(window.id)) {
        write(sprintf('error in RCy3::raiseWindow(), unrecognized window title: %s', window.title), stderr ())
        return()
      }
      # TO DO: call to raise the view
      
    } # window title was provided
}) # raiseWindow

#------------------------------------------------------------------------------------------------------------------------
setMethod ('showGraphicsDetails', 'CytoscapeConnectionClass',

  function (obj, new.value) {
#    invisible (xml.rpc (obj@uri, 'Cytoscape.setShowGraphicsDetails', new.value))
#    if (class (obj) == 'CytoscapeWindowClass')
#      redraw (obj)
    })

# ------------------------------------------------------------------------------
# display the graph using all of the available window space (the Cytoscape drawing canvas)
setMethod('fitContent', 'CytoscapeWindowClass', 
  function(obj) {
    net.SUID = as.character(obj@window.id)
    resource.uri = paste(obj@uri, pluginVersion(obj), "apply/fit", net.SUID, sep="/")
    request.res = GET(url=resource.uri)
    invisible(request.res)
})
## END fitContent

#------------------------------------------------------------------------------------------------------------------------
setMethod ('fitSelectedContent', 'CytoscapeWindowClass',

   function (obj) {
#     invisible (xml.rpc (obj@uri, 'Cytoscape.fitSelectedContent', obj@window.id))
     })

# ------------------------------------------------------------------------------
setMethod('getCenter', 'CytoscapeWindowClass', 
  function(obj) {
    net.SUID = as.character(obj@window.id)
    # cyREST API version
    version = pluginVersion(obj)
    # get the views for the given network model
    net.views.SUIDs = .getNetworkViews(obj)
    
    view.SUID <- as.character(net.views.SUIDs[[1]])
    
    # if multiple views are found, inform the user about it
    if(length(net.views.SUIDs) > 1) {
      write(sprintf("RCy3::getCenter() - %d views found... returning coordinates of the first one", length(net.views.SUIDs)), stderr())
    }
    # get the X-coordinate
    resource.uri = paste(obj@uri, version, "networks", net.SUID, "views", view.SUID, "network/NETWORK_CENTER_X_LOCATION", sep="/")
    request.res = GET(resource.uri)
    x.coordinate = fromJSON(rawToChar(request.res$content))$value[[1]]
    # get the Y-coordinate
    resource.uri = paste(obj@uri, version, "networks", net.SUID, "views", view.SUID, "network/NETWORK_CENTER_Y_LOCATION", sep="/")
    request.res = GET(resource.uri)
    y.coordinate = fromJSON(rawToChar(request.res$content))$value[[1]]
    
    return(list(x = x.coordinate, y = y.coordinate))
})
## END getCenter

# ------------------------------------------------------------------------------
# this method could be used to pan and scroll the Cytoscape canvas, which is adjusted(moved) 
# so that the specified x and y coordinates are at the center of the visible window.
setMethod('setCenter', 'CytoscapeWindowClass', 
   function(obj, x, y) {
      net.SUID = as.character(obj@window.id)
      # cyREST API version
      version = pluginVersion(obj)
      
      net.views.SUIDs = .getNetworkViews(obj)
      view.SUID = as.character(net.views.SUIDs[[1]])
      
      # if multiple views are found, inform the user about it
      if(length(net.views.SUIDs) > 1) {
         write(sprintf("RCy3::setCenter() - %d views found... setting coordinates of the first one", length(net.views.SUIDs)), stderr())
      }
      # set the X-coordinate
      resource.uri = paste(obj@uri, version, "networks", net.SUID, "views", view.SUID, "network/NETWORK_CENTER_X_LOCATION", sep="/")
      new.x.coordinate.JSON = 
         toJSON(list(list(visualProperty="NETWORK_CENTER_X_LOCATION", value=x)))
      request.res = PUT(resource.uri, body=new.x.coordinate.JSON, encode="json")
      # set the Y-coordinate
      resource.uri = paste(obj@uri, version, "networks", net.SUID, "views", view.SUID, "network/NETWORK_CENTER_Y_LOCATION", sep="/")
      new.y.coordinate.JSON = 
         toJSON(list(list(visualProperty="NETWORK_CENTER_Y_LOCATION", value=y)))
      request.res = PUT(resource.uri, body=new.y.coordinate.JSON, encode="json")
      invisible(request.res)
})
## END setCenter

# ------------------------------------------------------------------------------
setMethod('getZoom', 'CytoscapeWindowClass', 
  function(obj) {
    net.suid = as.character(obj@window.id)
    # cyREST API version
    version = pluginVersion(obj) 
    # get the views for the given network model
    net.views.SUIDs = .getNetworkViews(obj)
    
    view.SUID = as.character(net.views.SUIDs[[1]])
    # if multiple views are found, inform the user about it
    if(length(net.views.SUIDs) > 1) {
      write(sprintf("RCy3::getZoom() - %d views found... returning coordinates of the first one", length(net.views.SUIDs)), stderr())
    }
    
    resource.uri = paste(obj@uri, version, "networks", net.suid, "views", view.SUID, "network/NETWORK_SCALE_FACTOR", sep="/")
    request.res = GET(resource.uri)
    zoom.level = fromJSON(rawToChar(request.res$content))$value[[1]]
    
    return(zoom.level)
})
## END getZoom

# ------------------------------------------------------------------------------
setMethod('setZoom', 'CytoscapeWindowClass', 
  function(obj, new.level) {
    net.SUID = as.character(obj@window.id)
    version = pluginVersion(obj)
     
    net.views.SUIDs = .getNetworkViews(obj)
    
    view.SUID = as.character(net.views.SUIDs[[1]])
    # if multiple views are found, inform the user about it
    if(length(net.views.SUIDs) > 1) {
      write(sprintf("RCy3::getZoom() - %d views found... returning coordinates of the first one", length(net.views.SUIDs)), stderr())
    }
    
    view.zoom.value <- list(visualProperty = 'NETWORK_SCALE_FACTOR', value = new.level)
    
    view.zoom.value.JSON <- toJSON(list(view.zoom.value))
    
    resource.uri = paste(obj@uri, version, "networks", net.SUID, "views", view.SUID, "network", sep="/")
    request.res = PUT(url=resource.uri, body=view.zoom.value.JSON, encode="json")
    
    invisible(request.res)
    redraw(obj)
})
## END setZoom

#------------------------------------------------------------------------------------------------------------------------
setMethod ('getViewCoordinates', 'CytoscapeWindowClass',

   function (obj) {
#     tmp = xml.rpc (obj@uri, 'Cytoscape.getViewCoordinates', obj@window.id)
#     return (list (top.x=tmp[1], top.y=tmp[2], bottom.x=tmp[3], bottom.y=tmp[4]))
     })

#------------------------------------------------------------------------------------------------------------------------
setMethod ('hidePanel', 'CytoscapeConnectionClass',

   function (obj, panelName) {
#     invisible (xml.rpc (obj@uri, 'Cytoscape.hidePanel', panelName))
     })

#------------------------------------------------------------------------------------------------------------------------
setMethod ('hideAllPanels', 'CytoscapeConnectionClass',

  function (obj) {
#    invisible (sapply (tolower (LETTERS), function (letter) hidePanel (obj, letter)))
    })

#------------------------------------------------------------------------------------------------------------------------
setMethod ('dockPanel', 'CytoscapeConnectionClass',

   function (obj, panelName) {
#     invisible (xml.rpc (obj@uri, 'Cytoscape.dockPanel', panelName))
     })

#------------------------------------------------------------------------------------------------------------------------
setMethod ('floatPanel', 'CytoscapeConnectionClass',

   function (obj, panelName) {
#     invisible (xml.rpc (obj@uri, 'Cytoscape.floatPanel', panelName))
     })

#------------------------------------------------------------------------------------------------------------------------
setMethod ('setNodeTooltipRule', 'CytoscapeWindowClass',

      # todo:  prevent the obligatory redraw
           
  function (obj, node.attribute.name) {
#    id = as.character (obj@window.id)
#    viz.style.name = 'default'
#    if (!node.attribute.name %in% noa.names (obj@graph)) {
#      write (sprintf ('warning!  setNodeTooltipRule passed non-existent node attribute: %s', node.attribute.name), stderr ())
#      return ()
#      }
#    attribute.values = as.character (noa (obj@graph, node.attribute.name))
#    tooltips = attribute.values   # an identity mapping: if you see node attribute x, then display x.  odd but true.
#    default.tooltip = ''
#    xml.rpc (obj@uri, 'Cytoscape.createDiscreteMapper', viz.style.name, node.attribute.name, 'Node Tooltip', default.tooltip,
#             attribute.values, tooltips)
    })  # setNodeTooltipRule

#------------------------------------------------------------------------------------------------------------------------
setMethod ('setEdgeTooltipRule', 'CytoscapeWindowClass',

  function (obj, edge.attribute.name) {
#    id = as.character (obj@window.id)
#    viz.style.name = 'default'
#    attribute.values = as.character (eda (obj@graph, edge.attribute.name))
#    tooltips = attribute.values  # identity mapping: when eda has value x, tooltip is x.  odd but true.
#    default.tooltip = ''
#    xml.rpc (obj@uri, 'Cytoscape.createDiscreteMapper', viz.style.name, edge.attribute.name, 'Edge Tooltip', default.tooltip,
#             attribute.values, tooltips)
    })  # setEdgeTooltipRule

#------------------------------------------------------------------------------------------------------------------------
setMethod ('setNodeLabelRule', 'CytoscapeWindowClass',

  function (obj, node.attribute.name) {
#    id = as.character (obj@window.id)
#    xml.rpc (obj@uri, 'Cytoscape.setNodeLabel', id, node.attribute.name, 'label', 'default'); 
    })  # setNodeLabelRule

#------------------------------------------------------------------------------------------------------------------------
setMethod ('setEdgeLabelRule', 'CytoscapeWindowClass',

  function (obj, edge.attribute.name) {
#    id = as.character (obj@window.id)
#    default.value = ''
#    result = xml.rpc (obj@uri, 'Cytoscape.edgePassthroughMapper', edge.attribute.name, 'Edge Label', default.value)
#    invisible (result)
    })  # setEdgeLabelRule

# ------------------------------------------------------------------------------
setMethod('setNodeColorRule', 'CytoscapeWindowClass', 
    function(obj, node.attribute.name, control.points, colors, mode, default.color='#FFFFFF') {
        if(!mode %in% c('interpolate', 'lookup')) {
            write(sprintf("ERROR in RCy3::setNodeColorRule(): \n\t mode must be 'interpolate' (the default) or 'lookup'"), stderr())
            return()
        }
        setDefaultNodeColor (obj, default.color)
#     if (mode=='interpolate') {  # need a 'below' color and an 'above' color.  so there should be two more colors than control.points 
#       if (length (control.points) == length (colors)) { # caller did not supply 'below' and 'above' values; manufacture them
#         colors = c (colors [1], colors, colors [length (colors)])
#         #write ("RCytoscape::setNodeColorRule, no 'below' or 'above' colors specified.  Inferred from supplied colors.", stderr ());
#         } # 
#
#       good.args = length (control.points) == (length (colors) - 2)
#       if (!good.args) {
#         write (sprintf ('cp: %d', length (control.points)), stderr ())
#         write (sprintf ('co: %d', length (colors)), stderr ())
#         write ("Error! RCytoscape:setNodeColorRule, interpolate mode.", stderr ())
#         write ("Expecting 1 color for each control.point, one for 'above' color, one for 'below' color.", stderr ())
#         return ()
#         }
#       result = xml.rpc (obj@uri, 'Cytoscape.createContinuousNodeVisualStyle', node.attribute.name, 'Node Color', control.points, colors, FALSE)
#       invisible (result)
#       } # if mode==interpolate
#
#     else { # use a discrete rule, with no interpolation
#       good.args = length (control.points) == length (colors)
#       if (!good.args) {
#         write (sprintf ('cp: %d', length (control.points)), stderr ())
#         write (sprintf ('co: %d', length (colors)), stderr ())
#         write ("Error! RCytoscape:setNodeColorRule.  Expecting exactly as many colors as control.points in lookup mode.", stderr ())
#         return ()
#         }
#
#       default.style = 'default'
#       if (length (control.points) == 1) {   # code around the requirement that one-element lists are turned into scalars
#         control.points = rep (control.points, 2)
#         colors = rep (colors, 2)
#         } 
#       result = xml.rpc (obj@uri, 'Cytoscape.createDiscreteMapper', default.style, 
#                         node.attribute.name, 'Node Color', default.color, control.points, colors)
#       invisible (result)
#       } # else: !interpolate
     }) # setNodeColorRule


#------------------------------------------------------------------------------------------------------------------------
# Cytoscape distinguishes between Node Opacity, Node Border Opacity, and Node Label Opacity.  we call this 'aspect' here.

setMethod ('setNodeOpacityRule', 'CytoscapeWindowClass',

   function (obj, node.attribute.name, control.points, opacities, mode, aspect='all') {

#     if (!mode %in% c ('interpolate', 'lookup')) {
#       write ("Error! RCytoscape:setNodeOpacityRule.  mode must be 'interpolate' (the default) or 'lookup'.", stderr ())
#       return ()
#       }
#
#     aspect.all = length (grep ('all', aspect))  > 0
#     aspect.fill = length (grep ('fill', aspect)) > 0
#     aspect.border = length (grep ('border', aspect)) > 0
#     aspect.label = length (grep ('label', aspect)) > 0
#
#     if (aspect.all) {
#       aspect.fill = TRUE
#       aspect.border = TRUE
#       aspect.label = TRUE
#       }
#
#     if (aspect.fill == FALSE && aspect.border == FALSE && aspect.label == FALSE) {
#       specific.options = 'fill, border, label'
#       msg.1 = "Error! RCytoscape:setNodeOpacityRule.  apect must be 'all' (the default) "
#       msg.2 = sprintf ("or some combination, in any order, of %s", specific.options)
#       write (msg.1, stderr ())
#       write (msg.2, stderr ())
#       return ()
#       }
#
#     if (mode=='interpolate') {  # need a 'below' opacity and an 'above' opacity.  so there should be two more opacities than control.points 
#       if (length (control.points) == length (opacities)) { # caller did not supply 'below' and 'above' values; manufacture them
#         opacities = c (opacities [1], opacities, opacities [length (opacities)])
#         #write ("RCytoscape::setNodeOpacityRule, no 'below' or 'above' opacities specified.  Inferred from supplied opacities.", stderr ());
#         } # 
#
#       good.args = length (control.points) == (length (opacities) - 2)
#       if (!good.args) {
#         write (sprintf ('cp: %d', length (control.points)), stderr ())
#         write (sprintf ('co: %d', length (opacities)), stderr ())
#         write ("Error! RCytoscape:setNodeOpacityRule, interpolate mode.", stderr ())
#         write ("Expecting 1 opacity for each control.point, one for 'above' opacity, one for 'below' opacity.", stderr ())
#         return ()
#         }
#       
#       if (aspect.fill)
#         result = xml.rpc (obj@uri, 'Cytoscape.createContinuousNodeVisualStyle', node.attribute.name, 'Node Opacity', control.points, opacities, FALSE)
#       if (aspect.border) 
#         result = xml.rpc (obj@uri, 'Cytoscape.createContinuousNodeVisualStyle', node.attribute.name, 'Node Border Opacity', control.points, 
#                           opacities, FALSE)
#       if (aspect.label) 
#         result = xml.rpc (obj@uri, 'Cytoscape.createContinuousNodeVisualStyle', node.attribute.name, 'Node Label Opacity', control.points, 
#                           opacities, FALSE)
#       invisible (result)
#       } # if mode==interpolate
#
#     else { # mode==lookup, use a discrete rule, with no interpolation
#       good.args = length (control.points) == length (opacities)
#       if (!good.args) {
#         write (sprintf ('cp: %d', length (control.points)), stderr ())
#         write (sprintf ('co: %d', length (opacities)), stderr ())
#         write ("Error! RCytoscape:setNodeOpacityRule.  Expecting exactly as many opacities as control.points in lookup mode.", stderr ())
#         return ()
#         }
#
#       default.style = 'default'
#       default.opacity = 255;
#       if (length (control.points) == 1) {   # code around the requirement that one-element lists are turned into scalars
#         control.points = rep (control.points, 2)
#         opacities = rep (opacities, 2)
#         } 
#
#       if (aspect.fill)
#         result = xml.rpc (obj@uri, 'Cytoscape.createDiscreteMapper', default.style, 
#                           node.attribute.name, 'Node Opacity', as.character (default.opacity), control.points, as.character (opacities))
#       if (aspect.border) 
#         result = xml.rpc (obj@uri, 'Cytoscape.createDiscreteMapper', default.style, 
#                           node.attribute.name, 'Node Border Opacity', as.character (default.opacity), control.points, as.character (opacities))
#       if (aspect.label) 
#         result = xml.rpc (obj@uri, 'Cytoscape.createDiscreteMapper', default.style, 
#                           node.attribute.name, 'Node Label Opacity', as.character (default.opacity), control.points, as.character (opacities))
#       invisible (result)
#       } # else: !interpolate
     }) # setNodeOpacityRule

#------------------------------------------------------------------------------------------------------------------------
setMethod ('setNodeBorderColorRule', 'CytoscapeWindowClass',

   function (obj, node.attribute.name, control.points, colors, mode, default.color='#000000') {

#     if (!mode %in% c ('interpolate', 'lookup')) {
#       write ("Error! RCytoscape:setNodeBorderColorRule.  mode must be 'interpolate' (the default) or 'lookup'.", stderr ())
#       return ()
#       }
#
#     setDefaultNodeBorderColor (obj, default.color)
#     
#     if (mode=='interpolate') {  # need a 'below' color and an 'above' color.  so there should be two more colors than control.points 
#       if (length (control.points) == length (colors))  # caller did not supply 'below' and 'above' values; manufacture them
#         colors = c (default.color, colors, default.color)
#
#       good.args = length (control.points) == (length (colors) - 2)
#       if (!good.args) {
#         write (sprintf ('cp: %d', length (control.points)), stderr ())
#         write (sprintf ('co: %d', length (colors)), stderr ())
#         write ("Error! RCytoscape:setNodeBorderColorRule, interpolate mode.", stderr ())
#         write ("Expecting 1 color for each control.point, one for 'above' color, one for 'below' color.", stderr ())
#         return ()
#         }
#       result = xml.rpc (obj@uri, 'Cytoscape.createContinuousNodeVisualStyle', node.attribute.name, 'Node Border Color', control.points, colors, FALSE)
#       invisible (result)
#       } # if mode==interpolate
#
#     else { # use a discrete rule, with no interpolation
#       good.args = length (control.points) == length (colors)
#       if (!good.args) {
#         write (sprintf ('cp: %d', length (control.points)), stderr ())
#         write (sprintf ('co: %d', length (colors)), stderr ())
#         write ("Error! RCytoscape:setNodeBorderColorRule.  Expecting exactly as many colors as control.points in lookup mode.", stderr ())
#         return ()
#         }
#
#       default.style = 'default'
#       if (length (control.points) == 1) {   # code around the requirement that one-element lists are turned into scalars
#         control.points = rep (control.points, 2)
#         colors = rep (colors, 2)
#         } 
#       result = xml.rpc (obj@uri, 'Cytoscape.createDiscreteMapper', default.style, node.attribute.name,
#                          'Node Border Color', default.color, control.points, colors)
#       invisible (result)
#       } # else: !interpolate
     }) # setNodeBorderColorRule

#------------------------------------------------------------------------------------------------------------------------
setMethod ('setNodeBorderWidthRule', 'CytoscapeWindowClass',

   function (obj, node.attribute.name, attribute.values, line.widths, default.width=1) {

#     if (length (attribute.values) == 1) {  # hack: list of length 1 treated as scalar, failing method match -- double into a list
#       attribute.values = rep (attribute.values, 2)
#       line.widths = rep (line.widths, 2)
#       }
#     id = as.character (obj@window.id)
#     visual.property.type.name = 'Node Line Width'  # see class cytoscape.visual.VisualPropertyType
#
#     if (length (attribute.values) == 1) {   # code around the requirement that one-element lists are turned into scalars
#       attribute.values = rep (attribute.values, 2)
#       line.widths = rep (line.widths, 2)
#       } 
#     result = xml.rpc (obj@uri, 'Cytoscape.createDiscreteMapper', 'default', node.attribute.name, 
#                       'Node Line Width', as.character (default.width), attribute.values, as.character (line.widths))
#     invisible (result)
     })

# ------------------------------------------------------------------------------
setMethod('setDefaultNodeShape', 'CytoscapeConnectionClass', 
    function(obj, new.shape, vizmap.style.name='default') {
        if(new.shape %in% getNodeShapes(obj)) {
            style = list(visualProperty = "NODE_SHAPE", value = new.shape)
            setVisualProperty(obj, style, vizmap.style.name)
        } else {
            write(sprintf("Invalid shape value: '%s'. Use getNodeShapes() to find valid values.", new.shape), stderr ())
        }
})
## END setDefaultNodeShape

# ------------------------------------------------------------------------------
setMethod('setDefaultNodeSize', 'CytoscapeConnectionClass', 
  function(obj, new.size, vizmap.style.name='default') {
    style = list(visualProperty = "NODE_SIZE", value = new.size)
    setVisualProperty(obj, style, vizmap.style.name)
})
## END setDefaultNodeSize

# ------------------------------------------------------------------------------
setMethod('setDefaultNodeColor', 'CytoscapeConnectionClass', 
  function(obj, new.color, vizmap.style.name='default') {
    style = list(visualProperty = "NODE_FILL_COLOR", value = new.color)
    setVisualProperty(obj, style, vizmap.style.name)
})
## END setDefaultNodeColor

# ------------------------------------------------------------------------------
setMethod('setDefaultNodeBorderColor', 'CytoscapeConnectionClass', 
  function(obj, new.color, vizmap.style.name='default') {
    style = list(visualProperty = "NODE_BORDER_PAINT", value = new.color)
    setVisualProperty(obj, style, vizmap.style.name)
})
## END setDefaultNodeBorderColor

# ------------------------------------------------------------------------------
setMethod('setDefaultNodeBorderWidth', 'CytoscapeConnectionClass', 
  function(obj, new.width, vizmap.style.name='default') {
    style = list(visualProperty = "NODE_BORDER_WIDTH", value = new.width) 
    setVisualProperty(obj, style, vizmap.style.name)
})
## END setDefaultNodeBorderWidth

# ------------------------------------------------------------------------------
setMethod('setDefaultNodeFontSize', 'CytoscapeConnectionClass', 
  function(obj, new.size, vizmap.style.name='default') {
    style = list(visualProperty = "NODE_LABEL_FONT_SIZE", value = new.size)
    setVisualProperty(obj, style, vizmap.style.name)
})
## END setDefaultNodeFontSize

# ------------------------------------------------------------------------------
setMethod('setDefaultNodeLabelColor', 'CytoscapeConnectionClass', 
  function(obj, new.color, vizmap.style.name='default') {
    style = list(visualProperty = "NODE_LABEL_COLOR", value = new.color)
    setVisualProperty(obj, style, vizmap.style.name)
})
## END setDefaultNodeLabelColor

# ------------------------------------------------------------------------------
setMethod('setDefaultEdgeLineWidth', 'CytoscapeConnectionClass', 
  function(obj, new.width, vizmap.style.name='default') {
    style = list(visualProperty = "EDGE_WIDTH", value = new.width) 
    setVisualProperty(obj, style, vizmap.style.name)
})
## END setDefaultEdgeLineWidth

# ------------------------------------------------------------------------------
setMethod('setDefaultEdgeColor', 'CytoscapeConnectionClass', 
  function(obj, new.color, vizmap.style.name='default') {
    style = list(visualProperty = "EDGE_STROKE_UNSELECTED_PAINT", value = new.color) 
    setVisualProperty(obj, style, vizmap.style.name)
})
## END setDefaultEdgeColor

# ------------------------------------------------------------------------------
setMethod('setDefaultEdgeFontSize', 'CytoscapeConnectionClass', 
  function(obj, new.size, vizmap.style.name='default') {
    style = list(visualProperty = "EDGE_LABEL_FONT_SIZE", value = new.size)
    setVisualProperty(obj, style, vizmap.style.name)
})
## END setDefaultEdgeFontSize

#------------------------------------------------------------------------------------------------------------------------
setMethod ('setNodeShapeRule', 'CytoscapeWindowClass',

   function (obj, node.attribute.name, attribute.values, node.shapes, default.shape='ellipse') {
#     if (length (attribute.values) == 1) {  # hack: list of length 1 treated as scalar, failing method match -- double into a list
#       attribute.values = rep (attribute.values, 2)
#       node.shapes = rep (node.shapes, 2)
#       }
#     setDefaultNodeShape (obj, default.shape)
#     id = as.character (obj@window.id)
#     result = xml.rpc (obj@uri, "Cytoscape.setNodeShapeRule", id, node.attribute.name, default.shape, 
#                      attribute.values, node.shapes, .convert=TRUE)
#     invisible (result)
     }) # setNodeShapeRule

#------------------------------------------------------------------------------------------------------------------------
setMethod ('setNodeSizeRule', 'CytoscapeWindowClass',

#   function (obj, node.attribute.name, attribute.values, node.sizes) {
#     id = as.character (obj@window.id)
#        # take the first and last node size, prepend and append them respectively, so that there are 2 more
#        # visual attribute values (in this case, node size in pixels) than there are node data attribute values
#     adjusted.node.sizes = c (node.sizes [1], node.sizes, c (node.sizes [length (node.sizes)]))
#     result = xml.rpc (obj@uri, 'Cytoscape.createContinuousNodeVisualStyle', node.attribute.name, 'Node Size', 
#                       attribute.values, adjusted.node.sizes, FALSE)
#     return (result)
#     }) # setNodeSizeRule

   function (obj, node.attribute.name, control.points, node.sizes, mode, default.size=40) {

#     if (!mode %in% c ('interpolate', 'lookup')) {
#       write ("Error! RCytoscape:setNodeSizeRule.  mode must be 'interpolate' (the default) or 'lookup'.", stderr ())
#       return ()
#       }
#
#     setDefaultNodeSize (obj, default.size)
#
#     if (mode=='interpolate') {  # need a 'below' size and an 'above' size.  so there should be two more colors than control.points 
#       if (length (control.points) == length (node.sizes)) { # caller did not supply 'below' and 'above' values; manufacture them
#         node.sizes = c (node.sizes [1], node.sizes, node.sizes [length (node.sizes)])
#         write ("RCytoscape::setNodeSizeRule, no 'below' or 'above' sizes specified.  Inferred from node.sizes.", stderr ())
#         } # 
#
#       good.args = length (control.points) == (length (node.sizes) - 2)
#       if (!good.args) {
#         write (sprintf ('cp: %d', length (control.points)), stderr ())
#         write (sprintf ('co: %d', length (node.sizes)), stderr ())
#         write ("Error! RCytoscape:setNodeSizeRule, interpolate mode.", stderr ())
#         write ("Expecting 1 node.size for each control.point, one for 'above' size, one for 'below' size.", stderr ())
#         return ()
#         }
#       result = xml.rpc (obj@uri, 'Cytoscape.createContinuousNodeVisualStyle', node.attribute.name, 'Node Size', control.points, node.sizes, FALSE)
#       invisible (result)
#       } # if mode==interpolate
#
#     else { # use a discrete rule, with no interpolation
#       good.args = length (control.points) == length (node.sizes)
#       if (!good.args) {
#         write (sprintf ('cp: %d', length (control.points)), stderr ())
#         write (sprintf ('co: %d', length (node.sizes)), stderr ())
#         write ("Error! RCytoscape:setNodeSizeRule.  Expecting exactly as many node.sizes as control.points in lookup mode.", stderr ())
#         return ()
#         }
#
#       default.style = 'default'
#       if (length (control.points) == 1) {   # code around the requirement that one-element lists are turned into scalars
#         control.points = rep (control.points, 2)
#         node.sizes = rep (node.sizes, 2)
#         } 
#
#       result = xml.rpc (obj@uri, 'Cytoscape.createDiscreteMapper', default.style, 
#                         node.attribute.name, 'Node Size', as.character (default.size), 
#                         as.character (control.points), as.character (node.sizes))
#       invisible (result)
#       } # else: !interpolate
     }) # setNodeSizeRule


#------------------------------------------------------------------------------------------------------------------------
#setMethod ('setEdgeColorRule', 'CytoscapeWindowClass',
#
# function (obj, attribute.name, attribute.values, colors, default.color='#000000') {
#     if (length (attribute.values) == 1) {  # hack: list of length 1 treated as scalar, failing method match -- double into a list
#       attribute.values = rep (attribute.values, 2)
#       colors = rep (colors, 2)
#       }
#     setDefaultEdgeColor (obj, default.color)
#     id = as.character (obj@window.id)
#     default.color = '#000000'
#     result = xml.rpc (obj@uri, "Cytoscape.setEdgeColorRule", id, attribute.name, default.color, attribute.values, colors, .convert=TRUE)
#     invisible (result)
#     }) # setEdgeColorRule
#
#------------------------------------------------------------------------------------------------------------------------
setMethod ('setEdgeColorRule', 'CytoscapeWindowClass',

   function (obj, edge.attribute.name, control.points, colors, mode, default.color='#FFFFFF') {

#     if (!mode %in% c ('interpolate', 'lookup')) {
#       write ("Error! RCytoscape:setEdgeColorRule.  mode must be 'interpolate' (the default) or 'lookup'.", stderr ())
#       return ()
#       }
#
#     setDefaultEdgeColor (obj, default.color)
#     if (mode=='interpolate') {  # need a 'below' color and an 'above' color.  so there should be two more colors than control.points 
#       if (length (control.points) == length (colors)) { # caller did not supply 'below' and 'above' values; manufacture them
#         colors = c (colors [1], colors, colors [length (colors)])
#         #write ("RCytoscape::setEdgeColorRule, no 'below' or 'above' colors specified.  Inferred from supplied colors.", stderr ());
#         } # 
#
#       good.args = length (control.points) == (length (colors) - 2)
#       if (!good.args) {
#         write (sprintf ('cp: %d', length (control.points)), stderr ())
#         write (sprintf ('co: %d', length (colors)), stderr ())
#         write ("Error! RCytoscape:setEdgeColorRule, interpolate mode.", stderr ())
#         write ("Expecting 1 color for each control.point, one for 'above' color, one for 'below' color.", stderr ())
#         return ()
#         }
#       result = xml.rpc (obj@uri, 'Cytoscape.createContinuousEdgeVisualStyle', edge.attribute.name, 'Edge Color', control.points, colors, FALSE)
#       invisible (result)
#       } # if mode==interpolate
#
#     else { # use a discrete rule, with no interpolation
#       good.args = length (control.points) == length (colors)
#       if (!good.args) {
#         write (sprintf ('cp: %d', length (control.points)), stderr ())
#         write (sprintf ('co: %d', length (colors)), stderr ())
#         write ("Error! RCytoscape:setEdgeColorRule.  Expecting exactly as many colors as control.points in lookup mode.", stderr ())
#         return ()
#         }
#
#       default.style = 'default'
#       if (length (control.points) == 1) {   # code around the requirement that one-element lists are turned into scalars
#         control.points = rep (control.points, 2)
#         colors = rep (colors, 2)
#         } 
#       result = xml.rpc (obj@uri, 'Cytoscape.createDiscreteMapper', default.style, 
#                         edge.attribute.name, 'Edge Color', default.color, control.points, colors)
#       invisible (result)
#       } # else: !interpolate
     }) # setEdgeColorRule

#------------------------------------------------------------------------------------------------------------------------
setMethod ('setEdgeOpacityRule', 'CytoscapeWindowClass',

   function (obj, edge.attribute.name, control.points, opacities, mode) {

#     if (!mode %in% c ('interpolate', 'lookup')) {
#       write ("Error! RCytoscape:setEdgeOpacityRule.  mode must be 'interpolate' (the default) or 'lookup'.", stderr ())
#       return ()
#       }
# 
#     aspects = c ('Edge Opacity', 'Edge Target Arrow Opacity', 'Edge Source Arrow Opacity')
#
#     if (mode=='interpolate') {  # need a 'below' opacity and an 'above' opacity.  so there should be two more opacities than control.points 
#       if (length (control.points) == length (opacities)) { # caller did not supply 'below' and 'above' values; manufacture them
#         opacities = c (opacities [1], opacities, opacities [length (opacities)])
#         } # 
#
#       good.args = length (control.points) == (length (opacities) - 2)
#       if (!good.args) {
#         write (sprintf ('cp: %d', length (control.points)), stderr ())
#         write (sprintf ('co: %d', length (opacities)), stderr ())
#         write ("Error! RCytoscape:setEdgeOpacityRule, interpolate mode.", stderr ())
#         write ("Expecting 1 opacity value for each control.point, one for 'above' opacity, one for 'below' opacity.", stderr ())
#         return ()
#         }
#       for (aspect in aspects)
#         result = xml.rpc (obj@uri, 'Cytoscape.createContinuousEdgeVisualStyle', edge.attribute.name, aspect, control.points, opacities, FALSE)
#       invisible (result)
#       } # if mode==interpolate
#
#     else { # use a discrete rule, with no interpolation
#       good.args = length (control.points) == length (opacities)
#       if (!good.args) {
#         write (sprintf ('cp: %d', length (control.points)), stderr ())
#         write (sprintf ('co: %d', length (opacities)), stderr ())
#         write ("Error! RCytoscape:setEdgeColorRule.  Expecting exactly as many opacities as control.points in lookup mode.", stderr ())
#         return ()
#         }
#
#       default.style = 'default'
#       if (length (control.points) == 1) {   # code around the requirement that one-element lists are turned into scalars
#         control.points = rep (control.points, 2)
#         opacities = rep (opacities, 2)
#         } 
#       opacities = as.character (opacities)
#       for (aspect in aspects) {
#         result = xml.rpc (obj@uri, 'Cytoscape.createDiscreteMapper', default.style, edge.attribute.name, aspect, '255', control.points, opacities)
#         }
#
#       invisible (result)
#       } # else: !interpolate
     }) # setEdgeColorRule

#------------------------------------------------------------------------------------------------------------------------
setMethod ('setEdgeLineStyleRule', 'CytoscapeWindowClass',

   function (obj, edge.attribute.name, attribute.values, line.styles, default.style='SOLID') {
#     if (length (attribute.values) == 1) {  # hack: list of length 1 treated as scalar, failing method match -- double into a list
#       attribute.values = rep (attribute.values, 2)
#       line.styles = rep (line.styles, 2)
#       }
#     id = as.character (obj@window.id)
#     result = xml.rpc (obj@uri, "Cytoscape.setEdgeLineStyleRule", id, edge.attribute.name, default.style, 
#                       attribute.values, line.styles, .convert=TRUE)
#     invisible (result)
     }) # set.edge.line.style.rule

#------------------------------------------------------------------------------------------------------------------------
setMethod ('setEdgeLineWidthRule', 'CytoscapeWindowClass',

   function (obj, edge.attribute.name, attribute.values, line.widths, default.width=1) {
#     if (length (attribute.values) == 1) {  # hack: list of length 1 treated as scalar, failing method match -- double into a list
#       attribute.values = rep (attribute.values, 2)
#       line.widths = rep (line.widths, 2)
#       }
#     id = as.character (obj@window.id)
#     visual.property.type.name = 'Edge Line Width'  # see class cytoscape.visual.VisualPropertyType
#
#     if (length (attribute.values) == 1) {   # code around the requirement that one-element lists are turned into scalars
#       attribute.values = rep (attribute.values, 2)
#       line.widths = rep (line.widths, 2)
#       } 
#     result = xml.rpc (obj@uri, 'Cytoscape.createDiscreteMapper', 'default', edge.attribute.name, 
#                       'Edge Line Width', as.character (default.width), attribute.values, as.character (line.widths))
#     invisible (result)
     })

#------------------------------------------------------------------------------------------------------------------------
setMethod ('setEdgeTargetArrowRule', 'CytoscapeWindowClass', 

   function (obj, edge.attribute.name, attribute.values, arrows, default='Arrow') {
#     # write (sprintf ('before -- attribute.values: %d   arrows: %d', length (attribute.values), length (arrows)), stderr ())
#     if (length (attribute.values) == 1) {  # hack: list of length 1 treated as scalar, failing method match -- double into a list
#       attribute.values = rep (attribute.values, 2)
#       arrows = rep (arrows, 2)
#       }
#     #write (sprintf ('after -- attribute.values: %d   arrows: %d', length (attribute.values), length (arrows)), stderr ())
#     id = as.character (obj@window.id)
#     result = xml.rpc (obj@uri, "Cytoscape.setEdgeTargetArrowRule", id, edge.attribute.name, default, attribute.values, arrows, .convert=TRUE)
#     invisible (result)
     }) # setTargetArrowRule

#------------------------------------------------------------------------------------------------------------------------
setMethod ('setEdgeSourceArrowRule', 'CytoscapeWindowClass', 

   function (obj, edge.attribute.name, attribute.values, arrows, default='Arrow') {
#     if (length (attribute.values) == 1) {  # hack: list of length 1 treated as scalar, failing method match -- double into a list
#       attribute.values = rep (attribute.values, 2)
#       arrows = rep (arrows, 2)
#       }
#     id = as.character (obj@window.id)
#     result = xml.rpc (obj@uri, "Cytoscape.setEdgeSourceArrowRule", id, edge.attribute.name, default, attribute.values, arrows, .convert=TRUE)
#     invisible (result)
     }) # setTargetArrowRule

#------------------------------------------------------------------------------------------------------------------------
setMethod ('setEdgeTargetArrowColorRule', 'CytoscapeWindowClass', 

   function (obj, edge.attribute.name, attribute.values, colors, default.color='#000000') {
#     id = as.character (obj@window.id)
#     style.name = 'default'
#
#     if (length (attribute.values) == 1) {   # code around the requirement that one-element lists are turned into scalars
#       attribute.values = rep (attribute.values, 2)
#       colors = rep (colors, 2)
#       } 
#
#     result = xml.rpc (obj@uri, "Cytoscape.createDiscreteMapper", style.name, edge.attribute.name,
#                      'Edge Target Arrow Color', default.color, attribute.values, colors, .convert=TRUE)
#     invisible (result)
     }) # setTargetArrowRule

#------------------------------------------------------------------------------------------------------------------------
setMethod ('setEdgeSourceArrowColorRule', 'CytoscapeWindowClass', 

   function (obj, edge.attribute.name, attribute.values, colors, default.color='#000000') {
#     id = as.character (obj@window.id)
#     style.name = 'default'
#
#     if (length (attribute.values) == 1) {   # code around the requirement that one-element lists are turned into scalars
#       attribute.values = rep (attribute.values, 2)
#       colors = rep (colors, 2)
#       } 
#
#     result = xml.rpc (obj@uri, "Cytoscape.createDiscreteMapper", style.name, edge.attribute.name,
#                      'Edge Source Arrow Color', default.color, attribute.values, colors, .convert=TRUE)
#     invisible (result)
     }) # setTargetArrowRule

# ------------------------------------------------------------------------------
setMethod('setNodeColorDirect', 'CytoscapeWindowClass', 
   function(obj, node.names, new.color) {
      # ensure the new color string is correct hexadecimal format
      if(substring(new.color, 1, 1) != "#" || nchar(new.color) != 7) {
         write(sprintf('illegal node color string "%s" in RCy3::setNodeColorDirect. Color needs to be expressed in hexadecimal.', new.color), stderr())
         return()
      }
      setNodePropertyDirect(obj, node.names, new.color, "NODE_FILL_COLOR")
})
## END setNodeColorDirect

# ------------------------------------------------------------------------------
# only works if node dimensions are locked(that is, tied together). see lockNodeDimensions(T/F)
setMethod('setNodeSizeDirect', 'CytoscapeWindowClass', 
   function(obj, node.names, new.sizes) {
      for(current.size in new.sizes) {
         # ensure the sizes are numbers
         if(!is.double(current.size)) {
            write(sprintf('illegal node size string "%s" in RCy3::setNodeSizeDirect. Size needs to be numeric value.', current.size), stderr())
            return()
         }
         setNodePropertyDirect(obj, node.names, new.sizes, "NODE_WIDTH")
         setNodePropertyDirect(obj, node.names, new.sizes, "NODE_HEIGHT")
      }
})
## END setNodeSizeDirect

# ------------------------------------------------------------------------------
# only works if node dimensions are not locked(that is, tied together). see lockNodeDimensions(T/F)
setMethod('setNodeWidthDirect', 'CytoscapeWindowClass', 
   function(obj, node.names, new.widths) {
      # ensure the width(s) are numbers
      for(current.width in new.widths) {
         if(!is.double(current.width)) {
            write (sprintf ('illegal node width string "%s" in RCy3::setNodeWidthDirect. Width needs to be numeric value.', current.width), stderr())
            return()
         }
      }
      setNodePropertyDirect(obj, node.names, new.widths, "NODE_WIDTH")
})
## END setNodeWidthDirect

# ------------------------------------------------------------------------------
# only works if node dimensions are not locked(that is, tied together). see lockNodeDimensions(T/F)
setMethod('setNodeHeightDirect', 'CytoscapeWindowClass', 
   function(obj, node.names, new.heights) {
      for(current.height in new.heights) {
         # ensure the height(s) are numbers
         if(!is.double(current.height)) {
            write(sprintf('illegal node height string "%s" in RCy3::setNodeHeightDirect. Height needs to be numeric value.', current.height), stderr())
            return()
         }
      }
      setNodePropertyDirect(obj, node.names, new.heights, "NODE_HEIGHT")
})
## END setNodeHeightDirect

# ------------------------------------------------------------------------------
setMethod('setNodeLabelDirect', 'CytoscapeWindowClass', 
   function(obj, node.names, new.labels) {
      setNodePropertyDirect(obj, node.names, new.labels, "NODE_LABEL")
})
## END setNodeLabelDirect

# ------------------------------------------------------------------------------
setMethod('setNodeFontSizeDirect', 'CytoscapeWindowClass',
   function(obj, node.names, new.sizes) {
      for(current.size in new.sizes) {
         # ensure the sizes are numbers
         if(!is.double(current.size)) {
            write(sprintf('illegal node size string "%s" in RCy3::setNodeFontSizeDirect. Size needs to be numeric.', current.size), stderr())
            return()
         }
      }
      setNodePropertyDirect(obj, node.names, new.sizes, "NODE_LABEL_FONT_SIZE")
})
## END setNodeFontSizeDirect

# ------------------------------------------------------------------------------
setMethod('setNodeLabelColorDirect', 'CytoscapeWindowClass', 
   function(obj, node.names, new.colors) {
      for(current.color in new.colors) {
         # ensure the color is formated in the correct hexadecimal style
         if(substring(current.color, 1, 1) != "#" || nchar(current.color) != 7) {
            write (sprintf ('illegal color string "%s" in RCy3::setNodeLabelColorDirect. It needs to be in hexadecimal.', current.color), stderr())
            return()
         }
      }
      setNodePropertyDirect(obj, node.names, new.colors, "NODE_LABEL_COLOR")
})
## END setNodeLabelColorDirect

# ------------------------------------------------------------------------------
setMethod('setNodeShapeDirect', 'CytoscapeWindowClass', 
    function(obj, node.names, new.shapes) {
        for(node.shape in new.shapes) {
            if(!node.shape %in% getNodeShapes(obj)) {
                write(sprintf("Invalid node shape: '%s'. Use getNodeShapes() to find valid values.", node.shape), stderr())
                return()
            }
        }
        setNodePropertyDirect(obj, node.names, new.shapes, "NODE_SHAPE")
})
## END setNodeShapeDirect

# ------------------------------------------------------------------------------
setMethod('setNodeImageDirect', 'CytoscapeWindowClass', 
   function(obj, node.names, image.urls) {

#     if (length (image.urls) == 1)
#       image.urls = rep (image.urls, length (node.names))
#
#     if (length (node.names) != length (image.urls)) {
#       msg = sprintf ('error in RCytoscape::setNodeImageDirect.  image.urls count (%d) is neither 1 nor same as node.names count (%d)',
#                      length (image.urls), length (node.names))
#       write (msg, stderr ())
#       return ()
#       }
#    
#     id = as.character (obj@window.id)
#     for (i in 1:length (node.names)) {
#       setNodeShapeDirect (obj, node.names [i], 'rect')
#       setNodeLabelDirect (obj, node.names [i], '')
#       result = xml.rpc (obj@uri, "Cytoscape.setNodeProperty", node.names [i], 'Node Custom Graphics 1', image.urls [i])
#       }
#     invisible (result)
     })

# ------------------------------------------------------------------------------
setMethod('setNodeBorderWidthDirect', 'CytoscapeWindowClass', 
   function(obj, node.names, new.sizes) {
      for(current.size in new.sizes) {
         # ensure the sizes are numbers
         if(!is.double(current.size)) {
            write(sprintf('illegal width string "%s" in RCy3::setNodeBorderWidthDirect. Width needs to be a numeric value.', current.size), stderr())
            return()
         }
      }
      setNodePropertyDirect(obj, node.names, new.sizes, "NODE_BORDER_WIDTH")
})
## END setNodeBorderWidthDirect

# ------------------------------------------------------------------------------
setMethod('setNodeBorderColorDirect', 'CytoscapeWindowClass', 
   function(obj, node.names, new.color) {
      # ensure the new color string is correct hexadecimal format
      if(substring(new.color, 1, 1) != "#" || nchar(new.color) != 7) {
         write(sprintf('illegal color string "%s" in RCy3::setNodeBorderColorDirect. Color needs to be expressed in hexadecimal.', new.color), stderr())
         return()
      }
      setNodePropertyDirect(obj, node.names, new.color, "NODE_BORDER_PAINT")
})
## END setNodeBorderColorDirect

# ------------------------------------------------------------------------------
setMethod('setNodeOpacityDirect', 'CytoscapeWindowClass',
   function(obj, node.names, new.values) {
      # ensure that the opacity is specified as number between 0 and 255
      if(!is.double(new.values) || new.values < 0  || new.values > 255) {
         write(sprintf('illegal opacity string "%s" in RCy3::setNodeOpacityDirect. It needs to be between 0 and 255.', new.values), stderr())
         return()
      }
      setNodePropertyDirect(obj, node.names, new.values, "NODE_TRANSPARENCY")
      setNodePropertyDirect(obj, node.names, new.values, "NODE_BORDER_TRANSPARENCY")
      setNodePropertyDirect(obj, node.names, new.values, "NODE_LABEL_TRANSPARENCY")
})
## END setNodeOpacityDirect

# ------------------------------------------------------------------------------
setMethod('setNodeFillOpacityDirect', 'CytoscapeWindowClass', 
   function(obj, node.names, new.values) {
      # ensure that the opacity is specified as number between 0 and 255
      if(!is.double(new.values) || new.values < 0  || new.values > 255) {
         write(sprintf('illegal opacity string "%s" in RCy3::setNodeFillOpacityDirect. It needs to be between 0 and 255.', new.values), stderr())
         return()
      }
      setNodePropertyDirect(obj, node.names, new.values, "NODE_TRANSPARENCY")
})
## END setNodeFillOpacityDirect

# ------------------------------------------------------------------------------
setMethod('setNodeBorderOpacityDirect', 'CytoscapeWindowClass', 
   function(obj, node.names, new.values) {
      # ensure that the opacity is specified as number between 0 and 255
      if(!is.double(new.values) || new.values < 0  || new.values > 255) {
         write(sprintf('illegal opacity string "%s" in RCy3::setNodeBorderOpacityDirect. It needs to be between 0 and 255.', new.values), stderr())
         return()
      }
      setNodePropertyDirect(obj, node.names, new.values, "NODE_BORDER_TRANSPARENCY")
})
## END setNodeBorderOpacityDirect

# ------------------------------------------------------------------------------
setMethod('setNodeLabelOpacityDirect', 'CytoscapeWindowClass', 
   function(obj, node.names, new.values) {
      # ensure that the opacity is specified as number between 0 and 255
      if(!is.double(new.values) || new.values < 0  || new.values > 255) {
         write(sprintf('illegal opacity string "%s" in RCy3::setNodeLabelOpacityDirect. It needs to be between 0 and 255.', new.values), stderr())
         return()
      }
      setNodePropertyDirect(obj, node.names, new.values, "NODE_LABEL_TRANSPARENCY")
})
## END setNodeLabelOpacityDirect

# ------------------------------------------------------------------------------
setMethod('setEdgeOpacityDirect', 'CytoscapeWindowClass', 
   function(obj, edge.names, new.values) {
      for(current.value in new.values) {
         # ensure the opacity value is a double and between 0 and 255
         if(! is.double(current.value) || current.value < 0  || current.value > 255) {
            write(sprintf('illegal opacity string "%s" in RCy3::setEdgeLabelOpacityDirect. It needs to be between 0 and 255.', current.value), stderr())
            return()
         }
      }
      setEdgePropertyDirect(obj, edge.names, new.values, "EDGE_LABEL_TRANSPARENCY")
      setEdgePropertyDirect(obj, edge.names, new.values, "EDGE_TRANSPARENCY")
})
## END setEdgeOpacityDirect

#------------------------------------------------------------------------------------------------------------------------
#setMethod ('setNodeFillOpacitiesDirect', 'CytoscapeWindowClass',
#   function (obj, node.names, new.values) {
#     id = as.character (obj@window.id)
#     if (length (new.values) == 1)
#       new.values = rep (new.values, length (node.names))
#     properties = rep ('Node Opacity', length (node.names))
#     result = xml.rpc (obj@uri, "Cytoscape.setNodeProperties", node.names, properties, as.character (new.values))
#     invisible (result)
#     })
#------------------------------------------------------------------------------------------------------------------------
#setMethod ('setNodeBorderOpacityDirect', 'CytoscapeWindowClass',
#   function (obj, node.names, new.value) {
#     id = as.character (obj@window.id)
#     for (node.name in node.names)
#       result = xml.rpc (obj@uri, "Cytoscape.setNodeProperty", node.name, 'Node Border Opacity', as.character (new.value))
#     invisible (result)
#     })
#------------------------------------------------------------------------------------------------------------------------
#setMethod ('setNodeBorderOpacitiesDirect', 'CytoscapeWindowClass',
#   function (obj, node.names, new.values) {
#     id = as.character (obj@window.id)
#     if (length (new.values) == 1)
#       new.values = rep (new.values, length (node.names))
#     properties = rep ('Node Border Opacity', length (node.names))
#     result = xml.rpc (obj@uri, "Cytoscape.setNodeProperties", node.names, properties, as.character (new.values))
#     invisible (result)
#     })
#------------------------------------------------------------------------------------------------------------------------
#setMethod ('setNodeLabelOpacityDirect', 'CytoscapeWindowClass',
#   function (obj, node.names, new.value) {
#     id = as.character (obj@window.id)
#     for (node.name in node.names)
#       result = xml.rpc (obj@uri, "Cytoscape.setNodeProperty", node.name, 'Node Label Opacity', as.character (new.value))
#     invisible (result)
#     })
#------------------------------------------------------------------------------------------------------------------------
#setMethod ('setNodeLabelOpacitiesDirect', 'CytoscapeWindowClass',
#   function (obj, node.names, new.values) {
#     id = as.character (obj@window.id)
#     if (length (new.values) == 1)
#       new.values = rep (new.values, length (node.names))
#     properties = rep ('Node Label Opacity', length (node.names))
#     result = xml.rpc (obj@uri, "Cytoscape.setNodeProperties", node.names, properties, as.character (new.values))
#     invisible (result)
#     })
#------------------------------------------------------------------------------------------------------------------------
#setMethod ('setEdgeOpacityDirect', 'CytoscapeWindowClass',
#
#   function (obj, edge.names, new.values) {
#
#     id = as.character (obj@window.id)
#     if (length (edge.names) == 1) {
#       edge.name = edge.names [1]
#       new.value = new.values [1]
#       result = xml.rpc (obj@uri, "Cytoscape.setEdgeProperty", edge.name, 'Edge Opacity', as.character (new.value))
#       invisible (result)
#       } # 1 edge.name only
#     else {
#       if (length (new.values) == 1)
#         new.values = rep (new.values, length (edge.names))
#       properties = rep ('Edge Opacity', length (edge.names))
#       print ('--- setEdgeOpacitiesDirect')
#       print (edge.names)
#       print (properties)
#       print (as.character (new.values))
#       result = xml.rpc (obj@uri, "Cytoscape.setEdgeProperties", edge.names, properties, as.character (new.values))
#       print ('--- back from xml.rpc')
#       invisible (result)
#       } # multiple edges
#     })
#------------------------------------------------------------------------------------------------------------------------
#setMethod ('setEdgeOpacitiesDirect', 'CytoscapeWindowClass',
#   function (obj, edge.names, new.values) {
#     id = as.character (obj@window.id)
#     if (length (new.values) == 1)
#       new.values = rep (new.values, length (edge.names))
#     properties = rep ('Edge Opacity', length (edge.names))
#     print ('--- setEdgeOpacitiesDirect')
#     print (edge.names)
#     print (properties)
#     print (as.character (new.values))
#     result = xml.rpc (obj@uri, "Cytoscape.setEdgeProperties", edge.names, properties, as.character (new.values))
#     print ('--- back from xml.rpc')
#     invisible (result)
#     })

# ------------------------------------------------------------------------------
setMethod('setEdgeColorDirect', 'CytoscapeWindowClass', 
   function(obj, edge.names, new.value) {
      for(current.color in new.value) {
         # ensure the color is formated in correct hexadecimal style
         if((substring(current.color, 1, 1) != "#") || (nchar(current.color) != 7)) {
            write(sprintf('illegal color string "%s" in RCy3::setEdgeColorDirect. Color needs to be in hexadecimal format.', current.color), stderr())
            result()
         }
      }
      # TO-DO maybe the visual property should be EDGE_PAINT instead (should check)
      setEdgePropertyDirect(obj, edge.names, new.value, "EDGE_STROKE_UNSELECTED_PAINT")
})
## END setEdgeColorDirect

# ------------------------------------------------------------------------------
setMethod('setEdgeLabelDirect', 'CytoscapeWindowClass', 
   function(obj, edge.names, new.value) {
      setEdgePropertyDirect(obj, edge.names, new.value, "EDGE_LABEL")
})
## END setEdgeLabelDirect

# ------------------------------------------------------------------------------
setMethod('setEdgeFontFaceDirect', 'CytoscapeWindowClass', 
   function(obj, edge.names, new.value) {
      setEdgePropertyDirect(obj, edge.names, new.value, "EDGE_LABEL_FONT_FACE")
})
## END setEdgeFontFaceDirect

# ------------------------------------------------------------------------------
setMethod('setEdgeFontSizeDirect', 'CytoscapeWindowClass', 
   function(obj, edge.names, new.value) {
      for(current.size in new.value) {
         # ensure the sizes are valid numbers
         if(!is.double(current.size)) {
            write(sprintf('illegal font string "%s" in RCy3::setEdgeFontSizeDirect. It needs to be numberic value.', current.size), stderr())
            return()
         }
      }
      setEdgePropertyDirect(obj, edge.names, new.value, "EDGE_LABEL_FONT_SIZE")
})
## END setEdgeFontSizeDirect

# ------------------------------------------------------------------------------
setMethod('setEdgeLabelColorDirect', 'CytoscapeWindowClass', 
   function(obj, edge.names, new.value) {
      for(current.color in new.value){
         # ensure the color is formated in the correct hexadecimal style
         if((substring(current.color, 1, 1) != "#") || (nchar(current.color) != 7)) {
            write(sprintf('illegal color string "%s" in RCy3::setEdgeLabelColorDirect. It needs to be in hexadecimal format.', current.color), stderr())
            return()
         }
      }
      setEdgePropertyDirect(obj, edge.names, new.value, "EDGE_LABEL_COLOR")
})
## END setEdgeLabelColorDirect

# ------------------------------------------------------------------------------
setMethod('setEdgeTooltipDirect', 'CytoscapeWindowClass', 
   function(obj, edge.names, new.values) {
      setEdgePropertyDirect(obj, edge.names, new.values, "EDGE_TOOLTIP")
})
## END setEdgeTooltipDirect

# ------------------------------------------------------------------------------
setMethod('setEdgeLineWidthDirect', 'CytoscapeWindowClass', 
   function(obj, edge.names, new.value) {
      for(current.width in new.value) {
         # ensure the sizes are numbers
         if(!is.double(current.width)) {
            write(sprintf('illegal line width string "%s" in RCy3::setEdgeLineWidthDirect. It needs to be a numeric value.', current.width), stderr())
            return()
         }
      }
      setEdgePropertyDirect(obj, edge.names, new.value, "EDGE_WIDTH")
})
## END setEdgeLineWidthDirect 

# ------------------------------------------------------------------------------
setMethod('setEdgeLineStyleDirect', 'CytoscapeWindowClass', 
   function(obj, edge.names, new.values) {
      # TO-DO: get a list of supported line styles and check if the arguments are valid line styles 
      setEdgePropertyDirect(obj, edge.names, new.values, "EDGE_LINE_TYPE")
})
## END setEdgeLineStyleDirect

# ------------------------------------------------------------------------------
setMethod('setEdgeSourceArrowShapeDirect', 'CytoscapeWindowClass', 
   function(obj, edge.names, new.values) {
      setEdgePropertyDirect(obj, edge.names, new.values, "EDGE_SOURCE_ARROW_SHAPE")
})
## END setEdgeSourceArrowShapeDirect

# ------------------------------------------------------------------------------
setMethod('setEdgeTargetArrowShapeDirect', 'CytoscapeWindowClass', 
   function(obj, edge.names, new.values) {
      setEdgePropertyDirect(obj, edge.names, new.values, "EDGE_TARGET_ARROW_SHAPE")
})
## END setEdgeTargetArrowShapeDirect

# ------------------------------------------------------------------------------
setMethod('setEdgeSourceArrowColorDirect', 'CytoscapeWindowClass', 
   function(obj, edge.names, new.colors) {
      for(current.color in new.colors) {
         # ensure the colour is formatted in correct hexadecimal style
         if((substring(current.color, 1, 1) != "#") || (nchar(current.color) != 7)) {
            write(sprintf('illegal color string "%s" in RCy3::setEdgeSourceArrowColorDirect. It needs to be in hexadecimal format.', current.color), stderr())
            return()
         }
      }
      setEdgePropertyDirect(obj, edge.names, new.colors, "EDGE_SOURCE_ARROW_UNSELECTED_PAINT")
})
## END setEdgeSourceArrowColorDirect

# ------------------------------------------------------------------------------
setMethod('setEdgeTargetArrowColorDirect', 'CytoscapeWindowClass', 
   function(obj, edge.names, new.colors) {
      for(current.color in new.colors) {
         # ensure the color is formatted in correct hexadecimal style
         if((substring(current.color, 1, 1) != "#") || (nchar(current.color) != 7)) {
            write(sprintf('illegal color string "%s" in RCy3::setEdgeTargetArrowColorDirect. It needs to be in hexadecimal format.', current.color), stderr())
            return()
         }
      }
      setEdgePropertyDirect(obj, edge.names, new.colors, "EDGE_TARGET_ARROW_UNSELECTED_PAINT")
})
## END setEdgeTargetArrowColorDirect

# ------------------------------------------------------------------------------
setMethod('setEdgeLabelOpacityDirect', 'CytoscapeWindowClass', 
   function(obj, edge.names, new.value) {
      for(current.value in new.value) {
         # ensure the opacity value is a double and between 0 and 255
         if(!is.double(current.value) || current.value < 0 || current.value > 255) {
            write(sprintf('illegal opacity string "%s" in RCy3::setEdgeLabelOpacityDirect. It needs to be between 0 and 255.', current.value), stderr())
            return()
         }
      }
      setEdgePropertyDirect(obj, edge.names, new.value, "EDGE_LABEL_TRANSPARENCY")
})
## END setEdgeLabelOpacityDirect

#------------------------------------------------------------------------------------------------------------------------
#setMethod ('setEdgeLabelPositionDirect', 'CytoscapeWindowClass',
#   function (obj, edge.names, new.value) {
#     id = as.character (obj@window.id)
#     for (edge.name in edge.names)
#       result = xml.rpc (obj@uri, "Cytoscape.setEdgeProperty", edge.name, 'Edge Label Position', as.character (new.value))
#     invisible (result)
#     })

# ------------------------------------------------------------------------------
setMethod('setEdgeLabelWidthDirect', 'CytoscapeWindowClass', 
   function(obj, edge.names, new.value) {
      ### for implementation...
})
## END setEdgeLabelWidthDirect

# ------------------------------------------------------------------------------
setMethod('getNodeCount', 'CytoscapeWindowClass', 
  function(obj) {
    net.SUID = as.character(obj@window.id)
    version = pluginVersion(obj)
    
    resource.uri = paste(obj@uri, version, "networks", net.SUID, "nodes/count", sep="/")
    request.res = GET(resource.uri)
    node.count = unname(fromJSON(rawToChar(request.res$content)))
    return(node.count)
})
## END getNodeCount

# ------------------------------------------------------------------------------
setMethod('getEdgeCount', 'CytoscapeWindowClass', 
  function(obj) {
    net.SUID = as.character(obj@window.id)
    version = pluginVersion(obj)
    
    resource.uri = paste(obj@uri, version, "networks", net.SUID, "edges/count", sep="/")
    # request result
    request.res = GET(resource.uri)
    edge.count <- unname(fromJSON(rawToChar(request.res$content)))
    return(edge.count)
})
## END getEdgeCount

# ------------------------------------------------------------------------------
setMethod('getNodeAttribute', 'CytoscapeConnectionClass', 
    function(obj, node.name, attribute.name) {
        # network ID and cyREST API version
        net.SUID = as.character(obj@window.id)
        version = pluginVersion(obj)
        
        # map node names to node SUIDs
        node.SUID = .nodeNameToNodeSUID(obj, node.name)
        
        # check if the attribute exists
        if(attribute.name %in% getNodeAttributeNames(obj)) {
            if(length(node.SUID) == 1) {
                resource.uri = 
                    paste(obj@uri, version, "networks", net.SUID, "tables/defaultnode/rows", as.character(node.SUID), attribute.name, sep="/")
                request.res = GET(url=resource.uri)
                
                node.attribute.value = unname(rawToChar(request.res$content))
                
                node.attribute.type = getNodeAttributeType(obj, attribute.name)
                
                if(node.attribute.type == 'Boolean') {
                    return(as.logical(node.attribute.value))
                } else if(node.attribute.type == 'Long') {
                    return(as.numeric(node.attribute.value))
                } else if(node.attribute.type == 'String') {
                    return(as.character(node.attribute.value))
                } else if(node.attribute.type == 'Integer') {
                    return(as.integer(node.attribute.value))
                } else if(node.attribute.type == 'Double') {
                    return(as.numeric(node.attribute.value))
                } else {
                    return(node.attribute.value)
                }
            } else {
                write(sprintf("RCy3::getNodeAttribute() error: node '%s' does not exist in Cytoscape", node.name), stderr())
            }
        } else {
            write(sprintf("RCy3::getNodeAttribute() error: '%s' is not a recognized node attribute name", attribute.name), stderr())
        }
})
## END getNodeAttribute

setMethod('getNodeAttributeType', 'CytoscapeWindowClass', 
    function(obj, attribute.name) {
        net.SUID = as.character(obj@window.id)
        version = pluginVersion(obj)
        
        if(attribute.name %in% getNodeAttributeNames(obj)) {
            resource.uri = 
                paste(obj@uri, version, "networks", net.SUID, "tables/defaultnode/columns", sep="/")
            request.res = GET(url=resource.uri)
            
            node.attributes.info = fromJSON(rawToChar(request.res$content))
            
            return(node.attributes.info[[which(lapply(node.attributes.info, function(a) {a$name}) %in% attribute.name)]]$type)
        } else {
            write(sprintf("RCy3::getNodeAttributeType error: '%s' is not a recognized node attribute name", attribute.name), stderr())
        }
})
## END getNodeAttributeType

# ------------------------------------------------------------------------------
setMethod('getAllNodeAttributes', 'CytoscapeWindowClass', 
   function(obj, onlySelectedNodes = FALSE) {
      g = obj@graph
      attribute.names = names(nodeDataDefaults(g))
      nodes.of.interest = nodes(g)
      if(onlySelectedNodes) {
         if(getSelectedNodeCount(obj) == 0) {
            return(NA)
         }
         nodes.of.interest = getSelectedNodes(obj)
      }
      result = cbind(unlist(nodeData(g, nodes.of.interest, attr=attribute.names[1])))
      if(length(attribute.names) > 1) {
         for(name in attribute.names[2:length(attribute.names)]) {
            new.column = unlist(nodeData(g, nodes.of.interest, attr=name))
            if(is.null(new.column)) {
               new.column = rep('NULL', nrow(result))
            }
            result = cbind(result, new.column)
         } # for name
      } # if length > 1
      
      colnames(result) = attribute.names
      result = as.data.frame(result, stringsAsFactors=FALSE)
      
      for(name in attribute.names) {
         attribute.class = attr(nodeDataDefaults(obj@graph, name), 'class')
         if(attribute.class == 'FLOATING') {
            result[, name] = as.numeric(result[, name])
         } else if(attribute.class == 'STRING') {
            result[, name] = as.character(result[, name])
         } else if(attribute.class == 'INTEGER') {
            result[, name] = as.integer(result[, name])
         }
      } # for name
      
      return(result)
})
## END getAllNodeAttributes

# ------------------------------------------------------------------------------
setMethod('getEdgeAttribute', 'CytoscapeConnectionClass', 
   function(obj, edge.name, attribute.name) {
      # network ID and cyREST API version
      net.SUID = as.character(obj@window.id)
      version = pluginVersion(obj)
      
      # map node names to node SUIDs
      edge.SUID = .edgeNameToEdgeSUID(obj, edge.name)
      
      if(attribute.name %in% getEdgeAttributeNames(obj)) {
          if(length(edge.SUID) == 1) {
              resource.uri = 
                  paste(obj@uri, version, "networks", net.SUID, "tables/defaultedge/rows", as.character(edge.SUID), attribute.name, sep="/")
              request.res = GET(url=resource.uri)
              
              edge.attribute.value = unname(rawToChar(request.res$content))
              
              edge.attribute.type = getEdgeAttributeType(obj, attribute.name)
              
              if(edge.attribute.type == 'Boolean') {
                  return(as.logical(edge.attribute.value))
              } else if(edge.attribute.type == 'Long') {
                  return(as.numeric(edge.attribute.value))
              } else if(edge.attribute.type == 'String') {
                  return(as.character(edge.attribute.value))
              } else if(edge.attribute.type == 'Integer') {
                  return(as.integer(edge.attribute.value))
              } else if(edge.attribute.type == 'Double') {
                  return(as.numeric(edge.attribute.value))
              } else {
                  return(edge.attribute.value)
              }
          } else {
              write(sprintf("RCy3::getEdgeAttribute() error: edge '%s' does not exist in Cytoscape", node.name), stderr())
          }
      } else {
          write(sprintf("RCy3::getEdgeAttribute() error: '%s' is not a recognized edge attribute name", attribute.name), stderr())
      } 
      
      # edge.SUID = .edgeNameToEdgeSUID(obj, edge.name)
      # get the node attribute in the nodes table
      # resource.uri = paste(obj@uri, version, "networks", net.SUID, "tables/defaultedge/rows", as.character(edge.SUID), attribute.name, sep="/")
      # request.res = GET(url=resource.uri)
      # edge.attribute.value = unname(rawToChar(request.res$content))
      # return(edge.attribute.value)
})
## END getEdgeAttribute

setMethod('getEdgeAttributeType', 'CytoscapeWindowClass',
    function(obj, attribute.name) {
        net.SUID = as.character(obj@window.id)
        version = pluginVersion(obj)
        
        if(attribute.name %in% getEdgeAttributeNames(obj)) {
            resource.uri = 
                paste(obj@uri, version, "networks", net.SUID, "tables/defaultedge/columns", sep="/")
            request.res = GET(url=resource.uri)
            
            edge.attributes.info = fromJSON(rawToChar(request.res$content))
            
            return(edge.attributes.info[[which(lapply(edge.attributes.info, function(a) {a$name}) %in% attribute.name)]]$type)
        } else {
            write(sprintf("RCy3::getEdgeAttributeType: '%s' is not a recognized edge attribute name", attribute.name), stderr())
        }
})
## END getEdgeAttributeType

# ------------------------------------------------------------------------------
setMethod('getAllEdgeAttributes', 'CytoscapeWindowClass', 
   function(obj, onlySelectedEdges=FALSE) {
      
      g = obj@graph
      attribute.names = names(edgeDataDefaults(g))
      edges.of.interest = edgeNames(g)
      if(onlySelectedEdges) {
         if(getSelectedEdgeCount(obj) == 0)
            return (NA)
         edges.of.interest = getSelectedEdges(obj)
      } # if onlySelectedEdges
      
      source.and.target.nodes = unlist(strsplit(edges.of.interest, '~'))
      node.count = length(source.and.target.nodes)
      source = source.and.target.nodes[seq(1, node.count, 2)]
      target = source.and.target.nodes[seq (2, node.count, 2)]
      
      # printf ('source nodes: %s', list.to.string (source))
      # printf ('target nodes: %s', list.to.string (target))
      # printf ('attribute names: %s', list.to.string (attribute.names))
      
      result = cbind(unlist(edgeData(g, source, target, attr=attribute.names[1])))
      result = cbind(result, source)
      result = cbind(result, target)
      
      if(length(attribute.names) > 1) {
         for(name in attribute.names[2:length(attribute.names)]) {
            new.column = unlist(edgeData(g, source, target, attr=name))
            result = cbind(result, new.column)
         } # for name
      } # if > 1
      
      column.names = c(attribute.names[1], 'source', 'target')
      if(length(attribute.names) > 1)
         column.names = c(column.names, attribute.names[2:length(attribute.names)])
      
      colnames(result) = column.names
      result = as.data.frame(result, stringsAsFactors=FALSE)
      
      # we had a matrix of character strings, now a data.frame of character strings
      # use the embedded type information (created by initEdgeAttribute) to correct to the proper types
      # must be a more direct way to do this in the calls to cbind on a data.frame.
      
      for(name in attribute.names) {
         attribute.class = attr(edgeDataDefaults(obj@graph, name), 'class')
         if(attribute.class == 'FLOATING')
            result[, name] = as.numeric(result[, name])
         else if(attribute.class == 'STRING')
            result[, name] = as.character(result[, name])
         else if(attribute.class == 'INTEGER')
            result[, name] = as.integer(result[, name])
      } # for name
      
      return (result)
})
## END getAllEdgeAttributes

# ------------------------------------------------------------------------------
setMethod('getNodeAttributeNames', 'CytoscapeConnectionClass', 
  function(obj) {
    net.SUID = as.character(obj@window.id)
    resource.uri = paste(obj@uri, pluginVersion(obj), "networks", net.SUID, "tables/defaultnode/columns", sep="/")
    # request result
    request.res = GET(url = resource.uri)
    request.res = fromJSON(rawToChar(request.res$content))
    request.res = data.frame(t(sapply(request.res, c)))
    request.res = unlist(request.res$name)
    # exclude the 'default' nodes
    node.attributes = request.res[! request.res %in% c("SUID", "shared name", "name", "selected")]
    invisible(request.res)
    return(node.attributes)
})

# ------------------------------------------------------------------------------
setMethod('getEdgeAttributeNames', 'CytoscapeConnectionClass', 
  function(obj) {
    net.SUID = as.character(obj@window.id)
    resource.uri = paste(obj@uri, pluginVersion(obj), "networks", net.SUID, "tables/defaultedge/columns", sep="/")
    # request result
    request.res = GET(url=resource.uri)
    request.res = fromJSON(rawToChar(request.res$content))
    request.res = data.frame(t(sapply(request.res, c)))
    request.res = unlist(request.res$name)
    edge.attributes = request.res[! request.res %in% c("SUID", "shared name", "name", "selected")]
    invisible(request.res)
    return(edge.attributes)
})

# ------------------------------------------------------------------------------
# delete node attribute by deleting its column in the node table
setMethod('deleteNodeAttribute', 'CytoscapeConnectionClass', 
  function(obj, attribute.name) {
    net.SUID = as.character(obj@window.id)
    if(attribute.name %in% getNodeAttributeNames(obj)) {
      resource.uri = paste(obj@uri, pluginVersion(obj), "networks", net.SUID, "tables/defaultnode/columns", as.character(attribute.name), sep="/")
      request.res = DELETE(url= api.str)
      write(sprintf('Attribute "%s" has been deleted...', attr.name), stderr())
      invisible(request.res)
    } else {
      msg = paste(attribute.name, ' does not exist and thus could not be deleted.')
      write(msg, stderr())
    }
})

# ------------------------------------------------------------------------------
# delete edge attribute by deleting its column in the edge table
setMethod('deleteEdgeAttribute', 'CytoscapeConnectionClass', 
  function(obj, attribute.name) {
    net.SUID = as.character(obj@window.id)
    if(attribute.name %in% getEdgeAttributeNames(obj)) {
      resource.uri = paste(obj@uri, pluginVersion(obj), "networks", net.SUID, "tables/defaultedge/columns", as.character(attribute.name), sep="/")
      # request result
      request.res = DELETE(url= api.str)
      write(sprintf('Attribute "%s" has been deleted...', attr.name), stderr())
      invisible(request.res)
    } else {
      msg = paste(attribute.name, ' does not exist and thus could not be deleted.')
      write(msg, stderr())
    }
})

# ------------------------------------------------------------------------------
setMethod('getAllNodes', 'CytoscapeWindowClass', 
   function(obj) {
      loc.obj <- obj
      
      # network suid
      net.SUID = as.character(loc.obj@window.id)
      # CyREST version
      version = pluginVersion(loc.obj)
      
      resource.uri = paste(loc.obj@uri, version, "networks", net.SUID, "nodes/count", sep="/")
      count = rawToChar(GET(resource.uri)$content)
      if(count == 0) {
         return()
      }
      
      # get SUIDs of existing (in Cytoscape) nodes
      resource.uri = paste(loc.obj@uri, version, "networks", net.SUID, "nodes", sep="/")
      # get the SUIDs of the nodes in the Cytoscape graph
      cy.nodes.SUIDs = fromJSON(rawToChar(GET(resource.uri)$content))
      # translate the SUIDs to node names
      dict.suids.vec = sapply(loc.obj@suid.name.dict, "[[", 2)
      
      # if there is difference b/n the nodes in obj@graph and Cytoscape
      diff.nodes = setdiff(cy.nodes.SUIDs, dict.suids.vec)
      
      if(length(diff.nodes) > 0) {
         for(i in 1:length(diff.nodes)) {
            resource.uri = paste(loc.obj@uri, version, "networks", net.SUID, "nodes", as.character(diff.nodes[i]), sep="/")
            node.name = fromJSON(rawToChar(GET(resource.uri)$content))$data$name
            loc.obj@suid.name.dict[[length(loc.obj@suid.name.dict) + 1]] <- list(name=node.name, SUID=diff.nodes[i])
         }
         ### TO-DO in future: add new node to graph
      }
      indices <- which(dict.suids.vec %in% cy.nodes.SUIDs)
      
      node.names <- sapply(loc.obj@suid.name.dict, function(x) x[[1]])
      
      eval.parent(substitute(obj <- loc.obj))
      
      return(node.names)
})
## END getAllNodes

# ------------------------------------------------------------------------------
setMethod('getAllEdges', 'CytoscapeWindowClass', 
   function(obj) {
      net.SUID = as.character(obj@window.id)
      count = getEdgeCount(obj)
      if(count == 0) {
         return()
      }
      
      resource.uri = paste(obj@uri, pluginVersion(obj), "networks", net.SUID, "tables/defaultedge/columns/name", sep="/")
      request.res = GET(url=resource.uri)
      request.res = fromJSON(rawToChar(request.res$content))
      edge.names = request.res$values
      return(edge.names)
}) 
## END getAllEdges

# ------------------------------------------------------------------------------
setMethod('clearSelection', 'CytoscapeWindowClass', 
  function(obj) {
    net.SUID = as.character(obj@window.id)
    version = pluginVersion(obj)
    # if any nodes are selected, unselect them
    resource.uri <- paste(obj@uri, version, "networks", net.SUID, "tables/defaultnode/columns/selected?default=false", sep="/")
    request.res <- PUT(url=resource.uri, body=FALSE)
    
    redraw(obj)
    invisible(request.res)
})
   
# ------------------------------------------------------------------------------
setMethod('selectNodes', 'CytoscapeWindowClass', 
   function(obj, node.names, preserve.current.selection = TRUE) {
      net.SUID = as.character(obj@window.id)
      version = pluginVersion(obj)
      
      if(preserve.current.selection) {
         if(getSelectedNodeCount(obj) > 0) {
            node.names = unique(c(getSelectedNodes(obj), node.names))
         }
      }
      
      if(!preserve.current.selection) {
         clearSelection(obj)
      }
      
      # check for unknown nodes
      unknown.nodes = setdiff(node.names, nodes(obj@graph))
      if(length(unknown.nodes) > 0) {
         node.string = paste(unknown.nodes, collapse='')
         msg = paste('RCy3::selectNodes asked to select nodes not in graph: ', node.string)
         write(msg, stderr())
         node.names = intersect(node.names, nodes(obj@graph))
      }
      
      if(length(node.names) == 0) {
         invisible('no nodes to select')
      }
      
      node.SUIDs = .nodeNameToNodeSUID(obj, node.names)
      SUID.value.pairs = lapply(node.SUIDs, function(s) {list('SUID' = s, 'value' = TRUE)})
      SUID.value.pairs.JSON = toJSON(SUID.value.pairs)
      
      resource.uri = paste(obj@uri, version, "networks", net.SUID, "tables/defaultnode/columns/selected", sep="/")
      request.res = PUT(url=resource.uri, body=SUID.value.pairs.JSON, encode="json")
      
      # redraw(obj)
      invisible(request.res)
})
   
# ------------------------------------------------------------------------------
setMethod('getSelectedNodeCount', 'CytoscapeWindowClass', 
  function(obj) {
    net.SUID = as.character(obj@window.id)
    version = pluginVersion(obj)
    resource.uri = paste(obj@uri, version, "networks", net.SUID, "nodes?column=selected&query=true", sep="/")
    request.res = GET(url=resource.uri)
    
    num.selected.nodes = length(fromJSON(rawToChar(request.res$content)))
    return(num.selected.nodes)
})
## END getSelectedNodeCount


# ------------------------------------------------------------------------------
setMethod('getSelectedNodes', 'CytoscapeWindowClass', 
  function(obj) {
    net.SUID = as.character(obj@window.id)
    version = pluginVersion(obj)
    
    if(getSelectedNodeCount(obj) == 0) {
      return(NA)
    } else {
      resource.uri = paste(obj@uri, version, "networks", net.SUID, "nodes?column=selected&query=true", sep="/")
      request.res = GET(url=resource.uri)
      
      selected.nodes.SUIDs = fromJSON(rawToChar(request.res$content))
      selected.nodes.names = c()
      
      # uses the nodes dictionary; (not decided yet if the dictionary will be used)
      dict.indices = which(sapply(obj@suid.name.dict, function(s) { s$SUID }) %in% selected.nodes.SUIDs)
      selected.nodes.names = sapply(obj@suid.name.dict[dict.indices], function(i) {i$name})
      return(selected.nodes.names)
    }
})
   
#------------------------------------------------------------------------------------------------------------------------
setMethod ('hideSelectedNodes', 'CytoscapeWindowClass',

   function (obj) {
#     id = as.character (obj@window.id)
#     invisible (xml.rpc (obj@uri, 'Cytoscape.hideSelectedNodes', id, .convert=TRUE))
     }) # hideSelectedNodes
   
#------------------------------------------------------------------------------------------------------------------------
setMethod ('hideNodes', 'CytoscapeWindowClass',

   function (obj, node.names) {
#     id = as.character (obj@window.id)
#     for (node in node.names)
#       invisible (xml.rpc (obj@uri, 'Cytoscape.hideNode', id, node, .convert=TRUE))
     }) # hideNodes
   
#------------------------------------------------------------------------------------------------------------------------
#setMethod ('unhideNodes', 'CytoscapeWindowClass',
#
#   function (obj, node.names) {
#     id = as.character (obj@window.id)
#     for (node in node.names)
#       invisible (xml.rpc (obj@uri, 'Cytoscape.unhideNode', id, node, .convert=TRUE))
#     }) # unhideNodes
#   

# ------------------------------------------------------------------------------
# select all nodes that were not selected and deselect all nodes that were selected
setMethod('invertNodeSelection', 'CytoscapeWindowClass', function(obj) {
  net.SUID = as.character(obj@window.id)
  version = pluginVersion(obj)
  
  resource.uri = paste(obj@uri, version, "networks", net.SUID, "nodes?column=selected&query=false", sep="/")
  request.res = GET(url=resource.uri)
  unselected.nodes.SUIDs = fromJSON(rawToChar(request.res$content))
  # clear the selection
  clearSelection(obj)
  
  to.be.selected.nodes = lapply(unselected.nodes.SUIDs, function(s) {list('SUID' = s, 'value' = TRUE)})
  to.be.selected.nodes.JSON = toJSON(to.be.selected.nodes)
  
  resource.uri = paste(obj@uri, version, "networks", net.SUID, "tables/defaultnode/columns/selected", sep="/")
  request.res = PUT(url=resource.uri, body=to.be.selected.nodes.JSON, encode="json")
  invisible(request.res)
  
  # another better option: call selectNodes() 
  # selectNodes(obj, c('A', 'C'), FALSE)
})
 
# ------------------------------------------------------------------------------
setMethod('deleteSelectedNodes', 'CytoscapeWindowClass', 
  function(obj) {
    loc.obj <- obj
    
    net.SUID = as.character(loc.obj@window.id)
    version = pluginVersion(loc.obj)
    
    selected.node.names = getSelectedNodes(loc.obj)
    selected.node.SUIDs = .nodeNameToNodeSUID(loc.obj, selected.node.names)
    
    for(i in 1:length(selected.node.SUIDs)) {
        node.SUID = selected.node.SUIDs[i]
        # edges that have this node as their source node
        source.bound.edges = list()
        # edges that have this node as their target node
        target.bound.edges = list()
        
        source.indices = which(sapply(loc.obj@edge.suid.name.dict, function(n) {n$source.node}) %in% node.SUID)
        
        if(length(source.indices) > 0) {
            source.bound.edges = sapply(loc.obj@edge.suid.name.dict[source.indices], function(e) { e$SUID })
            # loop through all edges, which have that node as their source node and delete those edges
            for(k in 1:length(source.bound.edges)) {
                resource.uri = paste(loc.obj@uri, version, "networks", net.SUID, "edges", as.character(source.bound.edges[k]), sep="/")
                request.res = DELETE(url=resource.uri)
                
                # [GIK] TO-DO: delete the edge row from the edge table
            }
            # delete these edges from the session dictionary as well
            loc.obj@edge.suid.name.dict[source.indices] <- NULL
        }
        
        target.indices = which(sapply(loc.obj@edge.suid.name.dict, function(n) {n$target.node}) %in% node.SUID)
        
        if(length(target.indices) > 0) {
            target.bound.edges = sapply(loc.obj@edge.suid.name.dict[target.indices], function(e) { e$SUID })
            # loop through all edges, which have that node as their target node and delete those edges
            for(k in 1:length(target.bound.edges)) {
                resource.uri = paste(loc.obj@uri, version, "networks", net.SUID, "edges", as.character(target.bound.edges[k]), sep="/")
                request.res = DELETE(url=resource.uri)
                
                # [GIK] TO-DO: delete the edge row from the edge table
            }
            # delete these edges from the session dictionary as well
            loc.obj@edge.suid.name.dict[target.indices] <- NULL
        }
        
        # delete node in Cytoscape
        resource.uri = paste(loc.obj@uri, version, "networks", net.SUID, "nodes", as.character(node.SUID), sep="/")
        request.res = DELETE(url=resource.uri)
        
        # [GIK] TO-DO: delete the node row/entry in the node table
        
        # delete node in session
        node.index = which(sapply(loc.obj@suid.name.dict, function(n) { n$SUID }) %in% node.SUID)
        loc.obj@suid.name.dict[node.index] <- NULL
    }
    
    # print(selected.node.SUIDs)
    eval.parent(substitute(obj <- loc.obj))
})
## END deleteSelectedNodes

# ------------------------------------------------------------------------------
setMethod('selectEdges', 'CytoscapeWindowClass', 
   function(obj, edge.names, preserve.current.selection=TRUE) {
      net.SUID = as.character(obj@window.id)
      version = pluginVersion(obj)
      if(preserve.current.selection) {
         edge.names = unique(c(getSelectedEdges(obj), edge.names))
      }
      
      edge.SUIDs = .edgeNameToEdgeSUID(obj, edge.names)
      SUID.value.pairs = lapply(edge.SUIDs, function(s) {list('SUID' = s, 'value' = TRUE)})
      SUID.value.pairs.JSON = toJSON(SUID.value.pairs)
      
      resource.uri = paste(obj@uri, version, "networks", net.SUID, "tables/defaultedge/columns/selected", sep="/")
      request.res = PUT(url=resource.uri, body=SUID.value.pairs.JSON, encode="json")
      
      # redraw(obj)
      invisible(request.res)
}) 
## END selectEdges
 
# ------------------------------------------------------------------------------
setMethod('invertEdgeSelection', 'CytoscapeWindowClass', 
  function (obj) {
    net.SUID = as.character(obj@window.id)
    version = pluginVersion(obj)
    
    resource.uri = paste(obj@uri, version, "networks", net.SUID, "edges?column=selected&query=false", sep="/")
    request.res = GET(url=resource.uri)
    unselected.edges.SUIDs = fromJSON(rawToChar(request.res$content))
    # if any edges are selected, unselect them (nodes have clearSelection function) 
    resource.uri <- paste(obj@uri, version, "networks", net.SUID, "tables/defaultedge/columns/selected?default=false", sep="/")
    request.res <- PUT(url=resource.uri, body=FALSE)
    
    to.be.selected.edges = lapply(unselected.edges.SUIDs, function(s) {list('SUID' = s, 'value' = TRUE)})
    to.be.selected.edges.JSON = toJSON(to.be.selected.edges)
    
    # better option: use selectEdges() function
    resource.uri = paste(obj@uri, version, "networks", net.SUID, "tables/defaultedge/columns/selected", sep="/")
    request.res = PUT(url=resource.uri, body=to.be.selected.edges.JSON, encode="json")
    invisible(request.res)
})
 
# ------------------------------------------------------------------------------
setMethod('deleteSelectedEdges', 'CytoscapeWindowClass', 
    function(obj) {
        loc.obj <- obj
        
        net.SUID = as.character(loc.obj@window.id)
        version = pluginVersion(loc.obj)
        
        selected.edge.names = getSelectedEdges(loc.obj)
        selected.edge.SUIDs = .edgeNameToEdgeSUID(loc.obj, selected.edge.names)
        
        for(i in 1:length(selected.edge.SUIDs)) {
            edge.SUID = selected.edge.SUIDs[i]
            resource.uri = paste(loc.obj@uri, version, "networks", net.SUID, "edges", edge.SUID, sep="/")
            # delete edge from canvas / view
            request.res = DELETE(url=resource.uri)
            
            # delete edge from edge table : NOT possible in the API
            
            # delete edge record from the session dictionary
            loc.obj@edge.suid.name.dict[which(sapply(loc.obj@edge.suid.name.dict, function(e) { e$SUID }) %in% edge.SUID)] <- NULL
        }
        
        eval.parent(substitute(obj <- loc.obj))
})
## END deleteSelectedEdges
   
# ------------------------------------------------------------------------------
setMethod('getSelectedEdgeCount', 'CytoscapeWindowClass', 
  function(obj) {
    net.SUID = as.character(obj@window.id)
    version = pluginVersion(obj)
    resource.uri = paste(obj@uri, version, "networks", net.SUID, "edges?column=selected&query=true", sep="/")
    request.res = GET(url=resource.uri)
    
    num.selected.edges = length(fromJSON(rawToChar(request.res$content)))
    return(num.selected.edges)
})
## END getSelectedEdgeCount
   
# ------------------------------------------------------------------------------
setMethod('getSelectedEdges', 'CytoscapeWindowClass', 
   function(obj) {
      net.SUID = as.character(obj@window.id)
      version = pluginVersion(obj)
      if(getSelectedEdgeCount(obj) == 0) {
         return (NA)
      } else {
         resource.uri = paste(obj@uri, version, "networks", net.SUID, "edges?column=selected&query=true", sep="/")
         request.res = GET(url=resource.uri)
         selected.edges.SUIDs = fromJSON(rawToChar(request.res$content))
         selected.edges = .edgeSUIDToEdgeName(obj, selected.edges.SUIDs)
         
         return(selected.edges)
      }
}) 
## END getSelectedEdges
   
#------------------------------------------------------------------------------------------------------------------------
setMethod ('hideSelectedEdges', 'CytoscapeWindowClass',

   function (obj) {
#     id = as.character (obj@window.id)
#     invisible (xml.rpc (obj@uri, 'Cytoscape.hideSelectedEdges', id, .convert=TRUE))
     }) # hideSelectedEdges
   
#------------------------------------------------------------------------------------------------------------------------
setMethod ('unhideAll', 'CytoscapeWindowClass',

   function (obj) {
#     id = as.character (obj@window.id)
#     result = xml.rpc (obj@uri, 'Cytoscape.unhideAll', id, .convert=TRUE)
#     redraw (obj)
#     invisible (result)
     }) # unhideAll

# ------------------------------------------------------------------------------
setMethod('getFirstNeighbors', 'CytoscapeWindowClass',
   function(obj, node.names) {
      if(length(node.names) == 0){
         return()
      } else {
         # map node names to node SUIDs
         node.SUIDs = .nodeNameToNodeSUID(obj, node.names)
         
         # network ID and cyREST API version
         net.suid = as.character(obj@window.id)
         version = pluginVersion(obj)
         
         # get first neighbors
         neighbor.names <- c()
         
         for(node.SUID in node.SUIDs){
            # get first neighbors for each node
            resource.uri = paste(obj@uri, version, "networks", net.suid, "nodes", as.character(node.SUID), "neighbors", sep="/")
            request.res = GET(url=resource.uri)
            first.neighbors.SUIDs = fromJSON(rawToChar(request.res$content))
            
            # map node SUIDs to node names
            neighbor.names = c(neighbor.names, .nodeSUIDToNodeName(obj, first.neighbors.SUIDs))
         }
         return(neighbor.names)
      }
   }
)
## END getFirstNeighbors

# ------------------------------------------------------------------------------
setMethod('RCy3.getFirstNeighbors', 'CytoscapeWindowClass', 
   function(obj, node.names) {
      # network ID and cyREST API version
      net.SUID = as.character(obj@window.id)
      version = pluginVersion(obj)
      
      if(length(node.names) == 0) {
         invisible()
      }
      # map node names to node SUIDs
      node.SUIDs = .nodeNameToNodeSUID(obj, node.names)
      # get first neighbors
      neighbor.names = c()
      i = 1
      for(node.SUID in node.SUIDs) {
         # get the first neighbours of each node
         resource.uri = paste(obj@uri, version, "networks", net.SUID, "nodes", as.character(node.SUID), "neighbors", sep="/")
         request.res = GET(url=resource.uri)
         first.neighbor.SUIDs = fromJSON(rawToChar(request.res$content))
         
         list.item = list()
         node.name = node.names[[i]]
         first.neighbor.names = .nodeSUIDToNodeName(obj, first.neighbor.SUIDs)
         list.item[[node.name]] = first.neighbor.names
         neighbor.names[[length(neighbor.names)+1]] = list.item
         i = i+1
      }
      
      return(neighbor.names)
})
## END RCy3.getFirstNeighbors

# ------------------------------------------------------------------------------
setMethod('selectFirstNeighborsOfSelectedNodes', 'CytoscapeWindowClass', 
   function(obj) {
      if(getSelectedNodeCount(obj) > 0) {
         currently.selected = getSelectedNodes(obj)
         if(length(currently.selected) == 0) {
            invisible()
         }
         neighbors = getFirstNeighbors(obj, currently.selected)
         full.selection = unique(c(currently.selected, neighbors))
         selectNodes(obj, full.selection)
         invisible(full.selection)
      }
}) 
## END selectFirstNeighborsOfSelectedNodes

# ------------------------------------------------------------------------------
setMethod('sfn', 'CytoscapeWindowClass', function (obj) {
  selectFirstNeighborsOfSelectedNodes (obj)
})
## END sfn

# ------------------------------------------------------------------------------
noa.names = function(graph)
{
  return(names(nodeDataDefaults(graph)))
}

# ------------------------------------------------------------------------------
eda.names = function(graph)
{
  return(names(edgeDataDefaults(graph)))
}

# ------------------------------------------------------------------------------
# return the value of every node in the graph for the specified attribute 
noa = function(graph, node.attribute.name)
{
  if(!node.attribute.name %in% noa.names(graph))
    return(NA)
  return(unlist(nodeData(graph, attr=node.attribute.name)))
}

# ------------------------------------------------------------------------------
# return the value of every edge in the graph for the specified attribute
eda = function(graph, edge.attribute.name)
{
  if(!edge.attribute.name %in% eda.names(graph))
    return (NA)
  return(unlist(edgeData(graph, attr=edge.attribute.name)))
}

# ------------------------------------------------------------------------------
# use the expected 'edgeType' attribute to create cytoscape-style 'A (edgeType) B' 
# edge names from a graphNEL
# edgeNames (g) # "A~B" "B~C" "C~A"
# if there is no edge attribute named 'edgeType', then create edges(uninterestingly) named 'A (edge) B'
cy2.edge.names = function(graph, R.edge.names=NA)
{
   if(length(edges(graph)) == 0) {
      return(NA)
   }
   
   edgeType.attribute.present = TRUE
   edge.type = 'unspecified'
   if('edgeType' %in% names(edgeDataDefaults(graph))) {
      # vector containing the 'edgeType'-attribute value for every edge
      edge.type = as.character(eda(graph, 'edgeType'))
   }
   
   # print(.rcyEdgeNames(graph))
   tokens = strsplit(.rcyEdgeNames(graph), '~')
   a = sapply(tokens, function(tok) tok[1])
   b = sapply(tokens, function(tok) tok[2])
   edge.type = paste (' (', edge.type, ') ', sep='')
   edge.names = paste (a, edge.type, b, sep='')
   
   names(edge.names) = .rcyEdgeNames(graph)
   
   if(!(length(R.edge.names) == 1 && is.na(R.edge.names))) {  # we were given some subset of all edges to extract and get cy2 names for. do that here
      new.edgeNames.tilde = gsub('\\|', '~', R.edge.names)
      if(length(intersect(names(edge.names), new.edgeNames.tilde)) > 0)
         edge.names = edge.names[new.edgeNames.tilde]
   }
   return(edge.names)
}

#------------------------------------------------------------------------------------------------------------------------
getAdjacentEdgeNames = function (graph, node.names) 
{
#  all.edge.names = cy2.edge.names (graph) 
#  all.edge.names.cyStyle = as.character (all.edge.names) 
#  indices.of.edges.with.nodes = c () 
#
#  for (node in node.names) { 
#    node.regex.nodeA = sprintf ('^%s ', node)
#    node.regex.nodeB = sprintf (' %s$', node)
#    indices.A = grep (node.regex.nodeA, all.edge.names.cyStyle) 
#    indices.B = grep (node.regex.nodeB, all.edge.names.cyStyle) 
#    indices.of.edges.with.nodes = c (indices.of.edges.with.nodes, indices.A, indices.B) 
#    } # for node
#
#  return (unique (as.character (all.edge.names) [indices.of.edges.with.nodes]))

} # getAdjacentEdgeNames

# ------------------------------------------------------------------------------
makeSimpleGraph = function()
{
    g = new('graphNEL', edgemode='directed')
    
    g = initNodeAttribute(g, 'type', 'char', 'undefined')
    g = initNodeAttribute(g, 'lfc', 'numeric', 1.0)
    g = initNodeAttribute(g, 'label', 'char', 'default node label')
    g = initNodeAttribute(g, 'count', 'integer', 0)
    
    g = initEdgeAttribute(g, 'edgeType', 'char', 'undefined')
    g = initEdgeAttribute(g, 'score', 'numeric', 0.0)
    g = initEdgeAttribute(g, 'misc',   'char', 'default misc')
    
    g = graph::addNode('A', g)
    g = graph::addNode('B', g)
    g = graph::addNode('C', g)
    nodeData(g, 'A', 'type') = 'kinase'
    nodeData(g, 'B', 'type') = 'transcription factor'
    nodeData(g, 'C', 'type') = 'glycoprotein'
    
    nodeData(g, 'A', 'lfc') = -3.0
    nodeData(g, 'B', 'lfc') = 0.0
    nodeData(g, 'C', 'lfc') = 3.
    
    nodeData(g, 'A', 'count') = 2
    nodeData(g, 'B', 'count') = 30
    nodeData(g, 'C', 'count') = 100
    
    nodeData(g, 'A', 'label') = 'Gene A'
    nodeData(g, 'B', 'label') = 'Gene B'
    nodeData(g, 'C', 'label') = 'Gene C'
    
    g = graph::addEdge('A', 'B', g)
    g = graph::addEdge('B', 'C', g)
    g = graph::addEdge('C', 'A', g)
    
    edgeData(g, 'A', 'B', 'edgeType') = 'phosphorylates'
    edgeData(g, 'B', 'C', 'edgeType') = 'synthetic lethal'
    
    edgeData(g, 'A', 'B', 'score') =  35.0
    edgeData(g, 'B', 'C', 'score') =  -12
    
    return(g)
}
## END makeSimpleGraph

# ------------------------------------------------------------------------------
# create, display and render the 3-node, 3-edge simple graph
demoSimpleGraph = function ()
{
    window.title = 'demo.simpleGraph'
    cy = CytoscapeConnection ()
    if (window.title %in% as.character (getWindowList (cy)))
        deleteWindow (cy, window.title)
    
    g.simple = RCytoscape::makeSimpleGraph ()
    cws = new.CytoscapeWindow (window.title, g.simple)
    
    displayGraph (cws)
    layoutNetwork (cws, 'default')
    setNodeLabelRule (cws, 'label')
    
    node.attribute.values = c ("kinase",  "transcription factor")
    colors =                c ('#A0AA00', '#FF0000')
    setDefaultNodeBorderWidth (cws, 5)
    setNodeBorderColorRule (cws, 'type', node.attribute.values, colors, mode='lookup', default.color='#88FF22')
    count.control.points = c (2, 30, 100)
    sizes                = c (20, 50, 100)
    setNodeSizeRule (cws, 'count', count.control.points, sizes, mode='interpolate')
    setNodeColorRule (cws, 'lfc', c (-3.0, 0.0, 3.0), c ('#00FF00', '#FFFFFF', '#FF0000'), mode='interpolate')
    #redraw (cws)
    invisible (cws)
} 
## END demoSimpleGraph

# ------------------------------------------------------------------------------
makeRandomGraph = function(node.count=12, seed=123)
{
  set.seed(seed); 
  #if(node.count > 26) node.count = 26
  node.names = as.character(1:node.count)
  g = randomGraph(node.names, M <- 1:2, p = 0.6)
  attr(edgeDataDefaults(g, attr="weight"), "class") = "DOUBLE"
  edgeDataDefaults(g, 'pmid') = '9988778899'
  attr(edgeDataDefaults(g, attr="pmid"), "class") = "STRING"
  return(g)
} 
## END makeRandomGraph

#------------------------------------------------------------------------------------------------------------------------
# see Robert Flight's replacement below (pshannon, 20 jul 2012)
# the bioconductor graph class stores undirected graph edge attributes redundantly.  bioc's nishant says (email, 2 sep 2010):
#
# The people who started the graph package decided to return duplicate edge attributes / weights for the undirected
# case. ie if you have an edge a-b and the graph is undirected, methods such as edgeWeights, edgeData etc will end up
# returning duplicate values for the attribute for a-b and b-a.  That was a design decision taken by the creators of the
# package and I do not think it will be possible to change that now.  I guess the solution might be to create your own
# edgeWeights and edgeData methods in your package that retrieve only the non-duplicated attributes for the undirected
# case.
#
remove.redundancies.in.undirected.graph.old = function (gu)
{
  if (length (nodes (gu)) == 0)
    return (new ('graphNEL', edgemode='directed'))

  g = new ('graphNEL', edgemode='directed')

  if (length (edgeDataDefaults (gu)) > 0)
    edgeDataDefaults (g) = edgeDataDefaults (gu)

  if (length (nodeDataDefaults (gu)) > 0)
    nodeDataDefaults (g) = nodeDataDefaults (gu)

  g = addNode (nodes (gu), g)
  for (node in nodes (g)) {
    for (noa.name in noa.names (gu)) {
      nodeData (g, node, noa.name) = nodeData (gu, node, noa.name)
      } # for noa.name
    } # for node

  if (length (edges (gu)) == 0)
    return (g)

  edge.names = edgeNames (gu)
  edge.node.pairs = strsplit (edge.names, '\\~')
  eda.names = eda.names (gu)

  for (node.pair in edge.node.pairs) {
    source.node = node.pair [1]
    target.node = node.pair [2]
    #printf ('create edge from %s to %s', source.node, target.node)
    g = addEdge (source.node, target.node, g)
    for (eda.name in eda.names (gu)) {
      edgeData (g, source.node, target.node, eda.name) = edgeData (gu, source.node, target.node, eda.name)
      } # for eda.name
    } # for node.pair

  return (g)

} # remove.redundancies.in.undirected.graph.old
#------------------------------------------------------------------------------------------------------------------------
# Robert Flight offered this replacement, having encountered painfully slow execution with a 5k edge undirected graph
# this fast version, likes its slow predecessor, compensates for the (in my view) flawed implementation of undirected
# graphNELs by converting them to directed graphs.
# but because undirected graphs are logically sound, and representationally useful, this is only a temporary fix.
# a redesign of this aspect of the graphNEL class is needed.
#
# original comments:
# the bioconductor graph class stores undirected graph edge attributes redundantly.  bioc's nishant says (email, 2 sep 2010):
#
# The people who started the graph package decided to return duplicate edge attributes / weights for the undirected
# case. ie if you have an edge a-b and the graph is undirected, methods such as edgeWeights, edgeData etc will end up
# returning duplicate values for the attribute for a-b and b-a.  That was a design decision taken by the creators of the
# package and I do not think it will be possible to change that now.  I guess the solution might be to create your own
# edgeWeights and edgeData methods in your package that retrieve only the non-duplicated attributes for the undirected
# case.
#
remove.redundancies.in.undirected.graph = function(gu) 
{
  if (length(nodes(gu)) == 0) 
      return(new("graphNEL", edgemode = "directed"))

  g <- new("graphNEL", edgemode = "directed")

  if (length(edgeDataDefaults(gu)) > 0) 
      edgeDataDefaults(g) <- edgeDataDefaults(gu)

  if (length(nodeDataDefaults(gu)) > 0) 
      nodeDataDefaults(g) <- nodeDataDefaults(gu)

  g <- addNode(nodes(gu), g)

  allNodes <- nodes(gu)

  noa.name <- invisible(lapply(noa.names(gu), function(noa.name) {
      nodeData(g, allNodes, noa.name) <- nodeData(gu, allNodes, noa.name)
  }))

  if (length(edgeNames(gu)) == 0) 
      return(g)

  edge.names <- edgeNames(gu)
  edge.node.pairs <- strsplit(edge.names, "\\~")
  source.nodes <- sapply(edge.node.pairs, function(x) x[1])
  target.nodes <- sapply(edge.node.pairs, function(x) x[2])

  g = graph::addEdge(source.nodes, target.nodes, g)

  invisible(lapply(eda.names(gu), function(eda.name) {
      edgeData(g, source.nodes, target.nodes, eda.name) <- edgeData(gu, source.nodes, 
          target.nodes, eda.name)
  }))

  return(g)
}
## END remove.redundancies.in.undirected.graph

# ------------------------------------------------------------------------------
initNodeAttribute = function(graph, attribute.name, attribute.type, default.value)
{
    stopifnot(attribute.type %in% c('char', 'integer', 'numeric', 'boolean'))
    if(attribute.type == 'char')
        attribute.type = 'String'
    else if(attribute.type == 'integer')
        attribute.type = 'Integer'
    else if(attribute.type == 'numeric')
        attribute.type = 'Double'
    else if(attribute.type == 'boolean')
        attribute.type = 'Boolean'
    
    nodeDataDefaults(graph, attr=attribute.name) = default.value
    attr(nodeDataDefaults(graph, attr=attribute.name), 'class') = attribute.type
    
    return(graph)
}
## END initNodeAttribute

# ------------------------------------------------------------------------------
initEdgeAttribute = function(graph, attribute.name, attribute.type, default.value)
{
    stopifnot(attribute.type %in% c('char', 'integer', 'numeric', 'boolean'))
    if(attribute.type == 'char')
        attribute.type = 'String'
    else if(attribute.type == 'integer')
        attribute.type = 'Integer'
    else if(attribute.type == 'numeric')
        attribute.type = 'Double'
    else if(attribute.type == 'boolean')
        attribute.type = 'Boolean'
    
    edgeDataDefaults(graph, attr=attribute.name) = default.value
    attr(edgeDataDefaults(graph, attr=attribute.name), 'class') = attribute.type
    
    return(graph)
} 
## END initEdgeAttribute

# ------------------------------------------------------------------------------
# [GIK - 1 Apr,2015] this function is not used in RCy3 : could be deleted
.cleanup = function (libpath)
{
   cw.closer = CytoscapeWindow('closer', create.window=FALSE)
   deleteAllWindows(cw.closer)
}
## END .cleanup

#------------------------------------------------------------------------------------------------------------------------
# used when adding a new graph to an existing graph.  we assume (but do not yet here test) that before this method
# is called, the Cytoscape graph has already been updated with new ones from 'other.graph'
# there may be some overlap between the two graphs; care is taken to only send attributes for new nodes.
# pre-existing attributes in the old graph are therefore not affected.
# the strategy: identify the new nodes, use the standard method 'setNodeAttributesDirect' to send them to cytoscape
# 
.sendNodeAttributesForGraph = function(obj, other.graph, attribute.name, new.node.indices)
{
    caller.specified.attribute.class = attr(nodeDataDefaults(other.graph, attribute.name), 'class')
    if(is.null(caller.specified.attribute.class)) {
        msg1 = sprintf('Error! RCytoscape:::.sendNodeAttributesForGraph. You must initialize the "%s" node attribute.', attribute.name)
        msg2 = sprintf('        example: my.graph = initNodeAttribute(my.graph, attr="moleculeType", "char", "unspecified")')
        write(msg1, stderr())
        write(msg2, stderr())
        return(NA)
    }
    # only add attributes for new nodes, unique to the new graph 'other.graph'
    # new.node.names = setdiff(nodes(other.graph), nodes(obj@graph))
    new.node.names = nodes(other.graph)[new.node.indices]
    values = noa(other.graph, attribute.name)[new.node.names]
    invisible(setNodeAttributesDirect(obj, attribute.name, caller.specified.attribute.class, new.node.names, values))
}
## END .sendNodeAttributesForGraph 

#------------------------------------------------------------------------------------------------------------------------
# used when adding a new graph to an existing graph.  we assume (but do not yet here test) that before this method
# is called, the Cytoscape graph has already been extended with all the new nodes and edges from 'other.graph'
# there may be some overlap between the two graphs; care is taken to only send attributes for new edges
# pre-existing attributes in the old graph are therefore not affected.
# the strategy:  identify the new edges, use the standard method 'setEdgeAttributesDirect' to send them to cytoscape
# oddities: edge naming is a tricky business.  cytoscape lablels edges like this:
#    <sourceNode> (interactionType) <targetNode>
# RCytoscape provide a utility function for retrieving them from an R graph object,   cy2.edge.names (g)
# which uses the edgeNames (g) method to get the R names
# edgeNames (g2)  # [1] "A~E" "A~B" "D~E"
# thus, R has a little inconsistency:  sometimes using the tilda, sometimes the vertical bar
#                 A~E                 A~B                 D~E 
#     "A (inferred) E" "A (unspecified) B"  "D (literature) E" 
# names (edgeData (g2, attr='edgeType'))
#    [1] "A|E" "A|B" "D|E"
# for historical reasons, and maybe laziness, these two conventions are supported here, at the cost of calling gsub on the edge
# names, so that A~E becomes A|E, setting the stage for calling 
#   values = eda (g, attribute.name) [new.edge.names.with.bar.delimitor]
# below, and thereby ensuring that only the attributes of new edges are sent to Cytoscape

.sendEdgeAttributesForGraph = function (obj, other.graph, attribute.name, new.edge.indices)
{
    caller.specified.attribute.class = attr(edgeDataDefaults(other.graph, attribute.name), 'class')
    
    if(is.null(caller.specified.attribute.class)) {
        msg1 = sprintf('Error!  RCytoscape:::.sendEdgeAttributesForGraph. You must initialize the "%s" edge attribute.', attribute.name)
        msg2 = sprintf('        example:  my.graph = initEdgeAttribute (my.graph, attr="edgeType", "char", "unspecified")')
        write(msg1, stderr())
        write(msg2, stderr())
        return(NA)
    }
    
    # send only attributes for edges which are unique to other.graph; 
    # we assume that any existing edges already have their attributes
    new.edge.names = unname(cy2.edge.names(other.graph)[new.edge.indices])
    
    if(length(new.edge.names) == 0) {
        return()
    }
    
    values = eda(other.graph, attribute.name)[new.edge.indices]
    invisible(setEdgeAttributesDirect(obj, attribute.name, caller.specified.attribute.class, new.edge.names, values))
} 
## END .sendEdgeAttributesForGraph 

# ------------------------------------------------------------------------------
setMethod('getVisualStyleNames', 'CytoscapeConnectionClass', 
  function(obj) {
    resource.uri = paste(obj@uri, pluginVersion(obj), "apply/styles", sep="/")
    request.res = GET(url=resource.uri)
    visual.style.names = unname(fromJSON(rawToChar(request.res$content)))
    return(visual.style.names)
})
## END getVisualStyleNames

# ------------------------------------------------------------------------------
setMethod('copyVisualStyle', 'CytoscapeConnectionClass', 
   function(obj, from.style, to.style) {
      current.names = getVisualStyleNames(obj)
      if(!from.style %in% current.names){
         stop(sprintf('Cannot copy from a non-existent visual style (%s)', from.style))
      }
      # get the current style from Cytoscape
      resource.uri <- paste(obj@uri, pluginVersion(obj), "styles", from.style, sep="/")
      from.style.JSON <- GET(url=resource.uri)
      from.style <- fromJSON(rawToChar(from.style.JSON$content))
      from.style[1] <- as.character(to.style)
      
      # and send it to Cytoscape as a new style with a new name
      to.style.JSON <- toJSON(from.style)
      resource.uri <- paste(obj@uri, pluginVersion(obj), "styles", sep="/")
      request.res <- POST(url=resource.uri, body=to.style.JSON, encode="json")
      invisible(request.res)
})
## END copyVisualStyle

# ------------------------------------------------------------------------------
# apply visual style to network
setMethod('setVisualStyle', 'CytoscapeConnectionClass', 
  function(obj, new.style.name) {
    net.SUID = as.character(obj@window.id)
    current.names = getVisualStyleNames(obj)
    # warn the user if they are trying to set visual style that is not available
    if(!new.style.name %in% current.names) { 
      stop(sprintf('Cannot call setVisualStyle on a non-existent visual style (%s)', new.style.name))
    }
    # change the current style to the new style
    resource.uri = paste(obj@uri, pluginVersion(obj), "apply/styles", new.style.name, net.SUID, sep="/")
    request.res = GET(url=resource.uri)
    write(sprintf('network visual style has been set to (%s)', new.style.name), stderr())
    invisible(request.res)
})
## END setVisualStyle

# ------------------------------------------------------------------------------
setMethod('lockNodeDimensions', 'CytoscapeConnectionClass', 
   function(obj, new.state, visual.style.name='default') {
      # for implementation....
}) 
## END lockNodeDimensions

# ------------------------------------------------------------------------------
setMethod('getDefaultBackgroundColor', 'CytoscapeConnectionClass', 
  function(obj, vizmap.style.name='default') {
    resource.uri = paste(obj@uri, pluginVersion(obj), "styles", as.character(vizmap.style.name), "defaults/NETWORK_BACKGROUND_PAINT", sep="/")
    request.res = GET(url=resource.uri)
    def.background.color = fromJSON(rawToChar(request.res$content))[[2]]
    return(def.background.color)
})
## END getDefaultBackgroundColor

# ------------------------------------------------------------------------------
setMethod('setDefaultBackgroundColor', 'CytoscapeConnectionClass', 
  function(obj, new.color, vizmap.style.name='default') {
    resource.uri = paste(obj@uri, pluginVersion(obj), "styles", as.character(vizmap.style.name), "defaults", sep="/")
    style = list(visualProperty = 'NETWORK_BACKGROUND_PAINT', value = new.color)
    style.JSON = toJSON(list(style))
    request.res = PUT(url=resource.uri, body=style.JSON, encode="json")
    invisible(request.res)
})
## END setDefaultBackgroundColor

# ------------------------------------------------------------------------------
setMethod('getDefaultNodeSelectionColor', 'CytoscapeConnectionClass', 
  function(obj, vizmap.style.name='default') {
    return(getVisualProperty(obj, vizmap.style.name, 'NODE_SELECTED_PAINT'))
})
## END getDefaultNodeSelectionColor

# ------------------------------------------------------------------------------
setMethod('setDefaultNodeSelectionColor', 'CytoscapeConnectionClass', 
  function(obj, new.color, vizmap.style.name='default') {
    style = list(visualProperty = "NODE_SELECTED_PAINT", value = new.color) 
    setVisualProperty(obj, style, vizmap.style.name)
})
## END setDefaultNodeSelectionColor

# ------------------------------------------------------------------------------
setMethod('getDefaultNodeReverseSelectionColor', 'CytoscapeConnectionClass', 
   function(obj, vizmap.style.name='default') {
      return(getVisualProperty(obj, vizmap.style.name, 'NODE_PAINT'))
})
## END getDefaultNodeReverseSelectionColor

# ------------------------------------------------------------------------------
setMethod('setDefaultNodeReverseSelectionColor', 'CytoscapeConnectionClass', 
   function(obj, new.color, vizmap.style.name='default') {
      style = list(visualProperty = "NODE_PAINT", value = new.color)
      setVisualProperty(obj, style, vizmap.style.name)
})
## END setDefaultNodeReverseSelectionColor

# ------------------------------------------------------------------------------
setMethod('getDefaultEdgeSelectionColor', 'CytoscapeConnectionClass', 
  function(obj, vizmap.style.name='default') {
    return(getVisualProperty(obj, vizmap.style.name, 'EDGE_STROKE_SELECTED_PAINT'))
})
## END getDefaultEdgeSelectionColor

# ------------------------------------------------------------------------------
setMethod('setDefaultEdgeSelectionColor', 'CytoscapeConnectionClass', 
  function(obj, new.color, vizmap.style.name='default') {
    style = list(visualProperty = "EDGE_STROKE_SELECTED_PAINT", value = new.color) 
    setVisualProperty(obj, style, vizmap.style.name)
})
## END setDefaultEdgeSelectionColor

# ------------------------------------------------------------------------------
setMethod('getDefaultEdgeReverseSelectionColor', 'CytoscapeConnectionClass', 
   function(obj, vizmap.style.name='default') {
      return(getVisualProperty(obj, vizmap.style.name, 'EDGE_PAINT'))
})
## END getDefaultEdgeReverseSelectionColor

# ------------------------------------------------------------------------------
setMethod('setDefaultEdgeReverseSelectionColor', 'CytoscapeConnectionClass', 
   function(obj, new.color, vizmap.style.name='default') {
      style = list(visualProperty = "EDGE_PAINT", value = new.color)
      setVisualProperty(obj, style, vizmap.style.name)
})
## END setDefaultEdgeReverseSelectionColor

# ------------------------------------------------------------------------------
# TODO: TanjaM - scaling not possible with the new cyREST version - remove?
setMethod('saveImage', 'CytoscapeWindowClass', 
    function(obj, file.name, image.type, scale=1.0) {
        image.type = tolower(image.type)
        stopifnot(image.type %in% c('png', 'pdf', 'svg'))
        net.SUID = as.character(obj@window.id)
        
        if(!file.exists(file.name)) {
            # get image of the Cytoscape view in PNG format
            if(image.type == 'png'){
                resource.uri = paste(obj@uri, pluginVersion(obj), "networks", net.SUID, "views/first.png", sep="/")
            } else {
                write(sprintf('RCy3 currently allows to save as PNG files only.'), stderr())
                return()
            }
            request.res = GET(url=resource.uri, write_disk(file.name))
            
            write(sprintf("Image saved to file '%s'", file.name), stderr())
        } else {
            write(sprintf("File '%s' already exists. Please, use another name.", file.name), stderr ())
        }
})
## END saveImage

# ------------------------------------------------------------------------------
setMethod('saveNetwork', 'CytoscapeWindowClass', 
    function(obj, file.name, format='cys') {
        if(!file.exists(file.name)) {
            # TODO: currently only saves as cys, enable to save also to other formats including glm
            resource.uri = paste(obj@uri, pluginVersion(obj), "session", sep="/")
            request.res = POST(url=resource.uri, body=NULL, write_disk(file.name))
            write(sprintf('saving network to file %s', file.name), stderr())
            invisible(request.res)
        }
})
## END saveNetwork

# ------------------------------------------------------------------------------
# not used in RCy3 [GIK - 29Mar, 2015] : could be removed
hexColorToInt = function(hex.string)
{
   if(substr(hex.string, 1, 1) == '#') {
      base.index = 2
      if(nchar(hex.string) != 7) {
         return (NA)
      }
   } else {
      base.index = 1
      if(nchar(hex.string) != 6) {
         return (NA)
      }
   }
   red = strtoi(substr(hex.string, base.index, base.index+1), base=16)
   green = strtoi(substr(hex.string, base.index+2, base.index+3), base=16)
   blue = strtoi(substr(hex.string, base.index+4, base.index+5), base=16)
   
   return(list(red=red, green=green, blue=blue))

}
## END hexColorToInt

# ------------------------------------------------------------------------------
.classicGraphToNodePairTable = function (g)
{
  edges.g <- edges(g)
  edge.names = as.character(unlist(sapply(names(edges.g), function (a) {
         bs = edges.g[[a]]; 
         if (length (bs) > 0) paste (a, edges.g[[a]], sep='~') 
         })))
  # print(class(edge.names))
  # print(edge.names)
  pairs = strsplit (edge.names, '~')
  a = sapply (pairs, "[", 1)
  b = sapply (pairs, "[", 2)

  if ('edgeType' %in% eda.names (g))
    edgeType = as.character (edgeData (g, from=a, to=b, attr='edgeType'))
  else
    edgeType = rep ('unspecified', length (a))

  return(data.frame(source=a, target=b, edgeType=edgeType, stringsAsFactors=FALSE))
}
## END .classicGraphToNodePairTable

# ------------------------------------------------------------------------------
.multiGraphToNodePairTable = function (mg)
{
  edge.set.names = edgeSets (mg)

  template = list (source='', target='', edgeType='')
  tbl = data.frame (template, stringsAsFactors=F)
  for (edge.set in edgeSets (mg)) {
    tilde.names = edgeNames (mg, edge.set)
    pairs = strsplit (tilde.names, '~')
    for (pair in pairs) {
      source.node = pair [1]
      target.node = pair [2]
      new.row = list (source=source.node, target=target.node, edgeType=edge.set)
      tbl = rbind (tbl, new.row)
      }
    } # for edge
  
  invisible (tbl [-1,])
} 
## END .multiGraphToNodePairTable

# ------------------------------------------------------------------------------
# the bioc graph 'edgeNames' function does not detect, distinguish or report reciprocal edges 
# this behavior is fixed here
.rcyEdgeNames = function(g) 
{
   nodes.list = edges(g)
   result = c()
   for(source.node in names(nodes.list)) {
    target.nodes = nodes.list[[source.node]]
    
    if(length(target.nodes) == 0) {
      next;
    }    
    for(target.node in target.nodes) {
      tilde.edge.name = sprintf('%s~%s', source.node, target.node) 
      result = c(result, tilde.edge.name) 
    } # END for target.node
  } # END for source.node
  return(result)
}
## END .rcyEdgeNames

#------------------------------------------------------------------------------------------------------------------------
.getNovelEdges = function (g.old, g.new)
{
  if (length (edges (g.old)) == 0)
    gOld.edgeCount = 0
  else
    gOld.edgeCount = length (edgeNames (g.old))

  if (length (edges (g.new)) == 0)
    gNew.edgeCount = 0
  else
    gNew.edgeCount = length (edgeNames (g.new))

  #printf ('g.old: %d edges', gOld.edgeCount)
  #printf ('g.new: %d edges', gNew.edgeCount)

  if (gNew.edgeCount == 0)
    return (NA)

  if (gOld.edgeCount == 0)
    return (cy2.edge.names (g.new))

  old.edges = cy2.edge.names (g.old)
  new.edges = cy2.edge.names (g.new)
  novel.edges = setdiff (new.edges, old.edges)
  novel.edges.indices = match (novel.edges, as.character (new.edges))
  return (new.edges [novel.edges.indices])
  

} # .getNovelEdges

# ------------------------------------------------------------------------------
is.classic.graph = function(obj)
{
   obj.classes = is(obj)
   return ('graph' %in% obj.classes)  
} 
## END is.classic.graph

# ------------------------------------------------------------------------------
is.multiGraph = function(obj)
{
   obj.classes = is(obj)
   return('MultiGraph' %in% obj.classes)
} 
## END is.multiGraph

# ------------------------------------------------------------------------------
predictedDisplayGraphTime = function(graph) {
   # for implementation ...
}
## END predictedDisplayGraphTime

# ------------------------------------------------------------------------------
# capitalizes the first letter of all words in a string
simpleCap <- function(x) {
  s <- strsplit(x, " ")[[1]]
  
  return(paste(toupper(substring(s, 1, 1)), substring(s, 2), sep="", collapse=""))
} ### END simpleCap

# ------------------------------------------------------------------------------
getVisualProperty <- function(obj, vizmap.style.name, property) {
  resource.uri = paste(obj@uri, pluginVersion(obj), "styles", as.character(vizmap.style.name), "defaults", property, sep="/")
  request.res = GET(url=resource.uri)
  return(fromJSON(rawToChar(request.res$content))[[2]])
}
## END getVisualProperty

# ------------------------------------------------------------------------------
setVisualProperty <- function(obj, style.string, vizmap.style.name='default') {
  resource.uri = paste(obj@uri, pluginVersion(obj), "styles", as.character(vizmap.style.name), "defaults", sep="/")
  style.JSON = toJSON(list(style.string))
  request.res = PUT(url=resource.uri, body=style.JSON, encode="json")
  redraw(obj)
}
## END setVisualProperty

# ------------------------------------------------------------------------------
setNodePropertyDirect <- function(obj, node.names, new.values, visual.property) {
   # get network ID and cyREST plugin version
   net.SUID = as.character(obj@window.id)
   version = pluginVersion(obj)
   
   # cyREST allows for multiple views per network 
   # get all views that exist for this network and select the first one
   net.views.SUIDs = .getNetworkViews(obj)
   view.SUID = as.character(net.views.SUIDs[[1]])
   
   node.SUIDs = .nodeNameToNodeSUID(obj, node.names)
   
   # 'node.names' and 'new.values' must have the same length
   if(length(new.values) == 1) {
      new.values = rep(new.values, length(node.names))
   }
   if(length(new.values) != length(node.names)) {
      write(sprintf("Error: list sizes for node.names [%d] and new.values [%d] do not match.", 
                    length(node.names), length(new.values)), stderr())
      return()
   }
   
   request.res = c()
   for(i in seq(node.SUIDs)) {
      node.SUID = as.character(node.SUIDs[i])
      current.value = new.values[i]
      
      resource.uri = 
         paste(obj@uri, version, "networks", net.SUID, "views", view.SUID, "nodes", node.SUID, sep="/")
      node.SUID.JSON = 
         toJSON(list(list(visualProperty=visual.property, value=current.value)))
      request.res = PUT(resource.uri, body=node.SUID.JSON, encode="json")
   } # end for (node.SUID in node.SUIDs)
   
   invisible(request.res)
}
## END setNodePropertyDirect

setEdgePropertyDirect <- function(obj, edge.names, new.values, visual.property){
   # get network ID and version
   net.SUID = as.character(obj@window.id)
   version = pluginVersion(obj)
   
   # cyREST allows for multiple views per network 
   # get all views that exist for this network and select the first one
   net.views.SUIDs = .getNetworkViews(obj)
   view.SUID = as.character(net.views.SUIDs[[1]])
   
   edge.SUIDs = .edgeNameToEdgeSUID(obj, edge.names)
   
   # 'edge.names' and 'new.values' must have the same length
   if(length(new.values) == 1) {
      new.values = rep(new.values, length(edge.names))
   }
   if(length(new.values) != length(edge.names)) {
      write(sprintf("Error: list sizes for edge.names [%d] and new.values [%d] do not match.", 
                    length(edge.names), length(new.values)), stderr())
      return()
   }
   
   request.res = c()
   for(i in seq(edge.SUIDs)) {
      edge.SUID = as.character(edge.SUIDs[i])
      current.value = new.values[i]
      
      resource.uri = 
         paste(obj@uri, version, "networks", net.SUID, "views", view.SUID, "edges", edge.SUID, sep="/")
      edge.SUID.JSON = 
         toJSON(list(list(visualProperty=visual.property, value=current.value)))
      request.res = PUT(url=resource.uri, body=edge.SUID.JSON, encode="json")
   }
   
   invisible(request.res)
}
## END setEdgePropertyDirect

.discreteMapper <- function(obj, node.attribute.name, control.points, colors, visual.prop, column.type, style) {
    mapped.content = apply()
}
## END .discreteMapper

.continuousMapper <- function() {
    
}
## END .continuousMapper

# ------------------------------------------------------------------------------
# obtain every other value in vector(s): convenience method
obtainEveryOtherValue <- function(v) {
  return(v[c(TRUE, FALSE)])
}
## END obtainEveryOtherValue